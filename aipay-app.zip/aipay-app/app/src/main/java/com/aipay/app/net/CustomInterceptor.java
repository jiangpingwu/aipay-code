package com.aipay.app.net;

import android.text.TextUtils;

import com.aipay.app.utils.LogUtils;
import com.aipay.app.utils.UserUtils;
import com.aipay.app.utils.Utils;

import java.io.IOException;

import okhttp3.Interceptor;
import okhttp3.Request;
import okhttp3.Response;

public class CustomInterceptor implements Interceptor {
    @Override
    public Response intercept(Chain chain) throws IOException {

/***
 *device-code    设备标识

 terminal-source 终端来源标识

 network-type 网络类型标识

 client-version 客户端版本标识

 */
        LogUtils.i("device-code = "+ Utils.getDeviceId());
        LogUtils.i("terminal-source = "+"ANDROID");
        LogUtils.i("network-type = "+Utils.getNetWorkType());
        LogUtils.i("client-version = "+Utils.getVersionName());


        Request original = chain.request();

        Request.Builder builder=original.newBuilder()
                .header("device-code", Utils.getDeviceId())
                .header("terminal-source", "ANDROID")
                .header("network-type", Utils.getNetWorkType())
                .header("client-version", Utils.getVersionName());


        if (!TextUtils.isEmpty(UserUtils.getToken())){
          //  builder.header("unique-code",UserUtils.getToken());
        }

        Request request = builder
                .method(original.method(), original.body())
                .build();

        return chain.proceed(request);


    }


}
