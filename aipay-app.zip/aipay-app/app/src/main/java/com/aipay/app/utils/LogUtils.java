package com.aipay.app.utils;

import android.util.Log;

public class LogUtils {


    private   static   boolean    isLog=true;

    private   static   String   tag="paymerchantapp";

    public    static    void   setTag(String   outTag){
          tag=outTag;
    }

    public   static    void   setIsLog(boolean  outIsLog){
        isLog=   outIsLog;
    }

    public   static   void   i(String   msg){
         if (isLog){
             Log.i(tag,msg);
         }
    }


}
