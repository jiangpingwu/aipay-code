package com.aipay.app.activity;

import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.view.View;

import com.aipay.app.R;
import com.aipay.app.adapter.CustomAdapter;
import com.aipay.app.fragment.RechargeFragment;
import com.aipay.app.fragment.RechargeRecordFragment;
import com.aipay.app.mvp.presenter.IBasePresenter;
import com.aipay.app.mvp.view.IBaseView;

import butterknife.Bind;
import butterknife.OnClick;



public class CountMoneyActivity extends BaseActivity<IBasePresenter> implements IBaseView {
    //@Bind(R.id.money)
   // TextView money;
    @Bind(R.id.mTb)
    TabLayout mTb;
    @Bind(R.id.mVp)
    ViewPager mVp;

    private  CustomAdapter   adapter;



    @Override
    protected IBasePresenter getPresenter() {
        return null;
    }


    @OnClick(R.id.comeBack)
    public   void  comeBack(View view){
        finish();
    }

    @Override
    protected void initView() {
        //money.setText(Utils.formatMoney(UserUtils.getUserBean().balance));
        adapter=new CustomAdapter(getSupportFragmentManager());
        adapter.addFragment(new RechargeFragment(),"充值");
        adapter.addFragment(new RechargeRecordFragment(),"记录");
        mTb.setTabMode(TabLayout.MODE_FIXED);
        mTb.addTab(mTb.newTab().setText("充值"));
        mTb.addTab(mTb.newTab().setText("记录"));
        mVp.setAdapter(adapter);
        mTb.setupWithViewPager(mVp);



    }

    @Override
    protected int getContentView() {
        return R.layout.activity_count_money;
    }


}
