package com.aipay.app.net;

import android.content.Context;

import com.aipay.app.utils.LogUtils;
import com.aipay.app.bean.ResponseBean;
import com.aipay.app.handler.ProgressDialogHandler;

import io.reactivex.subscribers.ResourceSubscriber;


public abstract class ResourceSub<BEAN> extends ResourceSubscriber<ResponseBean<BEAN>> {
    private ProgressDialogHandler mHandler;

    public ResourceSub(Context context, boolean isShowLoadDialog) {
        if (isShowLoadDialog) {
            mHandler = new ProgressDialogHandler(context);
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        showDialog();
    }


    public void showDialog() {
        if (mHandler != null) {
            mHandler.obtainMessage(ProgressDialogHandler.DIALOG_SHOW).sendToTarget();
        }
    }

    public void dismissDialog() {
        if (mHandler != null) {
            mHandler.obtainMessage(ProgressDialogHandler.DIALOG_DISMISS).sendToTarget();
            mHandler.setContextNull();
        }
    }


    public void onCustomComplete() {

    }

    public void onCustomError() {
    }

    @Override
    public void onNext(ResponseBean<BEAN> bean) {
        if ("1".equals(bean.status)) {
            onCustomOneNext(bean.data);
        } else {
            onCustomNotOneNext();
        }

        onCustomComplete();
    }

    protected abstract void onCustomNotOneNext();


    public abstract void onCustomOneNext(BEAN data);

    @Override
    public void onError(Throwable e) {
        LogUtils.i(" e = " + e.getMessage());
        LogUtils.i("e = " + e.getLocalizedMessage());
        onCustomError();
        onCustomComplete();
    }

    @Override
    public void onComplete() {

    }
}
