package com.aipay.app.activity;

import android.animation.Animator;
import android.animation.ObjectAnimator;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.animation.BaseAnimation;
import com.aipay.app.utils.LogUtils;
import com.aipay.app.adapter.OrderAdapter;
import com.aipay.app.R;
import com.aipay.app.SimpleDividerItemDecoration;
import com.aipay.app.bean.ContentBean;
import com.aipay.app.bean.OrderItemBean;
import com.aipay.app.event.SupplementEvent;
import com.aipay.app.mvp.presenter.IOrderPresenter;
import com.aipay.app.mvp.presenter.OrderPresenter;
import com.aipay.app.mvp.view.IOrderView;
import com.aipay.app.pop.SearchOrderPop;
import com.aipay.app.utils.UserUtils;

import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.List;

import butterknife.Bind;
import butterknife.OnClick;



public class OrderActivity extends BaseActivity<IOrderPresenter> implements BaseQuickAdapter.RequestLoadMoreListener,
        IOrderView, SwipeRefreshLayout.OnRefreshListener, SearchOrderPop.SearchOrderListener {

    private OrderAdapter orderAdapter;

    @Bind(R.id.recycler)
    RecyclerView recyclerView;

    @Bind(R.id.swipeRefreshLayout)
    SwipeRefreshLayout swipeRefreshLayout;

    @Bind(R.id.topRl)
    RelativeLayout   topRl;

    @Bind(R.id.allContainer)
    LinearLayout  allContainer;



    @Override
    protected IOrderPresenter getPresenter() {
        return new OrderPresenter(this);
    }

    @Override
    protected void initView() {

        recyclerView.addItemDecoration(new SimpleDividerItemDecoration(this, 30));
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        orderAdapter = new OrderAdapter();
        orderAdapter.setEmptyView(View.inflate(this,R.layout.layout_order_empty,null));
        orderAdapter.isFirstOnly(false);
        orderAdapter.openLoadAnimation(new BaseAnimation() {
            @Override
            public Animator[] getAnimators(View view) {

                return new Animator[]{
                        ObjectAnimator.ofFloat(view, "scaleY", 1.0f, 0.9f, 1.0f),
                        ObjectAnimator.ofFloat(view, "scaleX", 1.0f, 0.9f, 1.0f),
                        ObjectAnimator.ofFloat(view, "alpha", 0.1f, 0.5f, 1.0f)
                };
            }
        });
        orderAdapter.setOnLoadMoreListener(this);
        swipeRefreshLayout.setColorScheme(R.color.red_EE3D15);
        swipeRefreshLayout.setOnRefreshListener(this);


        recyclerView.setAdapter(orderAdapter);

        onRefresh();
    }

    @Override
    protected boolean isRegisterEventBus() {
        return true;
    }

    /***
     *手动补单
     */
    @Subscribe(threadMode = ThreadMode.MAIN)
    public void supplementEvnet(SupplementEvent event) {
          presenter.supplementOrder(event);
    }

    @Override
    protected int getContentView() {
        return R.layout.activity_order;
    }

    @Override
    public void onLoadMoreRequested() {

        presenter.getOrderListCondition(false);

    }

    @OnClick(R.id.comeBack)
    public   void   comeBack(View    view){
        finish();
    }

    @OnClick(R.id.search)
    public    void   search(View  view){
        LogUtils.i("点击了");
        new SearchOrderPop(this,this).showAsDropDown(topRl);
    }


    @Override
    public void onRefresh() {
        presenter.getOrderListCondition(true);
    }

    @Override
    public void setRefreshing(boolean isRefreshing) {
        swipeRefreshLayout.setRefreshing(isRefreshing);
    }

    @Override
    public void setDataloadStatus(boolean isCompleteLoad) {
        if (isCompleteLoad) {
            orderAdapter.loadMoreEnd();
        } else {
            orderAdapter.loadMoreComplete();
        }
    }

    @Override
    public void addData(List<ContentBean> orderList, boolean isRefreshing) {
//        if (isRefreshing) {
//            orderAdapter.setNewData(orderList);
//        } else {
//            orderAdapter.addData(orderList);
//        }

    }

    @Override
    public void supplementOrderSuccess(String platformNum) {
         List<OrderItemBean>   list=       orderAdapter.getData();
         for (OrderItemBean item:list){
             if (item.code.equals(platformNum)){
               //  item.payStatusName="已完成";
               //  item.payStatus="COMPLIETED";
                 item.isSupplementing=true;
                 orderAdapter.notifyDataSetChanged();
                 return;
             }

         }

    }



    @Override
    public void addDataCondition(List<OrderItemBean> listBeans, boolean isRefreshing) {
          if (isRefreshing){
              orderAdapter.setNewData(listBeans);
          }else {
              orderAdapter.addData(listBeans);
          }

          if (listBeans.size()==0){
              orderAdapter.loadMoreEnd();
          }else {
              orderAdapter.loadMoreComplete();
          }
    }

    @Override
    public void clickSearch(String payChannel, String payStatus, String beginDateTime, String endDateTime) {
        presenter.getOrderListBySearch(beginDateTime,endDateTime, UserUtils.getUserBean().code,payChannel,payStatus);
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        SearchOrderPop.clearSearchData();
    }
}
