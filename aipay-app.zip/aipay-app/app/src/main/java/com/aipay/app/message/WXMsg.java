package com.aipay.app.message;

import android.app.Notification;
import android.os.Bundle;
import android.service.notification.StatusBarNotification;
import android.text.TextUtils;

import com.aipay.app.Constant;
import com.aipay.app.utils.LogUtils;

import java.util.List;



public class WXMsg extends NotificationMsg {
    public WXMsg() {
        super(1, "微信支付", Constant.PAY_CHANNEL_WX);
    }

    @Override
    protected void setMsgFromFeflex(List<String> text) {
        String content = getMoneyStringByFeflex(text);
        if (!TextUtils.isEmpty(content)) {
            int m, n;
            m = content.indexOf("收款");
            n = content.indexOf("元");
            LogUtils.i("m==" + m + " && n==" + n);
            if (m > 0 && n > 0) {
                String moneyString = content.substring(m + 2, n);
                setMoney(moneyString);
                LogUtils.i("money = " + money);

            }
        }



    }

    /***
     *获取微信扫码得到的价格字符串
     */
    protected String getMoneyStringByFeflex(List<String> texts) {
        int size = texts.size();
        boolean a = false;
        String moneyString = "";
        for (int position = 0; position < size; position++) {
            String item = texts.get(position);
            if (!TextUtils.isEmpty(item)) {
                if (("微信支付".equals(item))) {
                    a = true;
                }

                if (item.contains("微信支付收款")) {
                    moneyString = item;
                }
            }
        }

        if (a && !TextUtils.isEmpty(moneyString)) {
            return moneyString;
        } else {
            return "";
        }
    }

    @Override
    protected void setMsgFromBundle(Bundle bundle, StatusBarNotification sbn) {
        String title = bundle.getString(Notification.EXTRA_TITLE, "");
        String content = bundle.getString(Notification.EXTRA_TEXT, "");
        LogUtils.i("title = " + title + "   content = " + content);
        if ("微信支付".equals(title) && content.contains("微信支付")) {
            int m, n;

            m = content.indexOf("收款");
            n = content.indexOf("元");
            LogUtils.i("m==" + m + " && n==" + n);
            if (m > 0 && n > 0) {
                String moneyString = content.substring(m + 2, n);
                setMoney(moneyString);
                LogUtils.i("money = " + money);

            }

        } else {
            LogUtils.i("微信支付=title && content==微信支付");
        }

    }


}
