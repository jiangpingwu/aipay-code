package com.aipay.app;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.annotation.TargetApi;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.text.TextUtils;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import com.aipay.app.utils.LogUtils;

import java.util.List;

public class OrderService extends AccessibilityService {

    /**
     * 微信几个页面的包名+地址。用于判断在哪个页面
     * LAUCHER-微信聊天界面
     * LUCKEY_MONEY_RECEIVER-点击红包弹出的界面
     * LUCKEY_MONEY_DETAIL-红包领取后的详情界面
     */
    private String LAUCHER = "com.tencent.mm.ui.LauncherUI";
    //  private String LUCKEY_MONEY_DETAIL = "com.tencent.mm.plugin.luckymoney.ui.LuckyMoneyDetailUI";
    //    private String LUCKEY_MONEY_RECEIVER = "com.tencent.mm.plugin.luckymoney.ui.LuckyMoneyReceiveUI1";
//    private String LUCKEY_MONEY_RECEIVER = "com.tencent.mm.plugin.luckymoney.ui.En_fba4b94f";
    private String LUCK_MONEY_RECEIVE_PREFIX = "com.tencent.mm.plugin.luckymoney.ui";


    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        LogUtils.i(" paymerchantapp-   onServiceConnected()");

        AccessibilityServiceInfo accessibilityServiceInfo = new AccessibilityServiceInfo();
        //指定包名
        //accessibilityServiceInfo.packageNames = new String[]{Constant.WX_PACKAGE_NAME,Constant.ALIPAY_PACKAGE_NAME};
        //指定事件类型
        accessibilityServiceInfo.eventTypes = AccessibilityEvent.TYPES_ALL_MASK;
        accessibilityServiceInfo.feedbackType = AccessibilityServiceInfo.FEEDBACK_SPOKEN;
        accessibilityServiceInfo.notificationTimeout = 1000;
        setServiceInfo(accessibilityServiceInfo);

    }

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        int eventType = event.getEventType();
        //获取事件发生的包名
        CharSequence packageName = event.getPackageName();

        String className = event.getClassName().toString();

        LogUtils.i("currentClassName = " + className);


        if (TextUtils.isEmpty(packageName)) {

            return;
        }

        switch (eventType) {
            //状态栏标识
            case AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED:
                List<CharSequence> texts = event.getText();

                for (CharSequence text : texts) {
                    String content = text.toString();
                    LogUtils.i(getClass().getSimpleName() + "  " + content);
                    if (!TextUtils.isEmpty(content)) {

                        if (Constant.WX_PACKAGE_NAME.equals(packageName)) {
                            //微信事件
                            //判断是否含有[微信红包]字样
                            LogUtils.i("微信事件  content-  " + content);


                        } else if (Constant.ALIPAY_PACKAGE_NAME.equals(packageName)) {
                            //支付宝事件
                            LogUtils.i("支付宝事件");
                        }


                    }
                }

                //窗口切换的时候回调
            case AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED:
            case AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED:


                if (Constant.WX_PACKAGE_NAME.equals(packageName)) {
                    //微信事件


                } else if (Constant.ALIPAY_PACKAGE_NAME.equals(packageName)) {
                    //支付宝事件
                    LogUtils.i("支付宝事件");
                }

        }

    }

    /***
     *微信转账状态栏有变化
     * @param event
     */
    @TargetApi(Build.VERSION_CODES.JELLY_BEAN_MR2)
    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    private void checkStatusBarMsg(AccessibilityEvent event) {


    }

    /***
     *寻找转账信息
     */
    private void findTransferAccounts(AccessibilityNodeInfo rootNode) {
        LogUtils.i("寻找转账信息");
    }

    @Override
    public void onInterrupt() {

    }

}
