package com.aipay.app.fragment;

import com.aipay.app.R;
import com.aipay.app.mvp.presenter.IBaseFragPresenter;
import com.aipay.app.mvp.view.IBaseFragView;


public class EmptyFragment  extends   BaseFragment<IBaseFragPresenter>  implements IBaseFragView{
    @Override
    protected void initView() {

    }

    @Override
    protected IBaseFragPresenter getPresenter() {
        return null;
    }

    @Override
    protected int getLayoutView() {
        return R.layout.fragment_empty;
    }
}
