package com.aipay.app.net;

import com.aipay.app.utils.LogUtils;

import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;

public abstract class   BaseSubscriber<T>   implements   Observer<T> {

    /***
    *无论是否获取数据成功都会走的方法
    */
    public    void    onCustomComplete(){

    }

    public  abstract   void   onCustomNext(T   bean);

    public   abstract void   onCustomError();

    @Override
    public void onSubscribe(Disposable d) {

    }

    @Override
    public void onNext(T bean) {
        onCustomNext(bean);
        onCustomComplete();
    }

    @Override
    public void onError(Throwable e) {
        LogUtils.i("e "+e.getMessage());
        LogUtils.i("e "+e.getLocalizedMessage());
        e.printStackTrace();
        onCustomError();
        onCustomComplete();

    }

    @Override
    public void onComplete() {

    }
}
