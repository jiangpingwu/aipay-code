package com.aipay.app.mvp.view;

import android.app.Activity;

import com.trello.rxlifecycle2.LifecycleProvider;
import com.trello.rxlifecycle2.android.ActivityEvent;



public interface IBaseView {

    public Activity  getActivity();

    public <T>  LifecycleProvider<T>  getLifecycleProvide();


    public     void   showLoadDialog();
    public     void    dismissLoadDialog();


}
