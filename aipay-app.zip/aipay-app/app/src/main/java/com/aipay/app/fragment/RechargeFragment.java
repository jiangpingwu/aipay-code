package com.aipay.app.fragment;

import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.aipay.app.R;
import com.aipay.app.Constant;
import com.aipay.app.activity.MainActivity;
import com.aipay.app.bean.AlipayEvent;
import com.aipay.app.mvp.presenter.IRechargePresenter;
import com.aipay.app.mvp.presenter.RechargePresenter;
import com.aipay.app.mvp.view.IRechargeView;

import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import butterknife.Bind;
import butterknife.OnClick;


public class RechargeFragment extends BaseFragment<IRechargePresenter> implements IRechargeView, RadioGroup.OnCheckedChangeListener {
    @Bind(R.id.money)
    EditText money;
    @Bind(R.id.rb_alipay)
    RadioButton rbAlipay;
    @Bind(R.id.rb_wx)
    RadioButton rbWx;
    @Bind(R.id.searchPayChannel)
    RadioGroup searchPayChannel;
    @Bind(R.id.rechargeNow)
    TextView rechargeNow;


    String    payChannel="";

    @Override
    protected void initView() {
         searchPayChannel.setOnCheckedChangeListener(this);
    }


    @OnClick(R.id.rechargeNow)
    public    void    rechargeNow(View   view){
         presenter.rechargeNow(payChannel);
    }

    @Override
    protected IRechargePresenter getPresenter() {
        return new RechargePresenter(this);
    }

    @Override
    protected int getLayoutView() {
        return R.layout.fragment_recharge;
    }

    @Override
    protected boolean isRegisterEventBus() {
        return true;
    }


    @Subscribe(threadMode = ThreadMode.MAIN)
    public   void   payEvent(AlipayEvent  event){
        if (event.status==1){
            MainActivity.actionStartDefault(getActivity(),MainActivity.class);
        }
    }

    @Override
    public void onCheckedChanged(RadioGroup group, int checkedId) {
          if (checkedId==rbAlipay.getId()){
              payChannel= Constant.PAY_CHANNEL_ALIPAY;
          }else if (checkedId==rbWx.getId()){
              payChannel=Constant.PAY_CHANNEL_WX;
          }
    }

    @Override
    public double getMoney() {
       String   moneyString=     money.getText().toString().trim();
        if (TextUtils.isEmpty(moneyString)   ){
            return 0;
        }

        return  Double.parseDouble(moneyString);

    }
}
