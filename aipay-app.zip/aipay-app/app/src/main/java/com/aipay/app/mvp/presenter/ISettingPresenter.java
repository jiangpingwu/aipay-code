package com.aipay.app.mvp.presenter;


public interface ISettingPresenter  extends   IBasePresenter {
    void checkUpdate();
}
