package com.aipay.app.mvp.presenter;

import android.content.DialogInterface;
import android.support.v4.util.ArrayMap;
import android.support.v7.app.AlertDialog;
import android.text.TextUtils;

import com.google.gson.Gson;
import com.aipay.app.utils.LogUtils;
import com.aipay.app.MyApplication;
import com.aipay.app.activity.LoginActivity;
import com.aipay.app.bean.CheckAppBean;
import com.aipay.app.bean.ResponseBean;
import com.aipay.app.bean.UserBean;
import com.aipay.app.event.UpdateAppEvent;
import com.aipay.app.mvp.view.IMainView;
import com.aipay.app.net.APIService;
import com.aipay.app.net.NetRxFactory;
import com.aipay.app.net.ResponseSub;
import com.aipay.app.service.DownLoadService;
import com.aipay.app.utils.SPUtils;
import com.aipay.app.utils.StorageUtils;
import com.aipay.app.utils.SystemUtils;
import com.aipay.app.utils.UserUtils;
import com.aipay.app.utils.Utils;

import org.greenrobot.eventbus.EventBus;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.concurrent.TimeUnit;

import okhttp3.ResponseBody;



public class MainPresenter  extends   BasePresenter<IMainView>  implements   IMainPresenter {
    public MainPresenter(IMainView view) {
        super(view);
    }

    @Override
    public void getUserInfo() {

        if (TextUtils.isEmpty(SPUtils.getToken())){
            LoginActivity.actionStartDefault(view.getActivity(),LoginActivity.class);
            view.getActivity().finish();
            return;
        }else {
            UserUtils.getUserBean().token= SPUtils.getToken();
        }

        view.showLoadDialog();
        NetRxFactory.getServer(APIService.class).getUserInfo(UserUtils.getToken(),"")
                .delay(1000, TimeUnit.MILLISECONDS)
        .compose(view.getLifecycleProvide().<ResponseBean<UserBean>>bindToLifecycle())
        .compose(NetRxFactory.<ResponseBean<UserBean>>toMain())
        .subscribe(new   ResponseSub<UserBean>(){
            @Override
            public void onOneNext(UserBean userBean) {
                    view.getUserInfoSuccess(userBean);
            }

            @Override
            public void onNext(ResponseBean<UserBean> bean) {
                if ("-1".equals(bean.status)){
                    LoginActivity.actionStartDefault(view.getActivity(),LoginActivity.class);
                    view.getActivity().finish();
                    return;
                }
                super.onNext(bean);
            }

            @Override
            public void onCustomComplete() {
                super.onCustomComplete();
                view.dismissLoadDialog();
            }
        });


    }

    @Override
    public void loginOut() {
        if (TextUtils.isEmpty(UserUtils.getToken())){
            clearUserInfo();
            LoginActivity.actionStartDefault(view.getActivity(),LoginActivity.class);
            view.getActivity().finish();
            return;
        }
        view.showLoadDialog();
        NetRxFactory.getServer(APIService.class).loginOut(UserUtils.getToken(),"")
        .compose(view.getLifecycleProvide().<ResponseBean<String>>bindToLifecycle())
        .compose(NetRxFactory.<ResponseBean<String>>toMain())
        .subscribe(new ResponseSub<String>() {
            @Override
            public void onOneNext(String s) {
                clearUserInfo();
                LoginActivity.actionStartDefault(view.getActivity(),LoginActivity.class);
                view.getActivity().finish();
            }

            @Override
            public void onCustomComplete() {
                super.onCustomComplete();
                if (view!=null){

                    view.dismissLoadDialog();
                }
            }
        });

        ;

    }

    @Override
    public void updatePhoneInfo() {
        ArrayMap<String,Object>    map =  new ArrayMap<>();
        map.put("systemVersion", SystemUtils.getSystemVersion());
        map.put("systemModel",SystemUtils.getSystemModel());
        map.put("deviceBrand",SystemUtils.getDeviceBrand());
        NetRxFactory.getServer(APIService.class).updatePhoneInfo(UserUtils.getToken(),new Gson().toJson(map))
        .compose(view.getLifecycleProvide().<ResponseBean<String>>bindToLifecycle())
        .compose(NetRxFactory.<ResponseBean<String>>toMain())
        .subscribe(new ResponseSub<String>() {
            @Override
            public void onOneNext(String s) {
                LogUtils.i("上传手机信息成功");
            }
        });

    }

    @Override
    public void checkAppVersion() {
        NetRxFactory.getServer(APIService.class)
        .isNeedUpgrade(Utils.getVersionName(), MyApplication.context.getPackageName())
        .compose(view.getLifecycleProvide().<ResponseBean<CheckAppBean>>bindToLifecycle())
        .compose(NetRxFactory.<ResponseBean<CheckAppBean>>toMain())
        .subscribe(new ResponseSub<CheckAppBean>() {
            @Override
            public void onOneNext(final CheckAppBean checkAppBean) {


                if (checkAppBean.isNeedUpgrade){
                    AlertDialog.Builder builder = new AlertDialog.Builder(view.getActivity());
                    builder.setTitle("提示");
                    builder.setMessage("检查到有新版本，需要更新吗?");
                    builder.setNegativeButton("取消", null);
                    builder.setPositiveButton("确定", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                               updateNewApp(checkAppBean.downloadUrl);
                         //   LogUtils.i("lastIndex = "+checkAppBean.downloadUrl.lastIndexOf("/"));
                             //LogUtils.i("path = "+      StorageUtils.getCacheDirectory(view.getActivity()).toString());
                        }
                    });
                    builder.show();
                }else {
                    Utils.showToash("当前版本已经是最新的");
                }

            }
        });



        ;
    }

    private void updateNewApp(String downloadUrl) {
      // FileDownloadService downloadService = ServiceGenerator.create(FileDownloadService.class);
          int    num =    downloadUrl.lastIndexOf("/")  ;
          DownLoadService.downloadUrl=downloadUrl;
          DownLoadService. apkName=   downloadUrl.substring(num) ;
          final File    apkStorageFile=   StorageUtils.getCacheDirectory(view.getActivity())  ;
          if (!apkStorageFile.exists()){
              apkStorageFile.mkdirs();
          }

          EventBus.getDefault().post(new UpdateAppEvent(""));

//        Call<ResponseBody> call = NetRxFactory.getServer(APIService.class).downloadFileWithDynamicUrlSync(downloadUrl);
//
//        call.enqueue(new Callback<ResponseBody>() {
//            @Override
//            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
//                if (response.isSuccessful()) {
//                   // Log.d(TAG, "server contacted and has file");
//                   String    apkPath=  apkStorageFile.toString()+"/"+apkName ;
//
//                   LogUtils.i("apkPath  = "+apkPath);
//                    boolean writtenToDisk = writeResponseBodyToDisk(response.body(),apkPath);
//                   if (writtenToDisk){
//                       EventBus.getDefault().post(new UpdateAppEvent(apkPath));
//                   }
//                   // Log.d(TAG, "file download was a success? " + writtenToDisk);
//                } else {
//                  //  Log.d(TAG, "server contact failed");
//                }
//            }
//
//            @Override
//            public void onFailure(Call<ResponseBody> call, Throwable t) {
//              //  Log.e(TAG, "error");
//            }
//        });


    }
    private boolean writeResponseBodyToDisk(ResponseBody body,String   apkStorePath) {
        try {
            // todo change the file location/name according to your needs
            File futureStudioIconFile = new File(apkStorePath);

            InputStream inputStream = null;
            OutputStream outputStream = null;

            try {
                byte[] fileReader = new byte[4096];

                long fileSize = body.contentLength();
                long fileSizeDownloaded = 0;

                inputStream = body.byteStream();
                outputStream = new FileOutputStream(futureStudioIconFile);

                while (true) {
                    int read = inputStream.read(fileReader);

                    if (read == -1) {
                        break;
                    }

                    outputStream.write(fileReader, 0, read);

                    fileSizeDownloaded += read;

                    LogUtils.i( "file download: " + fileSizeDownloaded + " of " + fileSize);
                }

                outputStream.flush();

                return true;
            } catch (IOException e) {
                return false;
            } finally {
                if (inputStream != null) {
                    inputStream.close();
                }

                if (outputStream != null) {
                    outputStream.close();
                }
            }
        } catch (IOException e) {
            return false;
        }
    }


    private  void   clearUserInfo(){
        SPUtils.putToken("");
        UserUtils.setToken("");
    }
}
