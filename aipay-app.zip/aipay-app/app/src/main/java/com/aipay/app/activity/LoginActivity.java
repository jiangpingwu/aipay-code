package com.aipay.app.activity;

import android.text.InputType;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.aipay.app.R;
import com.aipay.app.mvp.presenter.ILoginPresenter;
import com.aipay.app.mvp.presenter.LoginPresenter;
import com.aipay.app.mvp.view.ILoginView;
import com.aipay.app.utils.Utils;

import butterknife.Bind;
import butterknife.OnClick;



public class LoginActivity extends BaseActivity<ILoginPresenter> implements ILoginView {
    private static final String ENABLED_NOTIFICATION_LISTENERS = "enabled_notification_listeners";

    @Bind(R.id.userName)
    EditText userName;
    @Bind(R.id.psd)
    EditText psd;
    @Bind(R.id.showPsw)
    TextView showPsw;
    //private boolean isEnabledNLS = false;

    @Override
    protected ILoginPresenter getPresenter() {
        return new LoginPresenter(this);
    }

    @Override
    protected void initView() {
        Utils.toggleNotificationListenerService(this);
    }

    @OnClick(R.id.showPsw)
    public void pswVisiable(View view) {
        pwdShow();
    }

    public void pwdShow() {
        int type = InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD;
        if (psd.getInputType() == type) {
            psd.setInputType(InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
            psd.setSelection(psd.getText().length());     //把光标设置到当前文本末尾
            showPsw.setText("隐藏");
        } else {
            psd.setInputType(type);
            psd.setSelection(psd.getText().length());
            showPsw.setText("显示");
        }
    }

    public String getUserAccount() {
        return userName.getText().toString().trim();
    }

    public String getPsw() {
        return psd.getText().toString().trim();
    }

    @Override
    public void loginSuccess() {
        MainActivity.actionStartDefault(this, MainActivity.class);

        finish();
    }

    @Override
    protected int getContentView() {
        return R.layout.activity_login;
    }

    @OnClick(R.id.login)
    public void login(View view) {
        presenter.login();
    }
}
