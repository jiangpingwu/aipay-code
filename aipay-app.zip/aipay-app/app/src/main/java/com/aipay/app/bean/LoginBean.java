package com.aipay.app.bean;

import com.google.gson.annotations.SerializedName;


public class LoginBean {


    /**
     * status : 1
     * msg : 操作成功
     * data : MTExMV8xMjM0NTZfMA==
     */

    @SerializedName("status")
    public String status;
    @SerializedName("msg")
    public String msg;
    @SerializedName("data")
    public String data;
}
