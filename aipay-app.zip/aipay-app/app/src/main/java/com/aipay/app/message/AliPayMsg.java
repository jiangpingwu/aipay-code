package com.aipay.app.message;

import android.app.Notification;
import android.os.Bundle;
import android.service.notification.StatusBarNotification;

import com.aipay.app.Constant;

import java.util.List;



public class AliPayMsg extends NotificationMsg {
    public AliPayMsg() {
        super(2, "支付宝支付", Constant.PAY_CHANNEL_ALIPAY);
    }


    @Override
    protected void setMsgFromFeflex(List<String> text) {

    }

    @Override
    protected void setMsgFromBundle(Bundle bundle, StatusBarNotification sbn) {
        String title = bundle.getString(Notification.EXTRA_TITLE, "");
        String content = bundle.getString(Notification.EXTRA_TEXT, "");

        if ("支付宝通知".equals(title) &&  content.contains("通过扫码向你付款") ){
            int  m=     content.indexOf("付款");
            int  n=     content.indexOf("元")  ;
            setMoney(content.substring(m+2,n));
        }

    }
}
