package com.aipay.app.bean;

import com.google.gson.annotations.SerializedName;


public class ResponseBean<T> {


    /**
     * status : 1
     * msg : 操作成功
     * data : {"code":"ZPM_TEST81","mobile":"15099923283","appKey":"654321","appSecret":"123456","balance":10000}
     */

    @SerializedName("status")
    public String status;
    @SerializedName("msg")
    public String msg;
    @SerializedName("data")
    public T data;


}
