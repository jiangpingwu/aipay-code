package com.aipay.app.mvp.view;

import com.aipay.app.bean.UserBean;



public interface IMainView  extends   IBaseView {
    void getUserInfoSuccess(UserBean userBean);
}
