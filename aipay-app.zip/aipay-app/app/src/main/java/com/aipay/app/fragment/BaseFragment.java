package com.aipay.app.fragment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.trello.rxlifecycle2.LifecycleProvider;
import com.trello.rxlifecycle2.android.FragmentEvent;
import com.trello.rxlifecycle2.components.support.RxFragment;
import com.aipay.app.utils.LogUtils;
import com.aipay.app.mvp.presenter.IBaseFragPresenter;
import com.aipay.app.mvp.view.IBaseFragView;

import org.greenrobot.eventbus.EventBus;

import butterknife.ButterKnife;


public abstract class BaseFragment<PRESENTER  extends IBaseFragPresenter>    extends RxFragment  implements IBaseFragView{

    protected   String    TAG=getClass().getSimpleName();
    protected   View    rootView;
   protected   PRESENTER   presenter;
    @Override
    public void onResume() {
        super.onResume();
        LogUtils.i(TAG+"  onResume");
    }

    @Override
    public void showLoadDialog() {

    }

    @Override
    public void dismissLoadDialog() {

    }

    public LifecycleProvider<FragmentEvent> getLifecycleProvide() {
        return this;
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        LogUtils.i(TAG+"  setUserVisibleHint "+isVisibleToUser);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        rootView=    inflater.inflate(getLayoutView(), null);
        ButterKnife.bind(this,rootView);

        if (isRegisterEventBus()) {
            EventBus.getDefault().register(this);
        }

        presenter=  getPresenter() ;
        initView();
        LogUtils.i(TAG+" onCreateView");
        return rootView;
    }

    protected abstract void initView();

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (isRegisterEventBus()){
            EventBus.getDefault().unregister(this);
        }
        if (presenter!=null){
            presenter.onDestroyView();
        }
        ButterKnife.unbind(this);
    }

    protected abstract PRESENTER getPresenter();

    protected abstract int getLayoutView() ;

    /***
     *是否注册eventbus
     */
    protected boolean isRegisterEventBus() {
        return false;
    }
}
