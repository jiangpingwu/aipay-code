package com.aipay.app.mvp.presenter;



public interface ILoginPresenter  extends   IBasePresenter {
    void login();
}
