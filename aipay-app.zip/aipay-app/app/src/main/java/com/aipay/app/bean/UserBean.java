package com.aipay.app.bean;

import com.google.gson.annotations.SerializedName;

import java.math.BigDecimal;


public class UserBean {
    /**
     * code : ZPM_TEST81
     * mobile : 15099923283
     * appKey : 654321
     * appSecret : 123456
     * balance : 10000
     */

    @SerializedName("code")
    public String code;
    @SerializedName("mobile")
    public String mobile;
    @SerializedName("appKey")
    public String appKey;
    @SerializedName("appSecret")
    public String appSecret;
    @SerializedName("balance")
    public double balance;

    @SerializedName("rate")
    public BigDecimal rate;


    /***
    *商户信息 {
     appSecret (string, optional): 二次加密后的商户密钥 ,
     balance (number, optional): 余额 ,
     code (string, optional): 商户编码 ,
     email (string, optional): 邮箱 ,
     mobile (string, optional): 手机号 ,
     qq (string, optional): qq号 ,
     status (string, optional): 商户状态 = ['NORMAL', 'FORBIDDEN'],
     statusName (string, optional): 商户状态名称 ,
     type (string, optional): 商户类型 = ['NORMAL', 'PROXY'],
     typeName (string, optional): 商户类型名称
     }
    */
    @SerializedName("email")
    public String email;

    @SerializedName("qq")
    public   String   qq;

    @SerializedName("status")
    public   String   status;

    @SerializedName("statusName")
    public   String   statusName;

    @SerializedName("type")
    public  String   type;

    @SerializedName("typeName")
    public   String   typeName;

    /***
    *从登录接口中获取的token
    */
    public    String   token="";


}
