package com.aipay.app.mvp.view;



public interface IRechargeView  extends   IBaseFragView {
    double getMoney();
}
