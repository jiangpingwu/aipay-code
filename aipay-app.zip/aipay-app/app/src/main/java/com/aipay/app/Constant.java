package com.aipay.app;


public class Constant {

    public   static final String   ALIPAY_APP_ID="";
    public  static  final String   WXPAY_APP_ID="";
    public   static   final String    WX_APP_KEY="";


    public   static   final  int   NOTIFICATION_ID=130;

    //微信包名
    public static final String WX_PACKAGE_NAME = "com.tencent.mm";

    //支付宝包名
    public static final String ALIPAY_PACKAGE_NAME = "com.eg.android.AlipayGphone";

    public    static final   String   PAY_CHANNEL_ALIPAY="ALIPAY_CODE";
    public   static   final  String   PAY_CHANNEL_WX="WECHAT_CODE";

    /***
    *测试环境的地址
    */
    public   static   final   String   URL_IP_DEBUG="http://120.79.93.227:8081";

    /***
    *生产环境的地址
    */
    public   static   final String   URL_IP_PRODUCT="";

    /***
    *是否是生产环境
    */
    public    static   boolean  isProduct;

    public    static   String  getBaseUrl(){
         if (isProduct){
             return   URL_IP_PRODUCT;
         }else {
             return  URL_IP_DEBUG;
         }
    }

    public static  String URL_BASE = getBaseUrl()+"/all";
    public   static     String  OTHER_URL_BASE =  getBaseUrl()+"/all";
}
