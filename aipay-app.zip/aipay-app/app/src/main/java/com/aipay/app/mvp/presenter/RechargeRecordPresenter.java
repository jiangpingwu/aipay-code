package com.aipay.app.mvp.presenter;

import android.support.v4.util.ArrayMap;

import com.aipay.app.bean.RechargeRecordItemBean;
import com.aipay.app.bean.ResponseBean;
import com.aipay.app.mvp.view.IRechargeRecordView;
import com.aipay.app.net.APIService;
import com.aipay.app.net.NetRxFactory;
import com.aipay.app.net.ResponseSub;
import com.aipay.app.utils.UserUtils;
import com.aipay.app.utils.Utils;

import java.util.List;



public class RechargeRecordPresenter  extends   BaseFragPresenter<IRechargeRecordView>
  implements   IRechargeRecordPresenter{


    private int pageNo = 0;

    private boolean canGetData = true, isCompleteLoad = false;


    public RechargeRecordPresenter(IRechargeRecordView view) {
        super(view);
    }

    @Override
    public void getRechargeRecordList(final boolean isRefreshing) {
        if (!canGetData) {
            return;
        }
        if (isRefreshing) {
            pageNo = 0;
            isCompleteLoad = false;
        }
        canGetData = false;
        pageNo++;
        ArrayMap<String, Object> map = new ArrayMap<>();
        /***
        *{
         "beginDateTime": "string",
         "endDateTime": "string",
         "merchantCode": "string",
         "pageNo": 0,
         "pageSize": 0,
         "rechargeChannel": "WECHAT_WAP",
         "rechargeStatus": "UNPAY"
         }
        */
        //map.put("beginDateTime",null);
       // map.put("endDateTime",null);
        //map.put("merchantCode",null);
        map.put("pageNo",pageNo);
        map.put("pageSize",10);
      //  map.put("rechargeChannel",null);
      //  map.put("rechargeStatus",null);

        NetRxFactory.getServer(APIService.class).getRechargeRecordList(UserUtils.getToken(), Utils.getRequestBody(map))
        .compose(view.getLifecycleProvide().<ResponseBean<List<RechargeRecordItemBean>>>bindToLifecycle())
        .compose(NetRxFactory.<ResponseBean<List<RechargeRecordItemBean>>>toMain())
        .subscribe(new ResponseSub<List<RechargeRecordItemBean>>() {


            @Override
            public void onOneNext(List<RechargeRecordItemBean> listBeans) {

                view.addData(listBeans, isRefreshing);

            }

            @Override
            public void onNotOneOrError() {
                pageNo--;
            }

            @Override
            public void onCustomComplete() {
                super.onCustomComplete();
                view.setRefreshing(false);
                canGetData = true;
            }


        });

        ;


    }
}
