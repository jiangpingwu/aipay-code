package com.aipay.app.bean;

import com.google.gson.annotations.SerializedName;



public class CheckAppBean {


    /**
     * isNeedUpgrade : true
     * lastestVersion : 1.0.2
     * downloadUrl :
     * remark : 修复了若刚bug
     */

    @SerializedName("isNeedUpgrade")
    public boolean isNeedUpgrade;
    @SerializedName("lastestVersion")
    public String lastestVersion;
    @SerializedName("downloadUrl")
    public String downloadUrl;
    @SerializedName("remark")
    public String remark;
}
