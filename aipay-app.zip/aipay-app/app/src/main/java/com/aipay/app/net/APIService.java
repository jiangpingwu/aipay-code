package com.aipay.app.net;

import com.aipay.app.bean.CheckAppBean;
import com.aipay.app.bean.OrderBean;
import com.aipay.app.bean.OrderItemBean;
import com.aipay.app.bean.RechargeBean;
import com.aipay.app.bean.RechargeRecordItemBean;
import com.aipay.app.bean.ResponseBean;
import com.aipay.app.bean.UserBean;

import java.math.BigDecimal;
import java.util.List;

import io.reactivex.Observable;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.Headers;
import retrofit2.http.POST;
import retrofit2.http.Query;
import retrofit2.http.Url;

public interface APIService {
    // @GET("http://www.runoob.com/try/angularjs/data/sites.php")
    // Observable<LoginBean> getLoginBean();

    @GET
    Call<ResponseBody> downloadFileWithDynamicUrlSync(@Url String fileUrl);


    /***
     *检查是否有新的版本
     */
    @Headers({"Content-Type: application/x-www-form-urlencoded", "Accept: application/json"})
    @POST("app/isNeedUpgrade")
    @FormUrlEncoded
    Observable<ResponseBean<CheckAppBean>> isNeedUpgrade(@Field("clientVersion") String clientVersion, @Field("packageName") String packageName);


    /***
     *获取手机相关信息到后台
     */
    @Headers({"Content-Type: application/x-www-form-urlencoded", "Accept: application/json"})
    @POST("app/addStatInfo")
    @FormUrlEncoded
    Observable<ResponseBean<String>> updatePhoneInfo(@Header("unique-code") String uniqueCode, @Field("content") String content);


    @Headers({"Content-Type: application/json", "Accept: application/json"})
    @POST("order/queryList")
    Observable<ResponseBean<List<OrderItemBean>>> getOrderListCondition(@Header("unique-code") String uniqueCode, @Body RequestBody requestBody);

    /***
     *获取充值记录接口
     */
    @Headers({"Content-Type: application/json", "Accept: application/json"})
    @POST("merchant/queryRecharge")
    Observable<ResponseBean<List<RechargeRecordItemBean>>> getRechargeRecordList(@Header("unique-code") String uniqueCode, @Body RequestBody requestBody);


    /***
     *退出登录
     */
    @Headers({"Content-Type: application/x-www-form-urlencoded", "Accept: application/json"})
    @POST("merchant/logout")
    @FormUrlEncoded
    Observable<ResponseBean<String>> loginOut(
            @Header("unique-code") String uniqueCode,
            // @Header("unique-code") String token,
            @Field("appData") String appdate
    );

    /***
     *监听状态栏支付回调
     */
    @Headers({"Content-Type: application/x-www-form-urlencoded", "Accept: application/json"})
    @POST
    @FormUrlEncoded
    Observable<ResponseBean<String>> payCallback(
            @Url String url,
            // @Header("unique-code") String token,
            @Field("merchantCode") String merchantCode,
            @Field("payAmount") BigDecimal payAmount,
            @Field("payChannel") String payChannel,
            @Field("sign") String sign
    );

    /***
     * 手动补单
     * unique-code用戶token标识header string
     merchantCode商户号formData string
     orderCode平台订单号formData string
     sign签名formData string

     */
    @Headers({"Content-Type: application/x-www-form-urlencoded", "Accept: application/json"})
    @POST
    @FormUrlEncoded
    Observable<ResponseBean<String>> updateStatus(
            @Url String url,
            @Header("unique-code") String uniqueCode,
            @Field("merchantCode") String mechantCode,
            @Field("code") String code,
            @Field("sign") String sign
    );

    /***
     * 获取订单列表
     */
    @Headers({"Content-Type: application/x-www-form-urlencoded", "Accept: application/json"})
    @POST("order/query")
    @FormUrlEncoded
    Observable<ResponseBean<OrderBean>> getOrderList(
            @Header("unique-code") String uniqueCode,
            @Field("pageNo") int pageNo,
            @Field("pageSize") int pageSize
    );


    /***
     *获取用户数据
     */
    @Headers({"Content-Type: application/x-www-form-urlencoded", "Accept: application/json"})
    @POST("merchant/getDetailInfo")
    @FormUrlEncoded
    Observable<ResponseBean<UserBean>> getUserInfo(
            @Header("unique-code") String token,
            @Field("appdata") String appData
    );

    /***
     *获取用户数据
     */
    @Headers({"Content-Type: application/x-www-form-urlencoded", "Accept: application/json"})
    @POST("merchant/getDetailInfo")
    @FormUrlEncoded
    ResourceSub<ResponseBean<UserBean>> getUserInfoByResourceSub(
            @Header("unique-code") String token,
            @Field("appdata") String appData
    );

    /***
     *登录
     mobile 手机号 formData string
     password 密码 formData string
     */
    @Headers({"Content-Type: application/x-www-form-urlencoded", "Accept: application/json"})
    @POST("merchant/login")
    @FormUrlEncoded
    Observable<ResponseBean<String>> login(
            @Field("mobile") String mobile,
            @Field("password") String psw
    );

    /***
     * 充值
     * appId appId
     query	string
     unique-code
     (required)
     用戶token标识
     header	undefined
     rechargePlatform
     支付平台
     formData	string
     rechargeChannel
     支付渠道
     formData	string
     amount
     (required)
     金额
     formData	double
     */
    @Headers({"Content-Type: application/x-www-form-urlencoded", "Accept: application/json"})
    @POST("merchant/recharge")
    @FormUrlEncoded
    Observable<ResponseBean<RechargeBean>> recharge(
            @Header("unique-code") String uniqueCode,
            @Query("appId") String appId,

            @Field("rechargePlatform") String rechargePlatform,
            @Field("rechargeChannel") String rechargeChannel,
            @Field("amount") double amount
    );
}
