package com.aipay.app.activity;

import android.view.View;
import android.widget.TextView;

import com.aipay.app.R;
import com.aipay.app.mvp.presenter.ISettingPresenter;
import com.aipay.app.mvp.presenter.SettingPresenter;
import com.aipay.app.mvp.view.ISettingView;
import com.aipay.app.utils.Utils;

import butterknife.Bind;
import butterknife.OnClick;


public class SettingActivity extends BaseActivity<ISettingPresenter> implements ISettingView {

    @Bind(R.id.apkVersion)
    TextView apkVersion;

    @Override
    protected ISettingPresenter getPresenter() {
        return new SettingPresenter(this);
    }

    @Override
    protected void initView() {
        apkVersion.setText("版本:" + Utils.getVersionName());
    }

    @OnClick(R.id.comeBack)
    public void comeBack(View view) {
        finish();
    }

    @OnClick(R.id.checkUpdate)
    public void checkUpdate(View view) {
        presenter.checkUpdate();
    }

    @OnClick(R.id.about)
    public   void   aboutUs(View   view){
        AboutUsActivity.actionStartDefault(this,AboutUsActivity.class);
    }


    @Override
    protected int getContentView() {
        return R.layout.activity_setting;
    }
}
