package com.aipay.app.mvp.presenter;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;

import com.aipay.app.MyApplication;
import com.aipay.app.bean.CheckAppBean;
import com.aipay.app.bean.ResponseBean;
import com.aipay.app.mvp.view.ISettingView;
import com.aipay.app.net.APIService;
import com.aipay.app.net.NetRxFactory;
import com.aipay.app.net.ResponseSub;
import com.aipay.app.service.DownLoadService;
import com.aipay.app.utils.Utils;



public class SettingPresenter  extends   BasePresenter<ISettingView> implements  ISettingPresenter {
    public SettingPresenter(ISettingView view) {
        super(view);
    }

    @Override
    public void checkUpdate() {
        NetRxFactory.getServer(APIService.class)
                .isNeedUpgrade(Utils.getVersionName(), MyApplication.context.getPackageName())
                .compose(view.getLifecycleProvide().<ResponseBean<CheckAppBean>>bindToLifecycle())
                .compose(NetRxFactory.<ResponseBean<CheckAppBean>>toMain())
                .subscribe(new ResponseSub<CheckAppBean>() {
                    @Override
                    public void onOneNext(final CheckAppBean checkAppBean) {


                        if (checkAppBean.isNeedUpgrade){
                            AlertDialog.Builder builder = new AlertDialog.Builder(view.getActivity());
                            builder.setTitle("提示");
                            builder.setMessage("检查到有新版本，需要更新吗?");
                            builder.setNegativeButton("取消", null);
                            builder.setPositiveButton("确定", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {

                                    int    num =    checkAppBean.downloadUrl.lastIndexOf("/")  ;
                                    DownLoadService.downloadUrl=checkAppBean.downloadUrl;
                                    DownLoadService. apkName=   checkAppBean.downloadUrl.substring(num) ;
                                    view.getActivity().startService(new Intent(view.getActivity(),DownLoadService.class));

                                }
                            });
                            builder.show();
                        }else {
                            Utils.showToash("当前版本已经是最新的");
                        }

                    }
                });
    }
}
