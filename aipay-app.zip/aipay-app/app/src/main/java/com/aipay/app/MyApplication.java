package com.aipay.app;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.support.multidex.MultiDex;

import com.aipay.app.utils.LogUtils;

import java.util.ArrayList;

public class MyApplication extends Application {

    public static MyApplication context;

    private static ArrayList<Activity> activityList = new ArrayList<>();


    public static void addActivity(Activity activity) {
        activityList.add(activity);
    }

    public static void removeActivity(Activity activity) {
        activityList.remove(activity);
    }

    public static void clearAllActivity() {

        for (Activity activity : activityList) {
            if (activity != null) {
                activity.finish();
            }

        }
        //杀死该应用进程
        android.os.Process.killProcess(android.os.Process.myPid());
        //System.exit(10);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        context = this;
        CrashHandler.getInstance().init(this);

        // getPackageManager().getPackageInfo(getPackageName(),PackageMan)
        PackageManager pm = context.getPackageManager();
        try {
            ApplicationInfo appInfo = pm.getApplicationInfo(context.getPackageName(), PackageManager.GET_META_DATA);

            String key = appInfo.metaData.getString("APP_PLATFORM_KEY");


            if ("local".equals(key)) {
                Constant.isProduct = false;
            } else {
                Constant.isProduct = true;
            }

            LogUtils.setIsLog(!Constant.isProduct);
            Constant.URL_BASE = Constant.getBaseUrl() + "/all";
            Constant.OTHER_URL_BASE = Constant.getBaseUrl() + "/all";
            LogUtils.i("baseUrl = " + Constant.URL_BASE);
        } catch (Exception e) {
            e.printStackTrace();
        }


    }

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        MultiDex.install(this);
    }
}
