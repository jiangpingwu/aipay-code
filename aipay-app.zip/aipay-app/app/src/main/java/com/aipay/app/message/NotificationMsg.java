package com.aipay.app.message;

import android.annotation.TargetApi;
import android.app.Notification;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.service.notification.StatusBarNotification;
import android.support.annotation.RequiresApi;
import android.text.TextUtils;
import android.widget.RemoteViews;

import com.aipay.app.Constant;
import com.aipay.app.utils.LogUtils;
import com.aipay.app.MyApplication;
import com.aipay.app.bean.ResponseBean;
import com.aipay.app.net.APIService;
import com.aipay.app.net.NetRxFactory;
import com.aipay.app.net.ResponseSub;
import com.aipay.app.utils.UserUtils;
import com.aipay.app.utils.Utils;

import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;


public abstract class NotificationMsg {
    /***
     *支付渠道
     */
    protected String payChannel;


    protected float money = -1.0f;//金额

    protected String typeString = "";

    protected int type;

    public NotificationMsg(int type, String typeString,String   payChannel) {
        this.type = type;
        this.typeString = typeString;
        this.payChannel=payChannel;
    }


    @TargetApi(Build.VERSION_CODES.KITKAT_WATCH)
    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    public void setMessage(StatusBarNotification sbn, Context context) {
        // 当 API > 18 时，使用 extras 获取通知的详细信息
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            Bundle bundle = sbn.getNotification().extras;
            if (bundle != null && !bundle.isEmpty()) {
                setMsgFromBundle(bundle, sbn);

            }
        } else {
            // 当 API = 18 时，利用反射获取内容字段
            List<String> texts = getText(sbn.getNotification());
            if (texts != null && texts.size() > 0) {
                setMsgFromFeflex(texts);
            }


        }
        if (money != -1.0f) {
            LogUtils.i("删除第三方状态栏消息，添加APP消息");
            Utils.cancelNotificationForce(context, sbn.getId(), sbn.getTag(), sbn.getPackageName(), sbn.getKey());
            LogUtils.i("生成id begin ");
           final int id = 10362;
            LogUtils.i("生成id end  id = " + id);

         //   EventBus.getDefault().post(new NotificationEvent(money,payChannel));

            BigDecimal payAmount =  BigDecimal.valueOf(money).divide(BigDecimal.valueOf(1L),2, RoundingMode.HALF_UP);
            String    sign=  Utils.getSign(payAmount,payChannel) ;
            LogUtils.i("sign = "+sign);
            NetRxFactory.getServer(APIService.class).payCallback(Constant.OTHER_URL_BASE+"/order/callbackForApp",UserUtils.getUserBean().code,payAmount,payChannel,
                    sign)
                    .compose(NetRxFactory.<ResponseBean<String>>toMain())
                    .subscribe(new ResponseSub<String>() {
                        @Override
                        public void onOneNext(String s) {
                            LogUtils.i("支付回调成功");
                            Utils.buildNotification(MyApplication.context, money + "元", typeString +"成功", 1, id);

                            //Utils.buildTestNotification(context, money + "元", typeString + ":" + "123123 测试商品成功", id);
                        }

                        @Override
                        public void onNotOneNext(String data) {
                            LogUtils.i("没有对应的订单");
                        }
                    });



        } else {
            LogUtils.i("money==-1.0f");
        }

    }

    /***
     *通过反射获取通知栏文本消息
     */
    protected abstract void setMsgFromFeflex(List<String> text);

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    public List<String> getText(Notification notification) {
        if (null == notification) {
            return null;
        }
        RemoteViews views = notification.bigContentView;
        if (views == null) {
            views = notification.contentView;
        }
        if (views == null) {
            return null;
        }
        // Use reflection to examine the m_actions member of the given RemoteViews object.
        // It's not pretty, but it works.
        List<String> text = new ArrayList<>();
        try {
            Field field = views.getClass().getDeclaredField("mActions");
            field.setAccessible(true);
            @SuppressWarnings("unchecked")
            ArrayList<Parcelable> actions = (ArrayList<Parcelable>) field.get(views);
            // Find the setText() and setTime() reflection actions
            for (Parcelable p : actions) {
                Parcel parcel = Parcel.obtain();
                p.writeToParcel(parcel, 0);
                parcel.setDataPosition(0);
                // The tag tells which type of action it is (2 is ReflectionAction, from the source)
                int tag = parcel.readInt();
                if (tag != 2) continue;
                // View ID
                parcel.readInt();
                String methodName = parcel.readString();
                if (null == methodName) {
                    continue;
                } else if (methodName.equals("setText")) {
                    // Parameter type (10 = Character Sequence)
                    parcel.readInt();
                    // Store the actual string
                    String t = TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel).toString().trim();
                    text.add(t);
                }
                parcel.recycle();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return text;
    }


    protected abstract void setMsgFromBundle(Bundle bundle, StatusBarNotification sbn);

    public int getType() {
        return type;
    }

    public float getMoney() {
        return money;
    }


    public void setMoney(String moneyString) {
        if (Utils.isNumeric(moneyString)) {
            money = Float.parseFloat(moneyString);
        }
    }


}
