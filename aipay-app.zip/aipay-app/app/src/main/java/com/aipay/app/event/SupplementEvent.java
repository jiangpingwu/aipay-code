package com.aipay.app.event;



public class SupplementEvent {
    /***
    *商户订单号
    */
    public    String   sellerOrderNum;

    /***
    *平台订单号
    */
    public    String   platformOrderNum;


    public     String   orderCode;

    public   int  num;


    public   SupplementEvent(String   sellerOrderNum,String   platformOrderNum,int   num,String   orderCode){
        this.sellerOrderNum  =   sellerOrderNum;
        this.platformOrderNum  =platformOrderNum;
        this.num=num;
        this.orderCode= orderCode;
    }
}
