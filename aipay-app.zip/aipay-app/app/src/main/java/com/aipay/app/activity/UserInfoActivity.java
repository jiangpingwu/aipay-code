package com.aipay.app.activity;

import android.view.View;
import android.widget.TextView;

import com.aipay.app.R;
import com.aipay.app.mvp.presenter.IBasePresenter;
import com.aipay.app.mvp.view.IBaseView;
import com.aipay.app.utils.UserUtils;
import com.aipay.app.utils.Utils;

import butterknife.Bind;
import butterknife.OnClick;



public class UserInfoActivity extends BaseActivity<IBasePresenter> implements IBaseView {


    @Bind(R.id.code)
    TextView code;
    @Bind(R.id.email)
    TextView email;
    @Bind(R.id.phone)
    TextView phone;
    @Bind(R.id.qq)
    TextView qq;
    @Bind(R.id.status)
    TextView status;
    @Bind(R.id.type)
    TextView type;

    @Bind(R.id.money)
    TextView money;

    @Bind(R.id.rate)
    TextView  rate;

    @OnClick(R.id.comeBack)
    public   void   comeBack(View view){
        finish();
    }

    @Override
    protected IBasePresenter getPresenter() {
        return null;
    }

    @Override
    protected void initView() {
        code.setText(UserUtils.getUserBean().code);
        email.setText(UserUtils.getUserBean().email);
        phone.setText(UserUtils.getUserBean().mobile);

        rate.setText(UserUtils.getUserBean().rate+"");

        qq.setText(UserUtils.getUserBean().qq);
        status.setText(UserUtils.getUserBean().statusName);
        type.setText(UserUtils.getUserBean().typeName);
        money.setText(Utils.formatMoney(UserUtils.getUserBean().balance));
    }

    @Override
    protected int getContentView() {
        return R.layout.activity_user_info;
    }


}
