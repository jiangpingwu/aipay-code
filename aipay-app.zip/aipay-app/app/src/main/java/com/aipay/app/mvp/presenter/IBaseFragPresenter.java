package com.aipay.app.mvp.presenter;



public interface IBaseFragPresenter {
    void onDestroyView();
}
