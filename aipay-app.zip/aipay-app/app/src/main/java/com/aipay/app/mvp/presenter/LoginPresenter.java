package com.aipay.app.mvp.presenter;

import android.text.TextUtils;

import com.aipay.app.utils.LogUtils;
import com.aipay.app.bean.ResponseBean;
import com.aipay.app.net.ResponseSub;
import com.aipay.app.utils.SPUtils;
import com.aipay.app.utils.Utils;
import com.aipay.app.mvp.view.ILoginView;
import com.aipay.app.net.APIService;
import com.aipay.app.net.NetRxFactory;
import com.aipay.app.utils.UserUtils;

import java.util.concurrent.TimeUnit;



public class LoginPresenter extends BasePresenter<ILoginView> implements ILoginPresenter {
    public LoginPresenter(ILoginView view) {
        super(view);
    }


    @Override
    public void login() {
        if (TextUtils.isEmpty(view.getUserAccount())) {
            Utils.showToash("请输入账户");
            return;
        } else if (TextUtils.isEmpty(view.getPsw())) {
            Utils.showToash("请输入密码");
            return;
        }
        LogUtils.i("登录中。。。");
        view.showLoadDialog();
        NetRxFactory.getServer(APIService.class).login(view.getUserAccount(), view.getPsw())
                .delay(1000, TimeUnit.MILLISECONDS)
                .compose(view.getLifecycleProvide().<ResponseBean<String>>bindToLifecycle())
                .compose(NetRxFactory.<ResponseBean<String>>toMain())
                .subscribe(new ResponseSub<String>() {
                    @Override
                    public void onOneNext(String s) {
                        UserUtils.setToken(s);
                        LogUtils.i("token  = "+s);
                        SPUtils.putToken(s);
                        view.loginSuccess();
                    }



                    @Override
                    public void onNotOneNext(String data) {
                        super.onNotOneNext(data);
                        Utils.showToash(data);
                    }

                    @Override
                    public void onNotOneOrError() {
                        Utils.showToash("登录失败");
                    }

                    @Override
                    public void onNext(ResponseBean<String> bean) {
                        view.dismissLoadDialog();
                        super.onNext(bean);
                    }

                    @Override
                    public void onError(Throwable e) {
                        super.onError(e);
                        view.dismissLoadDialog();
                    }
                });

    }
}
