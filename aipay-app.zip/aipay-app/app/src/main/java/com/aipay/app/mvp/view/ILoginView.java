package com.aipay.app.mvp.view;



public interface ILoginView   extends   IBaseView{


    public    String   getUserAccount();


    public    String   getPsw();

    void loginSuccess();
}
