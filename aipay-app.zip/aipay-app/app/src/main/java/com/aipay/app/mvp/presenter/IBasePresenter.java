package com.aipay.app.mvp.presenter;


public interface IBasePresenter {
    public    void  onCreate();


    public    void   onDestroy();
}
