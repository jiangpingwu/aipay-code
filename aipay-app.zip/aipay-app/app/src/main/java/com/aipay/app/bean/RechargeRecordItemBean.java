package com.aipay.app.bean;

import com.google.gson.annotations.SerializedName;

import java.math.BigDecimal;


public class RechargeRecordItemBean {


    /**
     * amount : 0
     * code : string
     * createDateTime : 2018-05-14T07:15:44.479Z
     * rechargeChannel : WECHAT_WAP
     * rechargeChannelName : string
     * rechargeStatus : UNPAY
     * rechargeStatusName : string
     */

    @SerializedName("amount")
    public BigDecimal amount;
    @SerializedName("code")
    public String code;
    @SerializedName("createDateTime")
    public String createDateTime;
    @SerializedName("rechargeChannel")
    public String rechargeChannel;
    @SerializedName("rechargeChannelName")
    public String rechargeChannelName;
    @SerializedName("rechargeStatus")
    public String rechargeStatus;
    @SerializedName("rechargeStatusName")
    public String rechargeStatusName;
}
