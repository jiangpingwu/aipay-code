package com.aipay.app.utils;

import android.app.Activity;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.util.Log;

import com.alipay.sdk.app.PayTask;
import com.tencent.mm.opensdk.modelpay.PayReq;
import com.tencent.mm.opensdk.openapi.IWXAPI;
import com.tencent.mm.opensdk.openapi.WXAPIFactory;
import com.aipay.app.Constant;
import com.aipay.app.bean.AlipayEvent;
import com.aipay.app.bean.RechargeBean;

import org.greenrobot.eventbus.EventBus;

import java.util.Map;

public class PayUtils {
    private static PayUtils instance;
    private static final int SDK_PAY_FLAG = 1001;

    public static PayUtils getInstance() {
        if (instance == null) {
            synchronized (PayUtils.class) {
                if (instance == null) {
                    instance = new PayUtils();
                }
            }
        }

        return instance;
    }


    private Handler mHandler = new Handler() {
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case SDK_PAY_FLAG:
                    PayResult payResult = new PayResult((Map<String, String>) msg.obj);
                    //同步获取结果
                    String resultInfo = payResult.getResult();
                    Log.i("Pay", "Pay:" + resultInfo);
                    String resultStatus = payResult.getResultStatus();
                    // 判断resultStatus 为9000则代表支付成功
                    if (TextUtils.equals(resultStatus, "9000")) {
                        // Toast.makeText(MainActivity.this, "支付成功", Toast.LENGTH_SHORT).show();
                        Utils.showToash("支付宝支付成功");
                        EventBus.getDefault().post(new AlipayEvent(1));

                    } else {
                        //  Toast.makeText(MainActivity.this, "支付失败", Toast.LENGTH_SHORT).show();
                        Utils.showToash("支付宝支付失败");

                        EventBus.getDefault().post(new AlipayEvent(0));

                    }

                    break;
            }


//            Result result = new Result((String) msg.obj);
//            Toast.makeText(DemoActivity.this, result.getResult(),
//                    Toast.LENGTH_LONG).show();
        }

        ;
    };

    /***
     *支付宝支付
     */
    public void alipay(final Activity context,final String   orderInfo) {
        //final String orderInfo = "";   // 订单信息

        Runnable payRunnable = new Runnable() {

            @Override
            public void run() {
                PayTask alipay = new PayTask(context);
                Map<String, String> result = alipay.payV2(orderInfo, true);

                Message msg = new Message();
                msg.what = SDK_PAY_FLAG;
                msg.obj = result;
                mHandler.sendMessage(msg);
            }
        };
        // 必须异步调用
        Thread payThread = new Thread(payRunnable);
        payThread.start();
    }

    private IWXAPI  api;
    /***
     *微信支付
     */
    public void wxpay(Activity context, RechargeBean  bean) {
       api= WXAPIFactory.createWXAPI(context, Constant.WX_APP_KEY);

        PayReq req = new PayReq();
        req.appId = bean.appid;
        req.partnerId = bean.partnerid;
        //预支付订单
        req.prepayId = bean.prepayid;
        req.nonceStr = bean.noncestr;
        req.timeStamp = bean.timestamp;
        req.packageValue = bean.packageStr;
        req.sign = bean.sign;
        // 在支付之前，如果应用没有注册到微信，应该先调用IWXMsg.registerApp将应用注册到微信
        //3.调用微信支付sdk支付方法
        api.sendReq(req);
    }
}
