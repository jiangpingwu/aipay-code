package com.aipay.app.mvp.presenter;

import com.aipay.app.mvp.view.IBaseView;



public class BasePresenter<VIEW  extends IBaseView>  implements    IBasePresenter {

    protected   VIEW     view;

    public    BasePresenter(VIEW    view){
        this.view=view;
    }



    public    void  onCreate(){

    }

    public    void   onDestroy(){
        this.view=null;
    }



}
