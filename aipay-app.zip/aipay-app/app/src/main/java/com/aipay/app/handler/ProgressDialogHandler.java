package com.aipay.app.handler;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.Handler;
import android.os.Message;

public class ProgressDialogHandler  extends Handler {

    public    static   final   int   DIALOG_SHOW  =  1;

    public    static   final    int   DIALOG_DISMISS =2;
    private Context context;
    private ProgressDialog pd;



    public      ProgressDialogHandler(Context   context){
        super();
        this.context = context;
    }

    public     void     setContextNull(){
        context=null;
    }

    @Override
    public void handleMessage(Message msg) {
        super.handleMessage(msg);

       switch (msg.what){
           case  DIALOG_SHOW:
               showDialog();
               break;


            case DIALOG_DISMISS:
                dismissDialog();
                break;
       }


    }

    private void dismissDialog() {
         if (pd!=null){
             pd.dismiss();
             pd=null;
         }
    }

    private void showDialog() {
        if (pd==null){
            pd=new ProgressDialog(context);

        }
        if (!pd.isShowing()){
            pd.show();
        }
    }
}
