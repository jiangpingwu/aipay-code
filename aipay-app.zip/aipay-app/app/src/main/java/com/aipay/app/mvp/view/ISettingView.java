package com.aipay.app.mvp.view;


public interface ISettingView extends IBaseView {
}
