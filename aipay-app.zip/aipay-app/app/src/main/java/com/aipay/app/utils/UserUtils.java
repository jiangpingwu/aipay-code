package com.aipay.app.utils;

import com.aipay.app.bean.UserBean;


public class UserUtils {

    private   static   UserUtils  instances;

    public   static   UserUtils   getInstances(){
        if (instances==null){
            synchronized (UserUtils.class){
                if (instances==null){
                      instances =new UserUtils();
                }
            }

        }

        return   instances;
    }

    private UserBean userBean;

    private   UserUtils(){
        userBean  =new UserBean();
    }

    public    static    void    setToken(String    token){
        getInstances().userBean.token=  token ;
    }

    public    static   String   getToken(){
      return      getInstances().userBean.token;
    }

    public   static   void    setUserInfo(UserBean  bean){
        getInstances().userBean.appKey =  bean.appKey  ;

        getInstances().userBean.appSecret= bean.appSecret;

        getInstances().userBean.balance=  bean.balance ;


        getInstances().userBean.code =  bean.code ;

        getInstances().userBean.mobile = bean.mobile ;

        getInstances().userBean.email=bean.email;
        getInstances().userBean.qq=bean.qq;
        getInstances().userBean.status=bean.status;
        getInstances().userBean.statusName=bean.statusName;
        getInstances().userBean.type=bean.type;
        getInstances().userBean.typeName= bean.typeName ;

        getInstances().userBean.rate=bean.rate;
    }


    public    static   UserBean  getUserBean(){
        return   getInstances().userBean;
    }


}
