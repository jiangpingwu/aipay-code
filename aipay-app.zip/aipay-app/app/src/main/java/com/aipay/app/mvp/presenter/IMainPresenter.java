package com.aipay.app.mvp.presenter;



public interface IMainPresenter  extends   IBasePresenter {
    void getUserInfo();

    void loginOut();

    void updatePhoneInfo();

    void checkAppVersion();
}
