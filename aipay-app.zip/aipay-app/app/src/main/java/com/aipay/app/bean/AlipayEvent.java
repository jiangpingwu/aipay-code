package com.aipay.app.bean;



public class AlipayEvent {


    public    int   status;

    public    AlipayEvent(int   status){
        this.status=status;
    }

}
