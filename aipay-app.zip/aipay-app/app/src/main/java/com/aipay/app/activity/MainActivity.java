package com.aipay.app.activity;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.Button;
import android.widget.TextView;

import com.app.hubert.guide.NewbieGuide;
import com.app.hubert.guide.listener.OnLayoutInflatedListener;
import com.app.hubert.guide.model.GuidePage;
import com.aipay.app.Constant;
import com.aipay.app.R;
import com.aipay.app.utils.LogUtils;
import com.aipay.app.MyApplication;
import com.aipay.app.bean.AlipayEvent;
import com.aipay.app.bean.UserBean;
import com.aipay.app.event.UpdateAppEvent;
import com.aipay.app.mvp.presenter.IMainPresenter;
import com.aipay.app.mvp.presenter.MainPresenter;
import com.aipay.app.mvp.view.IMainView;
import com.aipay.app.service.DownLoadService;
import com.aipay.app.utils.PermissionUtil;
import com.aipay.app.utils.UserUtils;
import com.aipay.app.utils.Utils;

import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.concurrent.TimeUnit;

import butterknife.Bind;
import butterknife.OnClick;
import io.reactivex.Observable;
import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;


public class MainActivity extends BaseActivity<IMainPresenter> implements IMainView {


    @Bind(R.id.userImg)
    View userImg;
    @Bind(R.id.userName)
    TextView userName;
    @Bind(R.id.userMoney)
    TextView userMoney;

    @Bind(R.id.setPermission)
    Button setPermission;

    @Bind(R.id.setSystemPermission)
    Button setSystemPermission;


    @Bind(R.id.userPhone)
    TextView userPhone;

    @Override
    protected IMainPresenter getPresenter() {
        return new MainPresenter(this);
    }

    @OnClick(R.id.myOrder)
    public void toMyOrderActivity(View view) {
        actionStartDefault(this, OrderActivity.class);
    }

    @Override
    protected void initView() {
        intervalTimer();

        //PermissionUtil.getCameraPermissions(this, 401);
        presenter.getUserInfo();
        presenter.updatePhoneInfo();
        Utils.toggleNotificationListenerService(this);
        Utils.buildNotification(this, MyApplication.context.getResources().getString(R.string.app_name) + "功能正常", "请保持此通知栏常驻", 10, Constant.NOTIFICATION_ID);

        //showMask();
    }

    /***
     *显示多层蒙版
     */
    private void showMask() {
        Animation enterAnimation = new AlphaAnimation(0f, 1f);
        enterAnimation.setDuration(600);
        enterAnimation.setFillAfter(true);

        Animation exitAnimation = new AlphaAnimation(1f, 0f);
        exitAnimation.setDuration(600);
        exitAnimation.setFillAfter(true);

        NewbieGuide.with(this).setLabel("page")
                .addGuidePage(

                        GuidePage.newInstance().addHighLight(setPermission)
                                .setLayoutRes(R.layout.layout_guide_use_permission, R.id.textView2)
                                .setOnLayoutInflatedListener(new OnLayoutInflatedListener() {
                                    @Override
                                    public void onLayoutInflated(View view) {
                                        TextView textView = (TextView) view.findViewById(R.id.textView);
                                        textView.setText(getResources().getString(R.string.guideUsePermission));
                                    }
                                })

                                .setEverywhereCancelable(false)
                                .setEnterAnimation(enterAnimation)
                                .setExitAnimation(exitAnimation)

                )
                .addGuidePage(

                        GuidePage.newInstance().addHighLight(setSystemPermission)
                                .setLayoutRes(R.layout.layout_guide_use_permission, R.id.textView2)
                                .setOnLayoutInflatedListener(new OnLayoutInflatedListener() {
                                    @Override
                                    public void onLayoutInflated(View view) {
                                        TextView textView = (TextView) view.findViewById(R.id.textView);
                                        textView.setText(getResources().getString(R.string.guideSystemPermission));
                                    }
                                })
                                .setEnterAnimation(enterAnimation)
                                .setExitAnimation(exitAnimation)

                ).show()

        ;


    }

    private void intervalTimer() {
        Observable.interval(0, 1, TimeUnit.MINUTES).compose(this.<Long>bindToLifecycle())
                .subscribe(new Observer<Long>() {
                    @Override
                    public void onSubscribe(Disposable d) {

                    }

                    @Override
                    public void onNext(Long aLong) {
                        LogUtils.i("循环遍历");

                        PermissionUtil.requestPerssions(getActivity(), 401, Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_PHONE_STATE);


                    }

                    @Override
                    public void onError(Throwable e) {

                    }

                    @Override
                    public void onComplete() {

                    }
                });

        ;
    }

    @OnClick(R.id.loginOut)
    public void loginOut(View view) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("提示");
        builder.setMessage("确定退出登录吗？");
        builder.setNegativeButton("取消", null);
        builder.setPositiveButton("确定", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                presenter.loginOut();
            }
        });
        builder.show();

    }

    @OnClick(R.id.setPermission)
    public void notificationPresemissionClick(View view) {
        Utils.openNotificationListenerServiceSetting(this);
    }

    @OnClick(R.id.setSystemPermission)
    public void clickSettingPresemission(View view) {
        startActivity(Utils.getAppDetailSettingIntent());
    }

    @Override
    protected int getContentView() {
        return R.layout.activity_main_app;
    }


    @Override
    public void getUserInfoSuccess(UserBean userBean) {
        UserUtils.setUserInfo(userBean);
        userName.setText("商户号:" + userBean.code);
        userPhone.setText("手机:" + userBean.mobile);
        userMoney.setText("余额:" + Utils.formatMoney(userBean.balance));
        presenter.updatePhoneInfo();
        presenter.checkAppVersion();

        showMask();
    }

    @OnClick(R.id.countMoney)
    public void countMoney(View view) {
        CountMoneyActivity.actionStartDefault(this, CountMoneyActivity.class);
    }

    @OnClick(R.id.personalInfo)
    public void jumpToPersonalInfo(View view) {
        actionStartDefault(this, UserInfoActivity.class);
    }

    @Override
    protected boolean isRegisterEventBus() {
        return true;
    }


    @Subscribe(threadMode = ThreadMode.MAIN)
    public void updateApp(UpdateAppEvent event) {
        // SystemUtils.installApk(this,event.appPath);
        startService(new Intent(this, DownLoadService.class));
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void recharge(AlipayEvent event) {
        if (event.status == 1) {
            presenter.getUserInfo();
        }
    }


    @OnClick(R.id.setting)
    public void clickSetting(View view) {
        actionStartDefault(this, SettingActivity.class);
    }


}
