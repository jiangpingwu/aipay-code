package com.aipay.app.utils;

import android.accessibilityservice.AccessibilityServiceInfo;
import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.media.RingtoneManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.NotificationManagerCompat;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.accessibility.AccessibilityManager;
import android.widget.Toast;

import com.google.gson.Gson;
import com.aipay.app.MyApplication;
import com.aipay.app.NotificationBroadcastReceiver;
import com.aipay.app.R;
import com.aipay.app.service.NotificationCollectorService;


import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.math.BigDecimal;
import java.security.MessageDigest;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import okhttp3.MediaType;
import okhttp3.RequestBody;

public class Utils {


    public    static Gson   singleGson=new Gson();


    /***
     *用于json格式请求，
     */
    public static RequestBody getRequestBody(Map<String,Object>  map) {
        return    RequestBody.create(MediaType.parse("application/json;charset=utf-8"),singleGson.toJson(map));
    }

    public  static void toggleNotificationListenerService(Context  context) {
        LogUtils.i("从新绑定");
        PackageManager pm = context.getPackageManager();
        pm.setComponentEnabledSetting(new ComponentName(context, NotificationCollectorService.class),
                PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP);

        pm.setComponentEnabledSetting(new ComponentName(context, NotificationCollectorService.class),
                PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP);

    }




    public static boolean isNotificationListenerEnabled(Context context) {
        Set<String> packageNames = NotificationManagerCompat.getEnabledListenerPackages(context);
        if (packageNames.contains(context.getPackageName())) {
            return true;
        }
        return false;
    }


    /**
     * Check当前辅助服务是否启用
     *
     * @param serviceName serviceName
     * @return 是否启用
     */
    @SuppressLint("LongLogTag")
    public static boolean checkAccessibilityEnabled(String serviceName) {

        AccessibilityManager mAccessibilityManager = (AccessibilityManager) MyApplication.context.getSystemService(Context.ACCESSIBILITY_SERVICE);

        List<AccessibilityServiceInfo> accessibilityServices =
                mAccessibilityManager.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_GENERIC);
        for (AccessibilityServiceInfo info : accessibilityServices) {
            Log.e("checkAccessibilityEnabled", info.getId());
            if (info.getId().equals(serviceName)) {
                return true;
            }
        }
        return false;
    }

    private static boolean isMatch(String regex, String orginal) {
        if (orginal == null || orginal.trim().equals("")) {
            return false;
        }
        Pattern pattern = Pattern.compile(regex);
        Matcher isNum = pattern.matcher(orginal);
        return isNum.matches();
    }

    /**
     * 判断字符串是否为数字，包括整数和小数
     *
     * @param str
     * @return
     */
    public static boolean isNumeric(String str) {
        Pattern pattern = Pattern.compile("-?[0-9]+.?[0-9]+");
        Matcher isNum = pattern.matcher(str);
        if (!isNum.matches()) {
            return false;
        }
        return true;
    }

    /***
     *打开AccessibilityService权限
     */
    public static void openAccessibilityServiceSetting(Context context) {
        Intent intent = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
        context.startActivity(intent);
    }

    /***
     *打开NotificationListenerService权限
     */
    public static void openNotificationListenerServiceSetting(Context contex) {
        try {
            Intent intent;
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP_MR1) {
                intent = new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS);
            } else {
                intent = new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS");
            }
            contex.startActivity(intent);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }


    /***
     *强制取消状态栏信息
     */
    public static void cancelNotificationForce(Context context, int id, String tag, String packageName, String key) {
        LogUtils.i("已经强制删除第三方消息  begin ");
        NotificationManager manger = (NotificationManager) context.getSystemService(context.NOTIFICATION_SERVICE);

        manger.cancel(id);
        LogUtils.i("已经强制删除第三方消息  end");
    }


    public    static   String   getCurrentDate(){
         SimpleDateFormat   format = new SimpleDateFormat("yyyy-MM-dd");
         return format.format(new Date());

    }

    public   static    long  getLongTime(String  dateTime){
        SimpleDateFormat   format=new SimpleDateFormat("yyyy-MM-dd");

        try {
            return   format.parse(dateTime).getTime();
        } catch (ParseException e) {
            e.printStackTrace();
            return 0;
        }


    }

    public static void buildTestNotification(Context context, String title, String content, int id) {
        //获取NotificationManager实例
        LogUtils.i("buildTestNotification");
        NotificationManager notifyManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        LogUtils.i("buildNotification 2");

        //实例化NotificationCompat.Builde并设置相关属性
        NotificationCompat.Builder builder = new NotificationCompat.Builder(context)
                //设置小图标
                .setSmallIcon(R.mipmap.ic_launcher)
                //设置通知标题
                .setContentTitle(title)
                //设置通知内容
                .setContentText(content);
        LogUtils.i("buildNotification 3");
        notifyManager.notify(id, builder.build());
        LogUtils.i("buildNotification 4");
    }


    public static void buildNotification(Context context, String title, String content, int requestCode, int id) {
        LogUtils.i("buildNotification 1");
        Intent intentClick = new Intent(context, NotificationBroadcastReceiver.class);
        intentClick.setAction("notification_clicked");

        PendingIntent pendingIntentClick = PendingIntent.getBroadcast(context, requestCode, intentClick, 0);


        Uri defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(context)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle(title)
                .setContentText(content)
                .setSound(defaultSoundUri)
                .setContentIntent(pendingIntentClick);
        Notification notification = notificationBuilder.build();
        notification.flags = Notification.FLAG_ONGOING_EVENT; // 设置常驻 Flag

        NotificationManager notificationManager = (NotificationManager) context.getSystemService(context.NOTIFICATION_SERVICE);
        notificationManager.notify(id /* ID of notification */, notification);  //这就是那个type，相同的update，不同add
        LogUtils.i("buildNotification 2");
        LogUtils.i("notificationId  =  " + id);
    }


    public static String getDeviceId() {

        try {
            TelephonyManager telephonyManager = (TelephonyManager) MyApplication.context.getSystemService(Context.TELEPHONY_SERVICE);
            String deviceId = telephonyManager.getDeviceId();

            return deviceId;
        } catch (Exception e) {
            return "";
        }


    }


    /**
     * 获取应用详情页面intent
     *
     * @return
     */
    public static Intent getAppDetailSettingIntent() {
        Intent localIntent = new Intent();
        localIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        if (Build.VERSION.SDK_INT >= 9) {
            localIntent.setAction("android.settings.APPLICATION_DETAILS_SETTINGS");
            localIntent.setData(Uri.fromParts("package", MyApplication.context.getPackageName(), null));
        } else if (Build.VERSION.SDK_INT <= 8) {
            localIntent.setAction(Intent.ACTION_VIEW);
            localIntent.setClassName("com.android.settings", "com.android.settings.InstalledAppDetails");
            localIntent.putExtra("com.android.settings.ApplicationPkgName", MyApplication.context.getPackageName());
        }
        return localIntent;
    }

//    public synchronized static String getUUID(Context mContext) {
//
//
//        if (sID == null) {
//            File installation = new File(mContext.getFilesDir(), INSTALLATION);
//            try {
//                if (!installation.exists()) {
//                    writeInstallationFile(installation);
//                }
//                sID = readInstallationFile(installation);
//            } catch (Exception e) {
//                throw new RuntimeException(e);
//            }
//        }
//        return sID;
//    }

    private static String readInstallationFile(File installation) throws IOException {
        RandomAccessFile f = new RandomAccessFile(installation, "r");
        byte[] bytes = new byte[(int) f.length()];
        f.readFully(bytes);
        f.close();
        return new String(bytes);
    }

    private static void writeInstallationFile(File installation) throws IOException {
        FileOutputStream out = new FileOutputStream(installation);
        String id = UUID.randomUUID().toString();
        out.write(id.getBytes());
        out.close();
    }

    /***
     *获取当前网络类型
     */
    public static String getNetWorkType() {
        String strNetworkType = "UNKOWN";

        NetworkInfo networkInfo = ((ConnectivityManager) MyApplication.context.getSystemService(Context.CONNECTIVITY_SERVICE)).getActiveNetworkInfo();
        if (networkInfo != null && networkInfo.isConnected()) {
            if (networkInfo.getType() == ConnectivityManager.TYPE_WIFI) {
                strNetworkType = "WIFI";
            } else if (networkInfo.getType() == ConnectivityManager.TYPE_MOBILE) {
                String _strSubTypeName = networkInfo.getSubtypeName();

                //  Log.e("cocos2d-x", "Network getSubtypeName : " + _strSubTypeName);

                // TD-SCDMA   networkType is 17
                int networkType = networkInfo.getSubtype();
                switch (networkType) {
                    case TelephonyManager.NETWORK_TYPE_GPRS:
                    case TelephonyManager.NETWORK_TYPE_EDGE:
                    case TelephonyManager.NETWORK_TYPE_CDMA:
                    case TelephonyManager.NETWORK_TYPE_1xRTT:
                    case TelephonyManager.NETWORK_TYPE_IDEN: //api<8 : replace by 11
                        strNetworkType = "TYPE_2G";
                        break;
                    case TelephonyManager.NETWORK_TYPE_UMTS:
                    case TelephonyManager.NETWORK_TYPE_EVDO_0:
                    case TelephonyManager.NETWORK_TYPE_EVDO_A:
                    case TelephonyManager.NETWORK_TYPE_HSDPA:
                    case TelephonyManager.NETWORK_TYPE_HSUPA:
                    case TelephonyManager.NETWORK_TYPE_HSPA:
                    case TelephonyManager.NETWORK_TYPE_EVDO_B: //api<9 : replace by 14
                    case TelephonyManager.NETWORK_TYPE_EHRPD:  //api<11 : replace by 12
                    case TelephonyManager.NETWORK_TYPE_HSPAP:  //api<13 : replace by 15
                        strNetworkType = "TYPE_3G";
                        break;
                    case TelephonyManager.NETWORK_TYPE_LTE:    //api<11 : replace by 13
                        strNetworkType = "TYPE_4G";
                        break;
                    default:
                        // http://baike.baidu.com/item/TD-SCDMA 中国移动 联通 电信 三种3G制式
                        if (_strSubTypeName.equalsIgnoreCase("TD-SCDMA") || _strSubTypeName.equalsIgnoreCase("WCDMA") || _strSubTypeName.equalsIgnoreCase("CDMA2000")) {
                            strNetworkType = "TYPE_3G";
                        } else {
                            strNetworkType = _strSubTypeName;
                        }

                        break;
                }

                // Log.e("cocos2d-x", "Network getSubtype : " + Integer.valueOf(networkType).toString());
            }
        }
        return strNetworkType;
    }

    /***
     *获取版本名
     */
    public static String getVersionName() {
        PackageManager packageManager = MyApplication.context.getPackageManager();
        PackageInfo packageInfo;
        String versionName = "";
        try {
            packageInfo = packageManager.getPackageInfo(MyApplication.context.getPackageName(), 0);
            versionName = packageInfo.versionName;
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
            return "";
        }
        return versionName;
    }

    public static void showToash(String msg) {
        Toast.makeText(MyApplication.context, msg, Toast.LENGTH_SHORT).show();
    }

    public static String formatMoney(double money) {
        return new DecimalFormat("0.0000").format(money);
    }

    /***
     *监听支付，回调接口需要用到的签名
     */
    public static String getSign(BigDecimal money, String payChannel) {

        LogUtils.i("code = " + UserUtils.getUserBean().code);
        LogUtils.i("appSecret = " + UserUtils.getUserBean().appSecret);


        StringBuilder signSB = new StringBuilder();

        //BigDecimal payAmount =  BigDecimal.valueOf(money).divide(BigDecimal.valueOf(1L),2, RoundingMode.HALF_UP);

        signSB.append("merchantCode=").append(UserUtils.getUserBean().code)
                .append("&payAmount=").append(String.valueOf(money))
                .append("&payChannel=").append(payChannel)
                .append("&appSecret=").append(UserUtils.getUserBean().appSecret);

        LogUtils.i("sign = " + signSB.toString());

        //String digestUtilsString = DigestUtils.md5Hex(signSB.toString());
        // LogUtils.i("digestUtilsString = " + digestUtilsString);
        return MD5Encode(signSB.toString(), "utf-8", true);

    }

//---------md5加密算法begin------------

    /**
     * 16进制的字符数组
     */
    private final static String[] hexDigits = {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "a", "b", "c", "d",
            "e", "f"};

    /**
     * @param source    需要加密的原字符串
     * @param encoding  指定编码类型
     * @param uppercase 是否转为大写字符串
     * @return
     */
    public static String MD5Encode(String source, String encoding, boolean uppercase) {
        String result = null;
        try {
            result = source;
            // 获得MD5摘要对象
            MessageDigest messageDigest = MessageDigest.getInstance("MD5");
            // 使用指定的字节数组更新摘要信息
            messageDigest.update(result.getBytes(encoding));
            // messageDigest.digest()获得16位长度
            result = byteArrayToHexString(messageDigest.digest());

        } catch (Exception e) {
            e.printStackTrace();
        }
        return uppercase ? result.toUpperCase() : result;
    }

    /**
     * 转换字节数组为16进制字符串
     *
     * @param bytes 字节数组
     * @return
     */
    private static String byteArrayToHexString(byte[] bytes) {
        StringBuilder stringBuilder = new StringBuilder();
        for (byte tem : bytes) {
            stringBuilder.append(byteToHexString(tem));
        }
        return stringBuilder.toString();
    }

    /**
     * 转换byte到16进制
     *
     * @param b 要转换的byte
     * @return 16进制对应的字符
     */
    private static String byteToHexString(byte b) {
        int n = b;
        if (n < 0) {
            n = 256 + n;
        }
        int d1 = n / 16;
        int d2 = n % 16;
        return hexDigits[d1] + hexDigits[d2];
    }

    public static String getSupplementSign(String   code) {

        StringBuilder  stringBuilder  =new StringBuilder();
        stringBuilder.append("code=").append(code)
                .append("&merchantCode=").append(UserUtils.getUserBean().code)
                .append("&appSecret=").append(UserUtils.getUserBean().appSecret);

        LogUtils.i("stringBuilder.toString = "+stringBuilder.toString());

        return MD5Encode(stringBuilder.toString(),"utf-8",true);
    }

//----------md5加密算法end-----------

}
