package com.aipay.app.net;

import android.support.v4.util.ArrayMap;

import com.aipay.app.Constant;

import org.reactivestreams.Publisher;

import java.util.concurrent.TimeUnit;

import io.reactivex.Flowable;
import io.reactivex.FlowableTransformer;
import io.reactivex.Observable;
import io.reactivex.ObservableSource;
import io.reactivex.ObservableTransformer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;
import okhttp3.OkHttpClient;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;


public class NetRxFactory {

    private static NetRxFactory instance;

    private ArrayMap<String, Retrofit> retrofitMap = new ArrayMap<>();

    private NetRxFactory() {
    }

    public static NetRxFactory getInstance() {
        if (instance == null) {
            synchronized (NetRxFactory.class) {
                if (instance == null) {
                    instance = new NetRxFactory();
                }
            }
        }
        return instance;
    }

//    public static <T> Observable.Transformer<T, T> applySchedulers() {
//        return (Observable.Transformer<T, T>) new Observable.Transformer() {
//            @Override
//            public Object call(Object observable) {
//
//                return ((Observable) observable).subscribeOn(Schedulers.io())
//                        .observeOn(AndroidSchedulers.mainThread());
//            }
//        };
//    }

    /**
     * Observable切换线程
     * 跟compose()配合使用,比如ObservableUtils.wrap(obj).compose(toMain())
     */
    public static <T> ObservableTransformer<T, T> toMain() {

        return new ObservableTransformer<T, T>() {

            @Override
            public ObservableSource<T> apply(Observable<T> upstream) {
                return upstream.subscribeOn(Schedulers.io())
                        .observeOn(AndroidSchedulers.mainThread());
            }
        };
    }

    /***
     *Flowable切换线程
     */
    public static <T> FlowableTransformer<T, T> toMainFlowable() {

        return new FlowableTransformer<T, T>() {

            @Override
            public Publisher<T> apply(Flowable<T> upstream) {
                return upstream.subscribeOn(Schedulers.io())
                        .observeOn(AndroidSchedulers.mainThread());
            }
        };
    }


    public static <T> T getServer(Class<T> clazz) {
        return getInstance().getRetrofit(false, Constant.URL_BASE + "/")
                .create(clazz);
    }

    /**
     * isAddInterceptor请求头是否添加拦截器
     */
    public Retrofit getRetrofit(boolean isAddInterceptor, String baseUrl) {

        String key = baseUrl + (isAddInterceptor ? "" : "notoken");

        Retrofit retrofit = retrofitMap.get(key);

        if (retrofit != null) {
            return retrofit;
        }

        OkHttpClient.Builder builder = new OkHttpClient.Builder();


        builder.addInterceptor(new CustomInterceptor());


        //设置超时
        builder.connectTimeout(15, TimeUnit.SECONDS);
        builder.readTimeout(20, TimeUnit.SECONDS);
        builder.writeTimeout(20, TimeUnit.SECONDS);
        //错误重连
        builder.retryOnConnectionFailure(true);

        OkHttpClient client = builder.build();

        retrofit = new Retrofit.Builder()
                .baseUrl(baseUrl)
                .client(client)
                .addConverterFactory(GsonConverterFactory.create())
                .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                .build();

        retrofitMap.put(key, retrofit);
        return retrofit;

    }

}
