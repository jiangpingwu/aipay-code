package com.aipay.app.mvp.presenter;

import com.aipay.app.event.SupplementEvent;



public interface IOrderPresenter  extends   IBasePresenter {
    void getOrderList(boolean isRefreshing);

    void supplementOrder(SupplementEvent event);

    public void getOrderListCondition(final boolean isRefreshing);


    public    void    getOrderListBySearch(String  beginDateTime,String  endDateTime,String merchantCode,
                                           String payChannel,String payStatus);
}
