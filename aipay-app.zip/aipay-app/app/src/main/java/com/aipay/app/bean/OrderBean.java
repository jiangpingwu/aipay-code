package com.aipay.app.bean;

import com.google.gson.annotations.SerializedName;

import java.util.List;


public class OrderBean   {


    /**
     * status : 1
     * msg : 操作成功
     * data : {"pageNo":1,"pageSize":10,"totalPage":2419,"totalCount":24181,"content":[{"merchantCode":"ZPM_TEST81","code":"ZPO1_1120030769918923R6058","outTradeNo":"76de597b-eb9b-4c72-b045-48f8776aba32","totalAmount":89,"payAmount":89,"subject":"测试商品","body":"一个普通的测试商品","payStatus":"UNPAY","payStatusName":"未支付","payChannel":"WECHAT_CODE","payChannelName":"微信收款","createDateTime":"2018-04-26 13:42:31","payDateTime":null},{"merchantCode":"ZPM_TEST81","code":"ZPO1_1120030855124212R8392","outTradeNo":"c9c9befa-a4fc-4b42-896a-78102b9fba65","totalAmount":62,"payAmount":62,"subject":"测试商品","body":"一个普通的测试商品","payStatus":"UNPAY","payStatusName":"未支付","payChannel":"WECHAT_CODE","payChannelName":"微信收款","createDateTime":"2018-04-26 13:42:31","payDateTime":null},{"merchantCode":"ZPM_TEST81","code":"ZPO1_1120029928002596R9958","outTradeNo":"89ed1588-7785-4498-9e7f-c9dc79634b84","totalAmount":14,"payAmount":14,"subject":"测试商品","body":"一个普通的测试商品","payStatus":"UNPAY","payStatusName":"未支付","payChannel":"WECHAT_CODE","payChannelName":"微信收款","createDateTime":"2018-04-26 13:42:30","payDateTime":null},{"merchantCode":"ZPM_TEST81","code":"ZPO1_1120030020089163R2490","outTradeNo":"098ea665-2876-432a-afc6-2bbabde5380f","totalAmount":71,"payAmount":71,"subject":"测试商品","body":"一个普通的测试商品","payStatus":"UNPAY","payStatusName":"未支付","payChannel":"WECHAT_CODE","payChannelName":"微信收款","createDateTime":"2018-04-26 13:42:30","payDateTime":null},{"merchantCode":"ZPM_TEST81","code":"ZPO1_1120030107953779R4122","outTradeNo":"2009c970-eb47-42bc-8472-9d6eac6f8932","totalAmount":15,"payAmount":15,"subject":"测试商品","body":"一个普通的测试商品","payStatus":"UNPAY","payStatusName":"未支付","payChannel":"WECHAT_CODE","payChannelName":"微信收款","createDateTime":"2018-04-26 13:42:30","payDateTime":null},{"merchantCode":"ZPM_TEST81","code":"ZPO1_1120030192505074R4693","outTradeNo":"4d3cdd95-152e-463c-818e-860fe1c15c6d","totalAmount":98,"payAmount":98,"subject":"测试商品","body":"一个普通的测试商品","payStatus":"UNPAY","payStatusName":"未支付","payChannel":"WECHAT_CODE","payChannelName":"微信收款","createDateTime":"2018-04-26 13:42:30","payDateTime":null},{"merchantCode":"ZPM_TEST81","code":"ZPO1_1120030278977051R4751","outTradeNo":"b3a22b10-dbab-4733-bd11-0eeee8c8e18e","totalAmount":59,"payAmount":59,"subject":"测试商品","body":"一个普通的测试商品","payStatus":"UNPAY","payStatusName":"未支付","payChannel":"WECHAT_CODE","payChannelName":"微信收款","createDateTime":"2018-04-26 13:42:30","payDateTime":null},{"merchantCode":"ZPM_TEST81","code":"ZPO1_1120030591314300R1361","outTradeNo":"e6f64750-9c0d-40cf-b9c5-bc5808649d66","totalAmount":83,"payAmount":83,"subject":"测试商品","body":"一个普通的测试商品","payStatus":"UNPAY","payStatusName":"未支付","payChannel":"WECHAT_CODE","payChannelName":"微信收款","createDateTime":"2018-04-26 13:42:30","payDateTime":null},{"merchantCode":"ZPM_TEST81","code":"ZPO1_1120030686781088R6578","outTradeNo":"9d9b08fc-ea65-4912-8535-da81e7fce8fd","totalAmount":13,"payAmount":13,"subject":"测试商品","body":"一个普通的测试商品","payStatus":"UNPAY","payStatusName":"未支付","payChannel":"WECHAT_CODE","payChannelName":"微信收款","createDateTime":"2018-04-26 13:42:30","payDateTime":null},{"merchantCode":"ZPM_TEST81","code":"ZPO1_1120029410495789R3369","outTradeNo":"8d1a7602-c5b6-473d-bc7c-55c0cd2db44a","totalAmount":46,"payAmount":46,"subject":"测试商品","body":"一个普通的测试商品","payStatus":"UNPAY","payStatusName":"未支付","payChannel":"WECHAT_CODE","payChannelName":"微信收款","createDateTime":"2018-04-26 13:42:29","payDateTime":null}]}
     */


        /**
         * pageNo : 1
         * pageSize : 10
         * totalPage : 2419
         * totalCount : 24181
         * content : [{"merchantCode":"ZPM_TEST81","code":"ZPO1_1120030769918923R6058","outTradeNo":"76de597b-eb9b-4c72-b045-48f8776aba32","totalAmount":89,"payAmount":89,"subject":"测试商品","body":"一个普通的测试商品","payStatus":"UNPAY","payStatusName":"未支付","payChannel":"WECHAT_CODE","payChannelName":"微信收款","createDateTime":"2018-04-26 13:42:31","payDateTime":null},{"merchantCode":"ZPM_TEST81","code":"ZPO1_1120030855124212R8392","outTradeNo":"c9c9befa-a4fc-4b42-896a-78102b9fba65","totalAmount":62,"payAmount":62,"subject":"测试商品","body":"一个普通的测试商品","payStatus":"UNPAY","payStatusName":"未支付","payChannel":"WECHAT_CODE","payChannelName":"微信收款","createDateTime":"2018-04-26 13:42:31","payDateTime":null},{"merchantCode":"ZPM_TEST81","code":"ZPO1_1120029928002596R9958","outTradeNo":"89ed1588-7785-4498-9e7f-c9dc79634b84","totalAmount":14,"payAmount":14,"subject":"测试商品","body":"一个普通的测试商品","payStatus":"UNPAY","payStatusName":"未支付","payChannel":"WECHAT_CODE","payChannelName":"微信收款","createDateTime":"2018-04-26 13:42:30","payDateTime":null},{"merchantCode":"ZPM_TEST81","code":"ZPO1_1120030020089163R2490","outTradeNo":"098ea665-2876-432a-afc6-2bbabde5380f","totalAmount":71,"payAmount":71,"subject":"测试商品","body":"一个普通的测试商品","payStatus":"UNPAY","payStatusName":"未支付","payChannel":"WECHAT_CODE","payChannelName":"微信收款","createDateTime":"2018-04-26 13:42:30","payDateTime":null},{"merchantCode":"ZPM_TEST81","code":"ZPO1_1120030107953779R4122","outTradeNo":"2009c970-eb47-42bc-8472-9d6eac6f8932","totalAmount":15,"payAmount":15,"subject":"测试商品","body":"一个普通的测试商品","payStatus":"UNPAY","payStatusName":"未支付","payChannel":"WECHAT_CODE","payChannelName":"微信收款","createDateTime":"2018-04-26 13:42:30","payDateTime":null},{"merchantCode":"ZPM_TEST81","code":"ZPO1_1120030192505074R4693","outTradeNo":"4d3cdd95-152e-463c-818e-860fe1c15c6d","totalAmount":98,"payAmount":98,"subject":"测试商品","body":"一个普通的测试商品","payStatus":"UNPAY","payStatusName":"未支付","payChannel":"WECHAT_CODE","payChannelName":"微信收款","createDateTime":"2018-04-26 13:42:30","payDateTime":null},{"merchantCode":"ZPM_TEST81","code":"ZPO1_1120030278977051R4751","outTradeNo":"b3a22b10-dbab-4733-bd11-0eeee8c8e18e","totalAmount":59,"payAmount":59,"subject":"测试商品","body":"一个普通的测试商品","payStatus":"UNPAY","payStatusName":"未支付","payChannel":"WECHAT_CODE","payChannelName":"微信收款","createDateTime":"2018-04-26 13:42:30","payDateTime":null},{"merchantCode":"ZPM_TEST81","code":"ZPO1_1120030591314300R1361","outTradeNo":"e6f64750-9c0d-40cf-b9c5-bc5808649d66","totalAmount":83,"payAmount":83,"subject":"测试商品","body":"一个普通的测试商品","payStatus":"UNPAY","payStatusName":"未支付","payChannel":"WECHAT_CODE","payChannelName":"微信收款","createDateTime":"2018-04-26 13:42:30","payDateTime":null},{"merchantCode":"ZPM_TEST81","code":"ZPO1_1120030686781088R6578","outTradeNo":"9d9b08fc-ea65-4912-8535-da81e7fce8fd","totalAmount":13,"payAmount":13,"subject":"测试商品","body":"一个普通的测试商品","payStatus":"UNPAY","payStatusName":"未支付","payChannel":"WECHAT_CODE","payChannelName":"微信收款","createDateTime":"2018-04-26 13:42:30","payDateTime":null},{"merchantCode":"ZPM_TEST81","code":"ZPO1_1120029410495789R3369","outTradeNo":"8d1a7602-c5b6-473d-bc7c-55c0cd2db44a","totalAmount":46,"payAmount":46,"subject":"测试商品","body":"一个普通的测试商品","payStatus":"UNPAY","payStatusName":"未支付","payChannel":"WECHAT_CODE","payChannelName":"微信收款","createDateTime":"2018-04-26 13:42:29","payDateTime":null}]
         */

        @SerializedName("pageNo")
        public int pageNo;
        @SerializedName("pageSize")
        public int pageSize;
        @SerializedName("totalPage")
        public int totalPage;
        @SerializedName("totalCount")
        public int totalCount;
        @SerializedName("content")
        public List<ContentBean> content;



}
