package com.aipay.app.mvp.view;

import com.aipay.app.bean.ContentBean;
import com.aipay.app.bean.OrderItemBean;

import java.util.List;



public interface IOrderView  extends   IBaseView {
    void setRefreshing(boolean isRefreshing);

    void setDataloadStatus(boolean isCompleteLoad);

    void addData(List<ContentBean> orderList, boolean isRefreshing);

    void supplementOrderSuccess(String   platformNum);

    void addDataCondition(List<OrderItemBean> listBeans, boolean isRefreshing);
}
