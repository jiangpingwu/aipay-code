package com.aipay.app.net;

import com.aipay.app.utils.Utils;
import com.aipay.app.bean.ResponseBean;

public abstract class ResponseSub<BEAN> extends BaseSubscriber<ResponseBean<BEAN>> {

    public void onNotOneOrError() {

    }

    public abstract void onOneNext(BEAN bean);


    public void onNotOneNext(BEAN data) {

    }

    @Override
    public void onCustomNext(ResponseBean<BEAN> bean) {
        if ("1".equals(bean.status)) {
            onOneNext(bean.data);
        } else {
            Utils.showToash(bean.msg);
            onNotOneNext(bean.data);
            onNotOneOrError();
        }
    }


    @Override
    public void onError(Throwable e) {
        super.onError(e);
        onNotOneOrError();
    }

    @Override
    public void onCustomError() {

    }
}
