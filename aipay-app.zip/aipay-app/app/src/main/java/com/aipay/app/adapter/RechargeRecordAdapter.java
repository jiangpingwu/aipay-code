package com.aipay.app.adapter;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.aipay.app.R;
import com.aipay.app.bean.RechargeRecordItemBean;



public class RechargeRecordAdapter   extends BaseQuickAdapter<RechargeRecordItemBean,BaseViewHolder> {
    public RechargeRecordAdapter( ) {
        super(R.layout.item_recharge_record);
    }

    @Override
    protected void convert(BaseViewHolder helper, RechargeRecordItemBean item) {

        helper.setText(R.id.code,"流水编号:"+item.code);
        helper.setText(R.id.money,"金额:"+item.amount);
        helper.setText(R.id.channel,"充值渠道:"+item.rechargeChannelName);
        helper.setText(R.id.status,"充值状态:"+item.rechargeStatusName);


        helper.setText(R.id.time,"充值时间:"+item.createDateTime);
    }
}
