package com.aipay.app.mvp.view;



public interface IBaseFragView   extends   IBaseView{
}
