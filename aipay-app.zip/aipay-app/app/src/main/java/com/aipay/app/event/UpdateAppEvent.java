package com.aipay.app.event;


public class UpdateAppEvent {

    public    String    appPath;

    public    UpdateAppEvent(String   appPath){
        this.appPath= appPath ;
    }

}
