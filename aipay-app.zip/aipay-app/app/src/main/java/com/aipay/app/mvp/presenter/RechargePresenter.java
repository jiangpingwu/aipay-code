package com.aipay.app.mvp.presenter;

import com.aipay.app.Constant;
import com.aipay.app.bean.RechargeBean;
import com.aipay.app.bean.ResponseBean;
import com.aipay.app.mvp.view.IRechargeView;
import com.aipay.app.net.APIService;
import com.aipay.app.net.NetRxFactory;
import com.aipay.app.net.ResponseSub;
import com.aipay.app.utils.PayUtils;
import com.aipay.app.utils.UserUtils;
import com.aipay.app.utils.Utils;


public class RechargePresenter  extends   BaseFragPresenter<IRechargeView> implements IRechargePresenter  {
    public RechargePresenter(IRechargeView view) {
        super(view);
    }

    @Override
    public void rechargeNow(final String payChannel) {

        if ("".equals(payChannel)){
            Utils.showToash("请选择支付方式");
            return;
        }

         double    money=    view.getMoney();

         if (0==money){
             Utils.showToash("请输入数字格式的金额");
             return;
         }
        NetRxFactory.getServer(APIService.class).recharge(UserUtils.getToken(),
                getAppId(payChannel),getPlatform(payChannel),getPlatform(payChannel)+"_APP",money)
        .compose(view.getLifecycleProvide().<ResponseBean<RechargeBean>>bindToLifecycle())
        .compose(NetRxFactory.<ResponseBean<RechargeBean>>toMain())
        .subscribe(new ResponseSub<RechargeBean>() {
            @Override
            public void onOneNext(RechargeBean rechargeBean) {
                if (isALIPAY(payChannel)){
                    PayUtils.getInstance().alipay(view.getActivity(),rechargeBean.requestInfoStr);
                }else {
                    PayUtils.getInstance().wxpay(view.getActivity(),rechargeBean);
                }

            }
        });



    }

    private  String   getPlatform(String  paychannel){
        if (isALIPAY(paychannel)){
            return   "ALIPAY";
        }else{
            return "WECHAT";
        }
    }





    private   String   getAppId(String   paychannel){
        if (isALIPAY(paychannel)){
            return   Constant.ALIPAY_APP_ID;
        }else {
            return Constant.WXPAY_APP_ID;
        }
    }

    private   boolean   isALIPAY(String   paychannel){
        return   paychannel.equals(Constant.PAY_CHANNEL_ALIPAY);
    }
}
