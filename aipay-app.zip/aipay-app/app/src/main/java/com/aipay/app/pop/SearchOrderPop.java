package com.aipay.app.pop;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.PopupWindow;
import android.widget.Spinner;
import android.widget.TextView;

import com.bruce.pickerview.popwindow.DatePickerPopWin;
import com.aipay.app.Constant;
import com.aipay.app.utils.LogUtils;
import com.aipay.app.R;
import com.aipay.app.utils.Utils;

import java.util.Calendar;

import static android.view.ViewGroup.LayoutParams.MATCH_PARENT;
import static android.view.ViewGroup.LayoutParams.WRAP_CONTENT;


public class SearchOrderPop extends PopupWindow implements View.OnClickListener {
    private Spinner searchOrderStatus;
    private Spinner searchPayChannel;

    TextView beginTime, endTime;
    public   static   String  beginDateTime,endDateTime;
    public   static   int     payChannelNum =-1,payStatusNum = -1;

    Context context;
    View rootView;
    private SearchOrderListener listener;

    public interface SearchOrderListener {
        void clickSearch(String payChannel, String payStatus, String beginDateTime, String endDateTime);
    }

    public SearchOrderPop(Context context, SearchOrderListener listener) {
        this.context = context;
        this.listener = listener;
        rootView = LayoutInflater.from(context).inflate(R.layout.pop_search_order, null);
        setContentView(rootView);
        setWidth(MATCH_PARENT);
        setHeight(WRAP_CONTENT);

        setBackgroundDrawable(new ColorDrawable(Color.WHITE));
        setOutsideTouchable(true);
        setTouchable(true);


        searchPayChannel = (Spinner) rootView.findViewById(R.id.searchPayChannel);

        searchOrderStatus = (Spinner) rootView.findViewById(R.id.searchOrderStatus);

        beginTime = (TextView) rootView.findViewById(R.id.beginTime);

        endTime = (TextView) rootView.findViewById(R.id.endTime);

        rootView.findViewById(R.id.beginTimeLL).setOnClickListener(this);
        rootView.findViewById(R.id.endTimeLL).setOnClickListener(this);

        rootView.findViewById(R.id.beginSearch).setOnClickListener(this);

        if (payStatusNum!=-1){
            searchOrderStatus.setSelection(payStatusNum);
        }
        if (payChannelNum!=-1){
            searchPayChannel.setSelection(payChannelNum);
        }

        if (!TextUtils.isEmpty(beginDateTime)){
            beginTime.setText(beginDateTime);
        }

        if (!TextUtils.isEmpty(endDateTime)){
            endTime.setText(endDateTime);
        }
    }

    public    static   void   clearSearchData(){
         payChannelNum=-1;
         payStatusNum=-1;
        beginDateTime=null;
        endDateTime=null;
    }


    @Override
    public void dismiss() {
        super.dismiss();
        rootView = null;
        context = null;
    }

    @Override
    public void onClick(final View clickView) {

        switch (clickView.getId()) {
            case R.id.beginTimeLL:
            case R.id.endTimeLL:
                showDialog(clickView);
                break;

            case R.id.beginSearch:
                if (listener != null) {
                    String payChannel = getSearchPayChannelSelect();
                   String  payStatus = getOrderStatus();
                     beginDateTime = beginTime.getText().toString().trim();
                     endDateTime = endTime.getText().toString().trim();

                     payChannelNum=  searchPayChannel.getSelectedItemPosition()  ;
                     payStatusNum= searchOrderStatus.getSelectedItemPosition() ;

                     String   clickBeginTime="";
                     String   clickEndTime="";
                    if (TextUtils.isEmpty(beginDateTime) && TextUtils.isEmpty(endDateTime)) {
                        beginDateTime = "";
                        endDateTime = "";
                    } else {
                        if (TextUtils.isEmpty(beginDateTime) && !TextUtils.isEmpty(endDateTime)) {
                            Utils.showToash("请选择开始时间");
                            return;
                        } else if (TextUtils.isEmpty(endDateTime) && !TextUtils.isEmpty(beginDateTime)) {
                            Utils.showToash("请选择结束时间");
                            return;
                        }
                        long beginLong = Utils.getLongTime(beginDateTime);
                        long endLong = Utils.getLongTime(endDateTime);
                        //long    tempTime=   (long) (1000 * 60 * 60 *24 *30);
                        LogUtils.i("beginLong = " + beginLong);
                        LogUtils.i("endLong   = " + endLong);
                        LogUtils.i("endLong-beginLong= " + (endLong - beginLong));
                        LogUtils.i("间隔天数=          " + (endLong - beginLong) / (1000 * 60 * 60 * 24));
                        if (beginLong > endLong) {
                            Utils.showToash("开始时间不得大于结束时间");
                            return;
                        } else if ((endLong - beginLong) / (1000 * 60 * 60 * 24) > 30) {
                            Utils.showToash("搜索时间的区间不得超过一个月");
                            return;
                        }

                         clickBeginTime=  beginDateTime + " 00:00:00";
                          clickEndTime= endDateTime + " 23:59:59";
                    }


                    listener.clickSearch(payChannel, payStatus, clickBeginTime, clickEndTime);
                    dismiss();
                }
                break;
        }
    }

    /***
     *['UNPAY', 'CANCEL', 'PAYED', 'OVERTIME', 'COMPLETED', 'FAILURE']
     *
     *   <item>未选择</item>
     <item>未支付</item>
     <item>支付取消</item>
     <item>已支付</item>
     <item>已超时</item>
     <item>已完成</item>
     <item>支付失败</item>
     */
    public String getOrderStatus() {

        String payStatus = searchOrderStatus.getSelectedItem().toString().trim();
        if ("未选择".equals(payStatus)) {
            payStatus = "";
        } else if ("未支付".equals(payStatus)) {
            payStatus = "UNPAY";
        } else if ("支付取消".equals(payStatus)) {
            payStatus = "CANCEL";
        } else if ("已支付".equals(payStatus)) {
            payStatus = "PAYED";
        } else if ("已超时".equals(payStatus)) {
            payStatus = "OVERTIME";
        } else if ("已完成".equals(payStatus)) {
            payStatus = "COMPLETED";

        } else if ("支付失败".equals(payStatus)) {
            payStatus = "FAILURE";
        }

        return payStatus;
    }

    public String getSearchPayChannelSelect() {
        String selectString = searchPayChannel.getSelectedItem().toString().trim();

        if ("微信".equals(selectString)) {
            selectString = Constant.PAY_CHANNEL_WX;
        } else if ("支付宝".equals(selectString)) {
            selectString = Constant.PAY_CHANNEL_ALIPAY;
        } else if ("未选择".equals(selectString)) {
            selectString = "";
        }


        return selectString;
    }


    private void showDialog(final View clickView) {
       Calendar   calendar=     Calendar.getInstance();

       LogUtils.i("Utils.getCurrentDate()= "+Utils.getCurrentDate());
       LogUtils.i("年份 = "+calendar.get(Calendar.YEAR));

        new DatePickerPopWin.Builder(context, new DatePickerPopWin.OnDatePickedListener() {
            @Override
            public void onDatePickCompleted(int year, int month, int day, String dateDesc) {

                switch (clickView.getId()) {
                    case R.id.beginTimeLL:
                        beginTime.setText(dateDesc);
                        break;

                    case R.id.endTimeLL:
                        endTime.setText(dateDesc);
                        break;
                }
            }
        }).textConfirm("确定") //text of confirm button
                .textCancel("取消") //text of cancel button
                .btnTextSize(16) // button text size
                .viewTextSize(30) // pick view text size
                .colorCancel(Color.parseColor("#999999")) //color of cancel button
                .colorConfirm(Color.parseColor("#009900"))//color of confirm button
                .minYear(2018) //min year in loop
                .maxYear(2040) // max year in loop
                .showDayMonthYear(true) // shows like dd mm yyyy (default is false)
                .dateChose(Utils.getCurrentDate()) // date chose when init popwindow
                .build().showPopWin((Activity) context);


//        DatePickDialog dialog = new DatePickDialog(context);
//        //设置上下年分限制
//        dialog.setYearLimt(5);
//        //设置标题
//        dialog.setTitle("选择时间");
//        //设置类型
//        dialog.setType(DateType.TYPE_ALL);
//        //设置消息体的显示格式，日期格式
//        dialog.setMessageFormat("yyyy-MM-dd");
//        //设置选择回调
//        dialog.setOnChangeLisener(null);
//        //设置点击确定按钮回调
//        dialog.setOnSureLisener(new OnSureLisener() {
//            @Override
//            public void onSure(Date date) {
//                String dateString = new SimpleDateFormat("yyyy-MM-dd").format(date);
//                switch (clickView.getId()) {
//                    case R.id.beginTimeLL:
//                        beginTime.setText(dateString);
//                        break;
//
//                    case R.id.endTimeLL:
//                        endTime.setText(dateString);
//                        break;
//                }
//            }
//        });
//        dialog.show();
    }
}
