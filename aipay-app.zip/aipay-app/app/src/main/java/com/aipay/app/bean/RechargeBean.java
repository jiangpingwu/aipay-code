package com.aipay.app.bean;

import com.google.gson.annotations.SerializedName;


public class RechargeBean {


    /**
     * code : ZPP1_942938627886502R1050
     * requestInfoStr : alipay_sdk=alipay-sdk-java-dynamicVersionNo&app_id=2018010801699662&biz_content=%7B%22body%22%3A%22%E6%89%8B%E7%BB%AD%E8%B4%B9%22%2C%22out_trade_no%22%3A%22ZPP1_942938627886502R1050%22%2C%22product_code%22%3A%22QUICK_MSECURITY_PAY%22%2C%22subject%22%3A%22%E8%B4%B9%E7%94%A8%22%2C%22timeout_express%22%3A%2230m%22%2C%22total_amount%22%3A%220.01%22%7D&charset=UTF-8&format=json&method=alipay.trade.app.pay&notify_url=http%3A%2F%2F59.37.85.222%3A18562%2Fskm-api%2Fout%2FcallbackForAlipay&sign=aH%2BuxG4uUVk6%2BO818TYVRhpDxXMoxwDYm0C%2FgKfbw03EZIDQ62vaHhKDQ6Yx27WiidAfRmbLXQ2CWZ7DwXxNcI1c%2FwoV4BixaMnbREypsckAFVIZ4SuaqixsZL0YcAieUuVAOXraixW9RQd0Te%2BgwwrE5ZG8kPwC9qq90yE4PF%2Ff8RwUNkZCW0asxPrqcfeOJbeDZTcM9uVpuGxnxo5YVmbOMBw9LuWnYWSB9osLak3i2ktfU4sSk7UJwxYfaDXP%2BS0N4Hyn97SNBnzDyRkB6szKKKydU18S2Q0FV%2FApM24ybJIebPvM2SlbBj0RzlSTg3UPheDWeMj9RmKQeZ31rw%3D%3D&sign_type=RSA2&timestamp=2018-05-10+14%3A30%3A34&version=1.0
     */

    @SerializedName("code")
    public String code;
    @SerializedName("requestInfoStr")
    public String requestInfoStr;


/***
*"appid": "wx36c5a1f890ea85d3",
 "partnerid": "1497305402",
 "prepayid": "wx10154853804873bc4f47949b0813408844",
 "packageStr": "Sign=WXPay",
 "noncestr": "caca6bb2d6e49ebaff81a0bf06f1b21b",
 "timestamp": "1525938489",
 "sign": "C542E39D3CBC54C654DF76CF4F1F27AC"
*/
    @SerializedName("appid")
    public String appid;

    @SerializedName("partnerid")
    public String partnerid;
    @SerializedName("prepayid")
    public String prepayid;
    @SerializedName("packageStr")
    public String packageStr;
    @SerializedName("noncestr")
    public String noncestr;
    @SerializedName("timestamp")
    public String timestamp;
    @SerializedName("sign")
    public String sign;
}
