package com.aipay.app.mvp.view;

import com.aipay.app.bean.RechargeRecordItemBean;

import java.util.List;



public interface IRechargeRecordView   extends   IBaseFragView{
    void addData(List<RechargeRecordItemBean> listBeans, boolean isRefreshing);

    void setRefreshing(boolean isRefreshing);
}
