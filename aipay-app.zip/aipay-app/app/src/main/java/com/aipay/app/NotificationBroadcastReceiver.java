package com.aipay.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class NotificationBroadcastReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
       // String data = intent.getStringExtra(Constant.CLICK_NOTIFICATION_TYPE);

       // LogUtils.i("data = "+data);



    }
}
