package com.aipay.app.fragment;

import android.animation.Animator;
import android.animation.ObjectAnimator;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.animation.BaseAnimation;
import com.aipay.app.R;
import com.aipay.app.SimpleDividerItemDecoration;
import com.aipay.app.adapter.RechargeRecordAdapter;
import com.aipay.app.bean.RechargeRecordItemBean;
import com.aipay.app.mvp.presenter.IRechargeRecordPresenter;
import com.aipay.app.mvp.presenter.RechargeRecordPresenter;
import com.aipay.app.mvp.view.IRechargeRecordView;

import java.util.List;

import butterknife.Bind;


public class RechargeRecordFragment extends BaseFragment<IRechargeRecordPresenter> implements
        IRechargeRecordView, SwipeRefreshLayout.OnRefreshListener, BaseQuickAdapter.RequestLoadMoreListener {
    @Bind(R.id.recycler)
    RecyclerView recyclerView;
    @Bind(R.id.swipeRefreshLayout)
    SwipeRefreshLayout swipeRefreshLayout;
    private RechargeRecordAdapter adapter;

    @Override
    protected void initView() {
        recyclerView.addItemDecoration(new SimpleDividerItemDecoration(getActivity(), 5));
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        adapter = new RechargeRecordAdapter();
        adapter.setEmptyView(View.inflate(getActivity(),R.layout.layout_order_empty,null));
        adapter.isFirstOnly(false);
        adapter.openLoadAnimation(new BaseAnimation() {
            @Override
            public Animator[] getAnimators(View view) {

                return new Animator[]{
                        ObjectAnimator.ofFloat(view, "scaleY", 1.0f, 0.9f, 1.0f),
                        ObjectAnimator.ofFloat(view, "scaleX", 1.0f, 0.9f, 1.0f),
                        ObjectAnimator.ofFloat(view, "alpha", 0.1f, 0.5f, 1.0f)
                };
            }
        });
        adapter.setOnLoadMoreListener(this);
        swipeRefreshLayout.setColorScheme(R.color.red_EE3D15);
        swipeRefreshLayout.setOnRefreshListener(this);


        recyclerView.setAdapter(adapter);
        onRefresh();
    }

    @Override
    protected IRechargeRecordPresenter getPresenter() {
        return new RechargeRecordPresenter(this);
    }

    @Override
    protected int getLayoutView() {
        return R.layout.layout_recycler;
    }


    @Override
    public void onRefresh() {
        presenter.getRechargeRecordList(true);
    }

    @Override
    public void onLoadMoreRequested() {
        presenter.getRechargeRecordList(false);
    }

    @Override
    public void addData(List<RechargeRecordItemBean> listBeans, boolean isRefreshing) {
        if (isRefreshing){
            adapter.setNewData(listBeans);
        }else {
            adapter.addData(listBeans);
        }

        if (listBeans.size()==0){
            adapter.loadMoreEnd();
        }else {
            adapter.loadMoreComplete();
        }
    }

    @Override
    public void setRefreshing(boolean isRefreshing) {
         swipeRefreshLayout.setRefreshing(isRefreshing);
    }
}
