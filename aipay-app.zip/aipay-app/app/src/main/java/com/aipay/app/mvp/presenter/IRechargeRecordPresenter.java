package com.aipay.app.mvp.presenter;



public interface IRechargeRecordPresenter   extends   IBaseFragPresenter{
    void getRechargeRecordList(boolean isRefreshing);
}
