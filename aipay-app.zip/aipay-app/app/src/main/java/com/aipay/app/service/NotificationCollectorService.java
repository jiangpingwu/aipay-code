package com.aipay.app.service;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.Message;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.support.annotation.RequiresApi;
import android.support.v4.app.NotificationCompat;
import android.text.TextUtils;
import com.aipay.app.R;
import com.aipay.app.Constant;
import com.aipay.app.utils.LogUtils;
import com.aipay.app.MyApplication;
import com.aipay.app.NotificationBroadcastReceiver;
import com.aipay.app.ObserverFactory;
import com.aipay.app.message.NotificationMsg;
import com.aipay.app.utils.UserUtils;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

@SuppressLint("OverrideAbstract")
@RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN_MR2)
public class NotificationCollectorService extends NotificationListenerService {

    private static final Lock sLock = new ReentrantLock();
    private   static  final   int   STOP_FOREGROUND=12;
    private Handler  NotificationHandler=new Handler(){
        @Override
        public void handleMessage(Message msg) {

            switch (msg.what){
                case  STOP_FOREGROUND:
                    stopForeground(true);
                    break;

                 default:
                     super.handleMessage(msg);
                     break;
            }


        }
    };


    @Override
    public void onCreate() {
        super.onCreate();
        LogUtils.i(getClass().getSimpleName() + "  onCreate");

        LogUtils.i("buildNotification 1");
        Intent intentClick = new Intent(this, NotificationBroadcastReceiver.class);
        intentClick.setAction("notification_clicked");

        PendingIntent pendingIntentClick = PendingIntent.getBroadcast(this, 0, intentClick, 0);


       // Uri defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(this)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle("aipay支付功能正常")
                .setContentText("请保持此通知栏常驻")
               // .setSound(defaultSoundUri)
                .setContentIntent(pendingIntentClick);
        Notification notification = notificationBuilder.build();
        notification.flags = Notification.FLAG_ONGOING_EVENT; // 设置常驻 Flag

      //  NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
      //  notificationManager.notify(0 /* ID of notification */, notification);  //这就是那个type，相同的update，不同add
        startForeground(Constant.NOTIFICATION_ID,notification);
        LogUtils.i("开启常驻通知栏");
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        LogUtils.i(getClass().getSimpleName() + "  onDestory");


    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        super.onStartCommand(intent, flags, startId);
        return   START_STICKY;
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        super.onNotificationPosted(sbn);

        LogUtils.i( getClass().getSimpleName()+"  onNotificationPosted");
        onPosted(sbn);

      //  Bundle bundle = sbn.getNotification().extras;
       // LogUtils.i(getClass().getSimpleName()+"   title= "+bundle.getString(Notification.EXTRA_TITLE));
      //  LogUtils.i(getClass().getSimpleName()+"  content = "+bundle.getString(Notification.EXTRA_TEXT));


    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    public final void onPosted(StatusBarNotification paramStatusBarNotification) {
        if (paramStatusBarNotification == null   || MyApplication.context  ==null  || UserUtils.getUserBean()==null ||  TextUtils.isEmpty(UserUtils.getToken())) {

            return;
        }

        if (paramStatusBarNotification.getNotification() == null) {

            return;
        }
        String str = paramStatusBarNotification.getPackageName();
        if (TextUtils.isEmpty(str)) {
            return;
        }

        NotificationMsg notificationMsg = ObserverFactory.getObserver(paramStatusBarNotification.getPackageName());

        if (notificationMsg != null) {
            LogUtils.i("notificationMsg!=null");
            sLock.lock();
            try {
                notificationMsg.setMessage(paramStatusBarNotification,this);

            } finally {
                sLock.unlock();
            }
        } else {
            LogUtils.i("notificationMsg==null");
        }

    }
}
