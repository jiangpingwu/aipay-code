package com.aipay.app.adapter;

import android.view.View;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.aipay.app.R;
import com.aipay.app.bean.OrderItemBean;
import com.aipay.app.event.SupplementEvent;

import org.greenrobot.eventbus.EventBus;



public class OrderAdapter   extends BaseQuickAdapter<OrderItemBean,BaseViewHolder> {



    public OrderAdapter() {
        super(R.layout.item_order_adapter);
    }


    protected void convert(BaseViewHolder helper, final OrderItemBean item) {
         helper.setText(R.id.sellerOrderNum,"商户订单号:"+item.outTradeNo);
         helper.setText(R.id.platformOrderNum,"平台订单号:"+item.code);
         helper.setText(R.id.allMoney,"订单金额:  ¥"+item.totalAmount.toString());
         helper.setText(R.id.realPaymount,"实际支付金额:  ¥"+item.payAmount.toString());
         helper.setText(R.id.payChannel,"支付渠道:"+item.payChannelName);
         helper.setText(R.id.orderTime,"下单时间:"+item.createDateTime);
         helper.setText(R.id.remark,"备注信息:"+item.remark);
         helper.setText(R.id.status,"订单状态:"+  (item.isSupplementing? "正在补单中" :item.payStatusName));
         helper.setGone(R.id.supplement, "UNPAY".equals(item.payStatus));

         if (item.isSupplementing){
             helper.setGone(R.id.supplement,false);
         }

         helper.setOnClickListener(R.id.supplement, new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                  //点击手动补单
                 EventBus.getDefault().post(new SupplementEvent(item.outTradeNo,item.code,0,item.code));
             }
         });
    }
}
