package com.aipay.app.mvp.presenter;



public interface IRechargePresenter  extends   IBaseFragPresenter {
    void rechargeNow(String payChannel);
}
