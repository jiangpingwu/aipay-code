package com.aipay.app.activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;

import com.trello.rxlifecycle2.LifecycleProvider;
import com.trello.rxlifecycle2.android.ActivityEvent;
import com.trello.rxlifecycle2.components.support.RxFragmentActivity;
import com.aipay.app.MyApplication;
import com.aipay.app.dialog.LoadingDialog;
import com.aipay.app.mvp.presenter.IBasePresenter;
import com.aipay.app.mvp.view.IBaseView;

import org.greenrobot.eventbus.EventBus;

import butterknife.ButterKnife;



public abstract class BaseActivity<PRESENTER extends IBasePresenter> extends RxFragmentActivity implements IBaseView {


    protected LoadingDialog pd;

    public static void actionStartDefault(Context context, Class clazz) {
        Intent intent = new Intent(context, clazz);

        context.startActivity(intent);
    }


    protected PRESENTER presenter;

    public Activity getActivity() {
        return this;
    }

    @Override
    public LifecycleProvider<ActivityEvent> getLifecycleProvide() {
        return this;
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
      //  Window window = getWindow();
        //隐藏标题栏
     //   requestWindowFeature(Window.FEATURE_NO_TITLE);
        //隐藏状态栏
        //定义全屏参数
        //int flag = WindowManager.LayoutParams.FLAG_FULLSCREEN;
        //设置当前窗体为全屏显示
       // window.setFlags(flag, flag);
        setContentView(getContentView());
        ButterKnife.bind(this);
        MyApplication.addActivity(this);
        if (isRegisterEventBus()) {
            EventBus.getDefault().register(this);
        }
        presenter = getPresenter();

        if (presenter != null) {
            presenter.onCreate();
        }
        initView();
    }

    /***
     *是否注册eventbus
     */
    protected boolean isRegisterEventBus() {
        return false;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        MyApplication.removeActivity(this);
        if (isRegisterEventBus()){
            EventBus.getDefault().unregister(this);
        }
        if (presenter != null) {
            presenter.onDestroy();
        }
    }

    protected abstract PRESENTER getPresenter();

    protected abstract void initView();

    protected abstract int getContentView();

    @Override
    public void showLoadDialog() {
        if (pd==null){
            pd=new LoadingDialog(this);
        }
        if (!pd.isShowing()){
            pd.show();
        }

    }

    @Override
    public void dismissLoadDialog() {
        if (pd!=null){
            pd.dismiss();
            pd=null;
        }
    }
}
