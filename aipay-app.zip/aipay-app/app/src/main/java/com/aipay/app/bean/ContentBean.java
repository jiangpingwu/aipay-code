package com.aipay.app.bean;

import com.google.gson.annotations.SerializedName;

import java.math.BigDecimal;


public class ContentBean {
    /**

     * code : ZPO1_1120030769918923R6058  平台订单号
     * outTradeNo : 76de597b-eb9b-4c72-b045-48f8776aba32   商户订单号
     * totalAmount : 89  订单金额
     * payAmount : 89  实际支付金额
     * subject : 测试商品    商品名字
     * body : 一个普通的测试商品  商品描述
     * payStatus : UNPAY     状态
     * payStatusName : 未支付   状态名称
     * payChannel : WECHAT_CODE  支付渠道
     * payChannelName : 微信收款   支付渠道名称
     * createDateTime : 2018-04-26 13:42:31  订单创建时间

     */

    @SerializedName("merchantCode")
    public String merchantCode;
    @SerializedName("code")
    public String code;
    @SerializedName("outTradeNo")
    public String outTradeNo;
    @SerializedName("totalAmount")
    public BigDecimal totalAmount;
    @SerializedName("payAmount")
    public BigDecimal payAmount;
    @SerializedName("subject")
    public String subject;
    @SerializedName("body")
    public String body;
    @SerializedName("payStatus")
    public String payStatus;
    @SerializedName("payStatusName")
    public String payStatusName;
    @SerializedName("payChannel")
    public String payChannel;
    @SerializedName("payChannelName")
    public String payChannelName;
    @SerializedName("createDateTime")
    public String createDateTime;
    @SerializedName("payDateTime")
    public Object payDateTime;
}
