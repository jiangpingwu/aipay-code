package com.aipay.app.activity;

import android.view.View;

import com.aipay.app.R;
import com.aipay.app.mvp.presenter.IBasePresenter;
import com.aipay.app.mvp.view.IBaseView;

import butterknife.OnClick;



public class AboutUsActivity   extends BaseActivity implements IBaseView{
    @Override
    protected IBasePresenter getPresenter() {
        return null;
    }

    @OnClick(R.id.comeBack)
    public   void   comeBack(View  view){
        finish();
    }

    @Override
    protected void initView() {

    }

    @Override
    protected int getContentView() {
        return  R.layout.activity_about_us;
    }
}
