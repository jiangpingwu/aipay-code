package com.aipay.app.dialog;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.support.annotation.NonNull;
import android.view.Gravity;
import android.view.ViewGroup;
import android.view.WindowManager;

import com.lsjwzh.widget.materialloadingprogressbar.CircleProgressBar;
import com.aipay.app.R;


public class LoadingDialog  extends Dialog {
    CircleProgressBar   progressBar;

    public LoadingDialog(@NonNull Context context) {
        super(context, R.style.loadingDialog);
        setContentView(R.layout.dialog_loading);
         progressBar  =    (CircleProgressBar)findViewById(R.id.progressBar);
        progressBar.setColorSchemeColors(Color.RED);
    }

    @Override
    public void show() {
        super.show();
        WindowManager.LayoutParams   layoutParams  =getWindow().getAttributes();

        layoutParams.gravity  = Gravity.BOTTOM;

        layoutParams.width = ViewGroup.LayoutParams.MATCH_PARENT;
        layoutParams.height = ViewGroup.LayoutParams.WRAP_CONTENT;

        getWindow().getDecorView().setPadding(0, 0, 0, 0);
        getWindow().setBackgroundDrawable(new ColorDrawable());
        getWindow().setAttributes(layoutParams);
    }
}
