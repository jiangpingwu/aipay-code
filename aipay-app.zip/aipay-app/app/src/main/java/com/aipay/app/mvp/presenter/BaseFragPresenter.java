package com.aipay.app.mvp.presenter;

import com.aipay.app.mvp.view.IBaseFragView;



public class BaseFragPresenter<VIEW   extends IBaseFragView>    implements  IBaseFragPresenter  {


    protected    VIEW   view;

    public     BaseFragPresenter(VIEW   view){
        this.view=view;
    }



    @Override
    public void onDestroyView() {
        view=null;
    }
}
