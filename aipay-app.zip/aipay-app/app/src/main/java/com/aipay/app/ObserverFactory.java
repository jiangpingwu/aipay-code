package com.aipay.app;

import com.aipay.app.message.AliPayMsg;
import com.aipay.app.message.NotificationMsg;
import com.aipay.app.message.WXMsg;
import com.aipay.app.utils.LogUtils;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class ObserverFactory {


    static final Map<String, Class<? extends NotificationMsg>> sPackageMap;

    static {
        HashMap localHashMap = new HashMap();
        localHashMap.put(Constant.WX_PACKAGE_NAME, WXMsg.class);
        //   localHashMap.put("com.tencent.mobileqq", KQQMessage.class);
        // localHashMap.put("com.unionpay", UniMessage.class);
        localHashMap.put(Constant.ALIPAY_PACKAGE_NAME, AliPayMsg.class);
        sPackageMap = Collections.unmodifiableMap(localHashMap);
    }

    public static NotificationMsg getObserver(String packageName) {

        LogUtils.i("packageName= "+packageName);

        try {

            if (sPackageMap.containsKey(packageName)) {
                return (NotificationMsg) ((Class) sPackageMap.get(packageName)).newInstance();
            } else {
                return null;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }


    }

}
