package com.aipay.app.event;


public class NotificationEvent {

    public     float   money;
    public     String     payChannel;
    public    NotificationEvent(float   money,String   payChannel){
          this.money=money;
          this.payChannel=payChannel;
    }

}
