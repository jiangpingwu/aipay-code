package com.aipay.app.bean;

import com.google.gson.annotations.SerializedName;

import java.math.BigDecimal;

public class OrderItemBean  {


    /**
     * body : string
     * code : string
     * createDateTime : 2018-05-02T01:33:08.640Z
     * outTradeNo : string
     * payAmount : 0
     * payChannel : ALIPAY_CODE
     * payChannelName : string
     * payStatus : UNPAY
     * payStatusName : string
     * remark : string
     * subject : string
     * totalAmount : 0
     */

    @SerializedName("body")
    public String body;
    @SerializedName("code")
    public String code;
    @SerializedName("createDateTime")
    public String createDateTime;
    @SerializedName("outTradeNo")
    public String outTradeNo;
    @SerializedName("payAmount")
    public BigDecimal payAmount;
    @SerializedName("payChannel")
    public String payChannel;
    @SerializedName("payChannelName")
    public String payChannelName;
    @SerializedName("payStatus")
    public String payStatus;
    @SerializedName("payStatusName")
    public String payStatusName;
    @SerializedName("remark")
    public String remark;
    @SerializedName("subject")
    public String subject;
    @SerializedName("totalAmount")
    public BigDecimal totalAmount;

    /***
    *是否正在补单中
    */
    public  boolean  isSupplementing=false;
}
