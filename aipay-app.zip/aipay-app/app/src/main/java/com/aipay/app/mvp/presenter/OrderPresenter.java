package com.aipay.app.mvp.presenter;

import android.support.v4.util.ArrayMap;
import android.text.TextUtils;

import com.aipay.app.Constant;
import com.aipay.app.utils.LogUtils;
import com.aipay.app.bean.OrderBean;
import com.aipay.app.bean.OrderItemBean;
import com.aipay.app.bean.ResponseBean;
import com.aipay.app.event.SupplementEvent;
import com.aipay.app.mvp.view.IOrderView;
import com.aipay.app.net.APIService;
import com.aipay.app.net.NetRxFactory;
import com.aipay.app.net.ResponseSub;
import com.aipay.app.utils.UserUtils;
import com.aipay.app.utils.Utils;

import java.util.List;
import java.util.concurrent.TimeUnit;



public class OrderPresenter extends BasePresenter<IOrderView> implements IOrderPresenter {

    private int pageNo = 0;

    private boolean canGetData = true, isCompleteLoad = false;


    private   String  beginDateTime,endDateTime,merchantCode,payChannel,payStatus;

    public OrderPresenter(IOrderView view) {
        super(view);
    }


    public    void    getOrderListBySearch(String  beginDateTime,String  endDateTime,String merchantCode,
                                           String payChannel,String payStatus){
         this.beginDateTime =beginDateTime;
         this.endDateTime=endDateTime;
         this.merchantCode=merchantCode;
         this.payChannel=payChannel;
         this.payStatus=payStatus;
         getOrderListCondition(true);
    }



    /***
     *根据条件查询
     * 订单查询对象 {
     beginDateTime (string, optional): 开始时间

     endDateTime (string, optional): 结束时间

     merchantCode (string, optional): 商户号

     pageNo (integer, optional): 当前页数,从1开始

     pageSize (integer, optional): 每页记录数

     payChannel (string, optional): 支付渠道
     = ['ALIPAY_CODE', 'WECHAT_CODE']

     payStatus (string, optional): 支付状态
     = ['UNPAY', 'CANCEL', 'PAYED', 'OVERTIME', 'COMPLETED', 'FAILURE']

     }
     */
    public void getOrderListCondition(final boolean isRefreshing) {
        if (!canGetData) {
            return;
        }
        if (isRefreshing) {
            pageNo = 0;
            isCompleteLoad = false;
        }
        canGetData = false;
        pageNo++;
        ArrayMap<String, Object> map = new ArrayMap<>();
        if (!TextUtils.isEmpty(beginDateTime)) {
            map.put("beginDateTime", beginDateTime);
        }
        if (!TextUtils.isEmpty(endDateTime)) {
            map.put("endDateTime", endDateTime);
        }
        if (!TextUtils.isEmpty(merchantCode)) {
            map.put("merchantCode", merchantCode);

        }
        if (!TextUtils.isEmpty(payChannel)) {
            map.put("payChannel", payChannel);
        }
        if (!TextUtils.isEmpty(payStatus)) {
            map.put("payStatus", payStatus);
        }


        map.put("pageNo", pageNo);
        map.put("pageSize", 10);

        LogUtils.i("beginDateTime = "+beginDateTime);
        LogUtils.i("endDateTime = "+endDateTime);
        LogUtils.i("merchantCode = "+merchantCode);
        LogUtils.i("payCannel = "+payChannel);
        LogUtils.i("payStatus =" +payStatus);
        LogUtils.i("pageNo = "+pageNo);
        LogUtils.i("pageSize = "+10);
        LogUtils.i("uniqueCode  = "+UserUtils.getToken());
        NetRxFactory.getServer(APIService.class).getOrderListCondition(UserUtils.getToken(), Utils.getRequestBody(map))
                .compose(view.getLifecycleProvide().<ResponseBean<List<OrderItemBean>>>bindToLifecycle())
                .compose(NetRxFactory.<ResponseBean<List<OrderItemBean>>>toMain())
                .subscribe(new ResponseSub<List<OrderItemBean>>() {
                    @Override
                    public void onOneNext(List<OrderItemBean> listBeans) {

                        view.addDataCondition(listBeans, isRefreshing);

                    }

                    @Override
                    public void onNotOneOrError() {
                        pageNo--;
                    }

                    @Override
                    public void onCustomComplete() {
                        super.onCustomComplete();
                        view.setRefreshing(false);
                        canGetData = true;
                    }
                });


    }


    @Override
    public void getOrderList(final boolean isRefreshing) {
        if (!canGetData) {
            return;
        }
        if (isRefreshing) {
            pageNo = 0;
            isCompleteLoad = false;
        }
        canGetData = false;
        pageNo++;

        LogUtils.i("currentPage = " + pageNo);
        NetRxFactory.getServer(APIService.class).getOrderList(UserUtils.getToken(), pageNo, 10)
                .compose(view.getLifecycleProvide().<ResponseBean<OrderBean>>bindToLifecycle())
                .compose(NetRxFactory.<ResponseBean<OrderBean>>toMain())
                .subscribe(new ResponseSub<OrderBean>() {
                    @Override
                    public void onOneNext(OrderBean orderBean) {
                        if (pageNo <= orderBean.totalPage && orderBean.content.size() > 0) {
                            //有数据
                            isCompleteLoad = false;
                            view.addData(orderBean.content, isRefreshing);

                        } else {
                            //没有数据
                            isCompleteLoad = true;
                            pageNo--;
                        }

                        view.setDataloadStatus(isCompleteLoad);
                    }

                    @Override
                    public void onNotOneNext(OrderBean data) {
                        super.onNotOneNext(data);
                        pageNo--;
                    }

                    @Override
                    public void onError(Throwable e) {
                        super.onError(e);
                        pageNo--;
                    }

                    @Override
                    public void onCustomComplete() {
                        canGetData = true;
                        view.setRefreshing(false);
                    }
                });

        ;
    }

    /***
     *手动补单
     */
    @Override
    public void supplementOrder(final SupplementEvent event) {
        view.showLoadDialog();
        LogUtils.i("sign= "+Utils.getSupplementSign(event.orderCode));
        LogUtils.i("appSecret= "+UserUtils.getUserBean().appSecret);
        NetRxFactory.getServer(APIService.class).updateStatus(
                Constant.OTHER_URL_BASE + "/order/updateStatus", UserUtils.getToken(), UserUtils.getUserBean().code, event.platformOrderNum, Utils.getSupplementSign(event.orderCode))
                .delay(1000, TimeUnit.MILLISECONDS)
                .compose(view.getLifecycleProvide().<ResponseBean<String>>bindToLifecycle())
                .compose(NetRxFactory.<ResponseBean<String>>toMain())
                .subscribe(new ResponseSub<String>() {
                    @Override
                    public void onOneNext(String s) {
                        Utils.showToash("补单成功");
                        view.supplementOrderSuccess(event.platformOrderNum);
                    }

                    @Override
                    public void onNotOneNext(String data) {
                        Utils.showToash("补单失败");
                    }

                    @Override
                    public void onCustomComplete() {
                        super.onCustomComplete();
                        view.dismissLoadDialog();
                    }
                });


        ;
    }
}
