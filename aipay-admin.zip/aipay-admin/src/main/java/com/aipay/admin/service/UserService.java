package com.aipay.admin.service;

import javax.annotation.Resource;

import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.aipay.admin.entity.User;
import com.aipay.admin.repository.UserRepository;

@Service
@Transactional
public class UserService extends BaseService {
	@Resource
	private UserRepository userRepository;

	/**
	 * 
	 * @param name
	 * @param password
	 * @return
	 */
	public User login(String name, String password) {
		if (StringUtils.isEmpty(name)) {
			throw new IllegalArgumentException("用户名不能为空");
		}

		if (StringUtils.isEmpty(password)) {
			throw new IllegalArgumentException("密码不能为空");

		}
		User user = userRepository.findByNameAndPassword(name, DigestUtils.md5Hex(password).toUpperCase());

		if (user == null) {
			throw new IllegalStateException("用户名或密码错误");
		}

		return user;
	}
}