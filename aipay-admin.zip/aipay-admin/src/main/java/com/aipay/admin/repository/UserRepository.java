package com.aipay.admin.repository;

import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.aipay.admin.entity.User;

@Repository
public interface UserRepository extends PagingAndSortingRepository<User, Long> {

	User findByNameAndPassword(String name, String password);
}