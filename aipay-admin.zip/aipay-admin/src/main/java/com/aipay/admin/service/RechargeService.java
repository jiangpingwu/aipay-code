package com.aipay.admin.service;

import javax.annotation.Resource;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.aipay.admin.entity.Recharge;
import com.aipay.admin.repository.MerchantRepository;
import com.aipay.admin.repository.RechargeRepository;
import com.aipay.admin.repository.WalletRepository;
import com.aipay.admin.vo.RechargeQueryVo;

@Service
@Transactional
public class RechargeService extends BaseService {

	@Resource
	private MerchantRepository merchantRepository;

	@Resource
	private WalletRepository walletRepository;

	@Resource
	private RechargeRepository rechargeRepository;

	/**
	 * 
	 * @param code
	 * @return
	 */
	public Recharge getPayment(String code) {
		return rechargeRepository.findByCode(code);
	}

	/**
	 * 
	 * @param queryVo
	 * @param pageable
	 * @return
	 */
	public Page<Recharge> queryList(RechargeQueryVo queryVo, Pageable pageable) {
		return rechargeRepository.queryList(queryVo, pageable);
	}
}