package com.aipay.admin.controller;

import javax.annotation.Resource;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.aipay.admin.entity.Recharge;
import com.aipay.admin.service.RechargeService;
import com.aipay.admin.vo.RechargeQueryVo;
import com.aipay.common.enums.RechargeChannelEnum;
import com.aipay.common.enums.RechargeStatusEnum;

@Controller
@RequestMapping(value = "/recharge")
public class RechargeController extends BaseController {
	@Resource
	private RechargeService rechargeService;

	/**
	 * 
	 * @return
	 */
	@RequestMapping(value = "/toQuery", method = { RequestMethod.GET, RequestMethod.POST })
	public String toQuery(Model model) {
		model.addAttribute("rechargeChannelList", RechargeChannelEnum.values());
		model.addAttribute("rechargeStatusList", RechargeStatusEnum.values());
		model.addAttribute("queryVo", new RechargeQueryVo());
		model.addAttribute("isShowPage", Boolean.FALSE);

		return "recharge/list";
	}

	@RequestMapping(value = "/query", method = { RequestMethod.GET, RequestMethod.POST })
	public String query(Model model, RechargeQueryVo queryVo, @PageableDefault(value = 10) Pageable pageable) {
		Page<Recharge> page = rechargeService.queryList(queryVo, pageable);

		model.addAttribute("rechargeChannelList", RechargeChannelEnum.values());
		model.addAttribute("rechargeStatusList", RechargeStatusEnum.values());
		model.addAttribute("page", page);
		model.addAttribute("queryVo", queryVo);

		Boolean isShowPage = Boolean.FALSE;

		if (page != null && page.getContent() != null && !page.getContent().isEmpty()) {
			isShowPage = Boolean.TRUE;
		}

		model.addAttribute("isShowPage", isShowPage);

		return "recharge/list";
	}
}