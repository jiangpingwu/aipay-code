package com.aipay.admin.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.aipay.admin.entity.Order;
import com.aipay.admin.vo.OrderQueryVo;

@Repository
public interface OrderRepository extends JpaRepository<Order, Long> {

	Order findByCodeAndMerchantCode(String code, String merchantCode);

	/**
	 * 
	 * @param queryVo
	 * @param pageable
	 * @return
	 */
	Page<Order> queryList(OrderQueryVo queryVo, Pageable pageable);
}