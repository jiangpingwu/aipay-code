package com.aipay.admin.handler;

import javax.servlet.http.HttpServletRequest;

import org.springframework.boot.autoconfigure.web.ErrorController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class DefaultErrorController implements ErrorController {
	private final static String ERROR_PATH = "/error";

	/**
	 *
	 * @param request
	 * @return
	 */
	@RequestMapping(value = ERROR_PATH)
	public String errorHtml(HttpServletRequest request) {
		return "error/404";
	}

	/**
	 *
	 * @return the error path
	 */
	@Override
	public String getErrorPath() {
		return ERROR_PATH;
	}
}