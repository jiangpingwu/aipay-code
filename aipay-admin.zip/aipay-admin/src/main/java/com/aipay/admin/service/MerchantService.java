package com.aipay.admin.service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import javax.annotation.Resource;

import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.aipay.admin.entity.Merchant;
import com.aipay.admin.entity.Wallet;
import com.aipay.admin.repository.MerchantRepository;
import com.aipay.admin.repository.WalletRepository;
import com.aipay.admin.vo.merchant.MerchantAddVo;
import com.aipay.admin.vo.merchant.MerchantQueryVo;
import com.aipay.admin.vo.merchant.MerchantUpdateVo;
import com.aipay.admin.vo.merchant.MerchantVo;
import com.aipay.common.enums.MerchantStatusEnum;
import com.aipay.common.exception.BusinessException;
import com.aipay.common.util.CodeUtil;
import com.aipay.common.util.VerifyUtil;

@Service
@Transactional
public class MerchantService extends BaseService {

	@Resource
	private MerchantRepository merchantRepository;

	@Resource
	private WalletRepository walletRepository;

	/**
	 * 
	 * @param addVo
	 */
	public void addMerchant(MerchantAddVo addVo) {
		if (addVo == null) {
			throw new IllegalArgumentException("addVo不能为空");
		}

		if (StringUtils.isEmpty(addVo.getName())) {
			throw new IllegalArgumentException("商户名不能为空");
		}

		if (StringUtils.isEmpty(addVo.getMobile())) {
			throw new IllegalArgumentException("手机号不能为空");
		}

		if (!VerifyUtil.isMobile(addVo.getMobile())) {
			throw new IllegalArgumentException("手机号格式不正确");
		}

		if (StringUtils.isEmpty(addVo.getPassword())) {
			throw new IllegalArgumentException("密码不能为空");
		}

		if (addVo.getRate() == null || addVo.getRate().compareTo(BigDecimal.ZERO) == 0) {
			throw new IllegalArgumentException("汇率不能为空或者为0");
		}

		try {
			Long nameCount = merchantRepository.countByName(addVo.getName());

			if (nameCount > 0) {
				throw new IllegalStateException("商户名已存在,请重新填写");
			}

			Long mobileCount = merchantRepository.countByMobile(addVo.getMobile());

			if (mobileCount > 0) {
				throw new IllegalStateException("手机号已存在,请重新填写");
			}

			Merchant merchant = new Merchant();
			merchant.setCode(CodeUtil.generateMerchantCode());
			merchant.setName(addVo.getName());
			merchant.setPassword(DigestUtils.md5Hex(addVo.getPassword()).toUpperCase());
			merchant.setAppSecret(DigestUtils.md5Hex(UUID.randomUUID().toString()).toUpperCase());
			merchant.setUniqueCode(DigestUtils.md5Hex(UUID.randomUUID().toString()).toUpperCase());
			merchant.setMobile(addVo.getMobile());
			merchant.setEmail(addVo.getEmail());
			merchant.setQq(addVo.getQq());
			merchant.setRate(addVo.getRate());
			merchant.setStatus(addVo.getStatus());
			merchant.setType(addVo.getType());
			merchant.setAddress(addVo.getAddress());
			merchant.setRemark(addVo.getRemark());
			merchant.setCreateDateTime(LocalDateTime.now());

			merchantRepository.save(merchant);

			// 保存钱包信息,余额等信息采用默认值
			Wallet wallet = new Wallet();
			wallet.setMerchantId(merchant.getId());
			wallet.setMerchantCode(merchant.getCode());
			wallet.setCreateDateTime(LocalDateTime.now());

			walletRepository.save(wallet);
		} catch (IllegalArgumentException | IllegalStateException e) {
			throw e;
		} catch (Exception e) {
			throw new BusinessException("添加商户信息出错了", e);
		}
	}

	/**
	 * 
	 * @param updateVo
	 */
	public void updateMerchant(MerchantUpdateVo updateVo) {
		if (updateVo == null) {
			throw new IllegalArgumentException("updateVo不能为空");
		}

		if (StringUtils.isEmpty(updateVo.getName())) {
			throw new IllegalArgumentException("商户名不能为空");
		}

		if (updateVo.getRate() == null || updateVo.getRate().compareTo(BigDecimal.ZERO) == 0) {
			throw new IllegalArgumentException("汇率不能为空或者为0");
		}

		try {
			Long count = merchantRepository.countByNameAndCodeNot(updateVo.getName(), updateVo.getCode());

			if (count > 0) {
				throw new IllegalStateException("商户名已存在,请重新填写");
			}

			Merchant merchant = merchantRepository.findByCode(updateVo.getCode());

			merchant.setName(updateVo.getName());

			merchant.setEmail(updateVo.getEmail());
			merchant.setQq(updateVo.getQq());
			merchant.setRate(updateVo.getRate());
			merchant.setAddress(updateVo.getAddress());
			merchant.setStatus(MerchantStatusEnum.NORMAL);
			merchant.setAddress(updateVo.getAddress());
			merchant.setRemark(updateVo.getRemark());
			merchant.setUpdateDateTime(LocalDateTime.now());

			merchantRepository.save(merchant);

			// 修改钱包信息,余额等信息采用默认值
			Wallet wallet = walletRepository.findByMerchantCode(merchant.getCode());
			wallet.setBalance(updateVo.getBalance());
			wallet.setUpdateDateTime(LocalDateTime.now());

			walletRepository.save(wallet);
		} catch (IllegalArgumentException | IllegalStateException e) {
			throw e;
		} catch (Exception e) {
			throw new BusinessException("修改商户信息出错了", e);
		}
	}

	/**
	 * 
	 * @param code
	 * @return
	 */
	public MerchantVo getDetailInfo(String code) {
		Merchant merchant = merchantRepository.findByCode(code);

		MerchantVo merchantVo = new MerchantVo();

		BeanUtils.copyProperties(merchant, merchantVo);

		// 获取余额
		Wallet wallet = walletRepository.findByMerchantCode(merchant.getCode());

		merchantVo.setBalance(wallet.getBalance());

		return merchantVo;
	}

	/**
	 * 
	 * @param queryVo
	 * @param pageable
	 * @return
	 */
	public Page<MerchantVo> queryList(MerchantQueryVo queryVo, Pageable pageable) {
		Page<Merchant> page = merchantRepository.queryList(queryVo, pageable);

		List<MerchantVo> voList = new ArrayList<>();

		for (Merchant merchant : page.getContent()) {
			MerchantVo merchantVo = new MerchantVo();

			BeanUtils.copyProperties(merchant, merchantVo);

			voList.add(merchantVo);
		}

		// 填充余额信息
		List<String> merchantCodeList = page.getContent().stream().map(merchant -> {
			return merchant.getCode();
		}).collect(Collectors.toList());

		List<Wallet> walletList = walletRepository.findByMerchantCodeIn(merchantCodeList);

		for (MerchantVo vo : voList) {
			for (Wallet wallet : walletList) {
				if (vo.getCode().equals(wallet.getMerchantCode())) {
					vo.setBalance(wallet.getBalance());
				}
			}
		}

		return new PageImpl<>(voList, pageable, page.getTotalElements());
	}
}