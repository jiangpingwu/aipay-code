package com.aipay.admin.service;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.aipay.admin.constant.SystemConstant;


public class BaseService {
	protected Logger logger = LoggerFactory.getLogger(getClass());

	protected ScheduledExecutorService executor = Executors
			.newScheduledThreadPool(Runtime.getRuntime().availableProcessors());

	@Resource
	protected SystemConstant systemConstant;
}
