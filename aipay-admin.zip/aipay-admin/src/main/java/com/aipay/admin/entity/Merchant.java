package com.aipay.admin.entity;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;

import com.aipay.common.enums.MerchantStatusEnum;
import com.aipay.common.enums.MerchantTypeEnum;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 商户信息
 *
 * @author admin
 */
@Entity
@Data
@EqualsAndHashCode(callSuper = true)
public class Merchant extends BaseDateTimeEntity {
	private static final long serialVersionUID = 1L;

	/**
	 * 上级代理id
	 */
	private Long parentId;

	/**
	 * 上级代理code
	 */
	private String parentCode;

	/**
	 * 商户编码,作为DRDS路由字段
	 */
	private String code;

	/**
	 * 商户名称
	 */
	private String name;

	/**
	 * 登录密码
	 */
	private String password;

	/**
	 * 与商户对应的appKey
	 */
	private String appKey;

	/**
	 * 签名时使用的appSecret
	 */
	private String appSecret;

	/**
	 * 用户最近使用的设备标识
	 */
	private String deviceCode;

	/**
	 * 服务器端生成的唯一标识用户当前设备的登录token
	 */
	private String uniqueCode;

	/**
	 * 联系电话
	 */
	private String mobile;

	/**
	 * 联系邮箱
	 */
	private String email;

	/**
	 * qq号
	 */
	private String qq;

	/**
	 * 公司地址
	 */
	private String address;

	/**
	 * 手续费费率,保留4位小数,默认是1%
	 */
	@Column(columnDefinition = "decimal(19,4)")
	private BigDecimal rate = BigDecimal.valueOf(0.01D);

	/**
	 * 代理用户的佣金点
	 */
	@Column(columnDefinition = "decimal(19,4)")
	private BigDecimal brokerage = BigDecimal.ZERO;

	/**
	 * 状态
	 */
	@Enumerated(value = EnumType.STRING)
	private MerchantStatusEnum status = MerchantStatusEnum.NORMAL;

	/**
	 * 类型
	 */
	@Enumerated(value = EnumType.STRING)
	private MerchantTypeEnum type = MerchantTypeEnum.NORMAL;

	/**
	 * 备注信息
	 */
	private String remark;
}
