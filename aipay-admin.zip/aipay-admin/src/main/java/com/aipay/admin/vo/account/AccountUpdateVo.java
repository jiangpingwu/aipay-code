package com.aipay.admin.vo.account;

import com.aipay.common.enums.PayChannelEnum;
import com.aipay.common.vo.BaseValueObject;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class AccountUpdateVo extends BaseValueObject {
	private static final long serialVersionUID = 1L;

	private Long id;
	
	private String merchantCode;

	/**
	 * 二维码图片的链接地址
	 */
	private String imageUrl;

	/**
	 * 关联的支付渠道
	 */
	private PayChannelEnum payChannel;

	/**
	 * 标识是否为默认的账号信息,一个银行商户只能存在一个默认的账号信息
	 */
	private Boolean isDefault = Boolean.FALSE;

	/**
	 * 备注信息
	 */
	private String remark;
}
