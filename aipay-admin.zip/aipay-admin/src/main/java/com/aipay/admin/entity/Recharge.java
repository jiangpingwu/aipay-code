package com.aipay.admin.entity;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Index;
import javax.persistence.Table;

import com.aipay.common.enums.RechargeChannelEnum;
import com.aipay.common.enums.RechargePlatformEnum;
import com.aipay.common.enums.RechargeStatusEnum;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 充值流水信息
 *
 * @author admin
 */
@Entity
@Table(indexes = { @Index(columnList = "code", unique = true) })
@Data
@EqualsAndHashCode(callSuper = true)
public class Recharge extends BaseDateTimeEntity {
	private static final long serialVersionUID = 1L;

	/**
	 * 冗余存储:对应的商户编号
	 */
	private Long merchantId;

	/**
	 * 商户编码,作为DRDS路由字段
	 */
	private String merchantCode;

	/**
	 * 支付流水编码,唯一标识该次支付
	 */
	private String code;

	/**
	 * 交易的总金额,单位为元,保留两位小数
	 */
	private BigDecimal amount = BigDecimal.ZERO;

	/**
	 * 支付平台: 微信官方、支付宝官方、ping++等
	 */
	@Enumerated(EnumType.STRING)
	private RechargePlatformEnum rechargePlatform;

	/**
	 * 支付渠道：微信、支付宝等
	 */
	@Enumerated(EnumType.STRING)
	private RechargeChannelEnum rechargeChannel;

	/**
	 * 支付状态
	 */
	@Enumerated(EnumType.STRING)
	private RechargeStatusEnum rechargeStatus;

	/**
	 * 支付错误码,与前端app的错误码对应
	 */
	private String rechargeErrorCode;

	/**
	 * 微信或者支付宝等第三方支付商生成的订单号
	 */
	private String thirdTradeNo;

	/**
	 * 微信或者支付宝回调通知的支付状态
	 */
	private String notifyStatus;

	/**
	 * 收到支付提供商支付回调的时间,用户发起支付订单的时间通过createDateTime存储
	 */
	private LocalDateTime payDateTime;

	/**
	 * 支付完成时间
	 */
	private LocalDateTime completeDateTime;
}
