package com.aipay.admin.entity;

import javax.persistence.Entity;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 用户信息
 * 
 * @author admin
 */
@Entity
@Data
@EqualsAndHashCode(callSuper = true)
public class User extends BaseDateTimeEntity {
	private static final long serialVersionUID = 1L;

	private String name;

	private String password;

	private String email;

	private String mobile;
}
