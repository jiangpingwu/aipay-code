package com.aipay.admin.entity;

import java.time.LocalDateTime;

import javax.persistence.MappedSuperclass;

import lombok.Data;
import lombok.EqualsAndHashCode;

@MappedSuperclass
@Data
@EqualsAndHashCode(callSuper = true)
public class BaseDateTimeEntity extends BaseEntity {
    private static final long serialVersionUID = 1L;

    /**
     * 创建时间
     */
    protected LocalDateTime createDateTime = LocalDateTime.now();

    /**
     * 修改时间
     */
    protected LocalDateTime updateDateTime;
}
