package com.aipay.admin.controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.aipay.common.constant.RestResult;
import com.aipay.common.constant.ReturnCode;
import com.aipay.common.exception.BusinessException;
import com.aipay.common.exception.ValidateException;

public class BaseController {
	protected Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	protected HttpServletRequest request;

	/**
	 * 获取请求主机IP地址,如果通过代理进来，则透过防火墙获取真实IP地址
	 * 
	 * @return
	 */
	protected String getClientIp() {
		try {
			String ip = request.getHeader("X-Real-IP");

			if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
				if (StringUtils.isEmpty(ip) || "unknown".equalsIgnoreCase(ip)) {
					ip = request.getHeader("x-forwarded-for");
				}

				if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
					ip = request.getHeader("Proxy-Client-IP");
				}

				if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
					ip = request.getHeader("WL-Proxy-Client-IP");
				}

				if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
					ip = request.getHeader("HTTP_CLIENT_IP");
				}

				if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
					ip = request.getHeader("HTTP_X_FORWARDED_FOR");
				}

				if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
					ip = request.getRemoteAddr();
				}
			} else if (ip.length() > 15) {
				String[] ips = ip.split(",");

				for (int index = 0; index < ips.length; index++) {
					String strIp = (String) ips[index];

					if (!("unknown".equalsIgnoreCase(strIp))) {
						ip = strIp;
						break;
					}
				}
			}

			return ip;
		} catch (Exception e) {
			logger.error("获取ip地址发生错误", e);

			return "";
		}
	}

	/**
	 * 
	 * @param request
	 * @return
	 * @throws IOException
	 */
	public String parseInputStream(HttpServletRequest request) throws IOException {
		request.setCharacterEncoding("UTF-8");

		BufferedReader br = new BufferedReader(
				new InputStreamReader((ServletInputStream) request.getInputStream(), "UTF-8"));

		String line = null;

		StringBuilder sb = new StringBuilder();

		while ((line = br.readLine()) != null) {
			sb.append(line);
		}

		return sb.toString();
	}

	/**
	 * 
	 * @param e
	 * @param result
	 */
	protected void buildSuccessResult(String successMsg, RestResult result) {
		result.setMsg(successMsg);
	}

	/**
	 * 
	 * @param e
	 * @param result
	 */
	protected void buildFailureResult(String errorMsg, RestResult result) {
		result.setStatus(ReturnCode.REC_0.getCode());
		result.setMsg(errorMsg);
	}

	/**
	 * 
	 * @param e
	 * @param result
	 */
	protected void buildFailureResult(Exception e, RestResult result) {
		initResult(e, result);
	}

	/**
	 * 
	 * @param request
	 * @param result
	 */
	protected void logAndBuildFailureResult(Exception e, RestResult result) {
		logger.error("操作出错了", e);

		initResult(e, result);
	}

	/**
	 * 
	 * @param e
	 * @param result
	 */
	private void initResult(Exception e, RestResult result) {
		if (e instanceof IllegalArgumentException || e instanceof IllegalStateException) {
			result.setStatus(ReturnCode.REC_2.getCode());
			result.setMsg(e.getMessage());
		} else if (e instanceof ValidateException) {
			ValidateException validateException = (ValidateException) e;

			result.setStatus(validateException.getErrorCode());
			result.setMsg(validateException.getErrorMsg());
		} else if (e instanceof BusinessException) {
			result.setStatus(ReturnCode.REC_0.getCode());
			result.setMsg(ReturnCode.REC_0.getName());
		} else {
			result.setStatus(ReturnCode.REC_0.getCode());
			result.setMsg(ReturnCode.REC_0.getName());
		}
	}
}