package com.aipay.admin.repository;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.apache.commons.lang3.StringUtils;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;

import com.aipay.admin.entity.Merchant;
import com.aipay.admin.vo.merchant.MerchantQueryVo;

@Repository
public class MerchantRepositoryImpl {

	@PersistenceContext
	private EntityManager em;

	/**
	 * 
	 * @param queryVo
	 * @param pageable
	 * @return
	 */
	public Page<Merchant> queryList(MerchantQueryVo queryVo, Pageable pageable) {
		CriteriaBuilder cb = em.getCriteriaBuilder();
		CriteriaQuery<Merchant> cq = cb.createQuery(Merchant.class);
		Root<Merchant> root = cq.from(Merchant.class);

		List<Predicate> paramList = fetchParamList(queryVo, cb, root);

		javax.persistence.criteria.Order order = cb.desc(root.get("createDateTime"));
		cq.orderBy(order);

		// 查询列表
		cq.where(paramList.toArray(new Predicate[paramList.size()]));

		TypedQuery<Merchant> tq = em.createQuery(cq).setFirstResult(pageable.getPageNumber() * pageable.getPageSize())
				.setMaxResults(pageable.getPageSize());

		List<Merchant> list = tq.getResultList();

		// 查询总记录数
		Long totalCount = queryCount(queryVo);

		// 构造分页对象
		Page<Merchant> page = new PageImpl<>(list, pageable, totalCount);

		return page;
	}

	/**
	 * 查询总数
	 * 
	 * @param queryVo
	 * @return
	 */
	private Long queryCount(MerchantQueryVo queryVo) {
		CriteriaBuilder cb = em.getCriteriaBuilder();
		CriteriaQuery<Long> cq = cb.createQuery(Long.class);
		Root<Merchant> root = cq.from(Merchant.class);

		List<Predicate> paramList = fetchParamList(queryVo, cb, root);

		cq.where(paramList.toArray(new Predicate[paramList.size()]));
		cq.select(cb.count(root));

		Long count = em.createQuery(cq).getSingleResult();

		return count;
	}

	/**
	 * 
	 * @param queryVo
	 * @param cb
	 * @param root
	 * @return
	 */
	private List<Predicate> fetchParamList(MerchantQueryVo queryVo, CriteriaBuilder cb, Root<Merchant> root) {
		List<Predicate> paramList = new ArrayList<>();

		if (StringUtils.isNotEmpty(queryVo.getCode())) {
			paramList.add(cb.equal(root.get("code").as(String.class), queryVo.getCode()));
		}

		return paramList;
	}
}