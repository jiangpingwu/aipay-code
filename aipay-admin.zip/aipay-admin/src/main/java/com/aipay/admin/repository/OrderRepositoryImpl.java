package com.aipay.admin.repository;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.apache.commons.lang3.StringUtils;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;

import com.aipay.admin.entity.Order;
import com.aipay.admin.vo.OrderQueryVo;
import com.aipay.common.enums.PayChannelEnum;
import com.aipay.common.enums.PayStatusEnum;
import com.aipay.common.util.DateUtil;

@Repository
public class OrderRepositoryImpl {

	@PersistenceContext
	private EntityManager em;

	/**
	 * 
	 * @param queryVo
	 * @param pageable
	 * @return
	 */
	public Page<Order> queryList(OrderQueryVo queryVo, Pageable pageable) {
		CriteriaBuilder cb = em.getCriteriaBuilder();
		CriteriaQuery<Order> cq = cb.createQuery(Order.class);
		Root<Order> root = cq.from(Order.class);

		List<Predicate> paramList = fetchParamList(queryVo, cb, root);

		javax.persistence.criteria.Order order = cb.desc(root.get("createDateTime"));
		cq.orderBy(order);

		// 查询列表
		cq.where(paramList.toArray(new Predicate[paramList.size()]));

		TypedQuery<Order> tq = em.createQuery(cq).setFirstResult(pageable.getPageNumber() * pageable.getPageSize())
				.setMaxResults(pageable.getPageSize());

		List<Order> list = tq.getResultList();

		// 查询总数
		Long totalCount = queryCount(queryVo);

		// 构造分页对象
		Page<Order> page = new PageImpl<>(list, pageable, totalCount);

		return page;
	}

	/**
	 * 查询总数
	 * 
	 * @param queryVo
	 * @return
	 */
	private Long queryCount(OrderQueryVo queryVo) {
		CriteriaBuilder cb = em.getCriteriaBuilder();
		CriteriaQuery<Long> cq = cb.createQuery(Long.class);
		Root<Order> root = cq.from(Order.class);

		List<Predicate> paramList = fetchParamList(queryVo, cb, root);

		cq.where(paramList.toArray(new Predicate[paramList.size()]));
		cq.select(cb.count(root));

		Long count = em.createQuery(cq).getSingleResult();

		return count;
	}

	/**
	 * 
	 * @param queryVo
	 * @param cb
	 * @param root
	 * @return
	 */
	private List<Predicate> fetchParamList(OrderQueryVo queryVo, CriteriaBuilder cb, Root<Order> root) {
		List<Predicate> paramList = new ArrayList<>();

		if (StringUtils.isNotEmpty(queryVo.getMerchantCode())) {
			paramList.add(cb.equal(root.get("merchantCode").as(String.class), queryVo.getMerchantCode()));
		}

		if (StringUtils.isNotEmpty(queryVo.getCode())) {
			paramList.add(cb.equal(root.get("code").as(String.class), queryVo.getCode()));
		}

		if (StringUtils.isNotEmpty(queryVo.getOutTradeNo())) {
			paramList.add(cb.equal(root.get("outTradeNo").as(String.class), queryVo.getOutTradeNo()));
		}

		if (queryVo.getPayChannel() != null) {
			paramList.add(cb.equal(root.get("payChannel").as(PayChannelEnum.class), queryVo.getPayChannel()));
		}

		if (queryVo.getPayStatus() != null) {
			paramList.add(cb.equal(root.get("payStatus").as(PayStatusEnum.class), queryVo.getPayStatus()));
		}

		if (StringUtils.isNotEmpty(queryVo.getBeginDateTime()) && StringUtils.isNotEmpty(queryVo.getEndDateTime())) {
			LocalDateTime beginDateTime = DateUtil.toLocalDateTime(queryVo.getBeginDateTime() + " 00:00:00");
			LocalDateTime endDateTime = DateUtil.toLocalDateTime(queryVo.getEndDateTime() + " 23:59:59");

			paramList.add(cb.between(root.get("createDateTime").as(LocalDateTime.class), beginDateTime, endDateTime));
		}

		return paramList;
	}
}