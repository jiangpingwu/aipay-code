package com.aipay.admin.service;

import javax.annotation.Resource;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.aipay.admin.entity.Order;
import com.aipay.admin.repository.OrderRepository;
import com.aipay.admin.vo.OrderQueryVo;

@Service
@Transactional
public class OrderService extends BaseService {

	@Resource
	private OrderRepository orderRepository;

	/**
	 * 
	 * @param queryVo
	 * @param pageable
	 * @return
	 */
	public Page<Order> queryList(OrderQueryVo queryVo, Pageable pageable) {
		return orderRepository.queryList(queryVo, pageable);
	}
}