package com.aipay.admin.controller;

import javax.annotation.Resource;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.aipay.admin.entity.Account;
import com.aipay.admin.service.AccountService;
import com.aipay.admin.vo.account.AccountAddVo;
import com.aipay.admin.vo.account.AccountQueryVo;
import com.aipay.admin.vo.account.AccountUpdateVo;
import com.aipay.common.constant.RestResult;
import com.aipay.common.enums.PayChannelEnum;

@Controller
@RequestMapping(value = "/account")
public class AccountController extends BaseController {

	@Resource
	private AccountService accountService;

	/**
	 * 
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "/toAdd", method = { RequestMethod.GET, RequestMethod.POST })
	public String toAdd(Model model) {
		model.addAttribute("addVo", new AccountAddVo());
		model.addAttribute("payChannelList", PayChannelEnum.values());

		return "account/add";
	}

	/**
	 * 
	 * @param model
	 * @param addVo
	 * @return
	 */
	@RequestMapping(value = "/add", method = { RequestMethod.POST })
	@ResponseBody
	public RestResult add(Model model, AccountAddVo addVo) {
		RestResult restResult = new RestResult();

		try {
			accountService.addAccount(addVo);
		} catch (Exception e) {
			logAndBuildFailureResult(e, restResult);
		}

		return restResult;
	}

	/**
	 * 
	 * @param model
	 * @param updateVo
	 * @return
	 */
	@RequestMapping(value = "/update", method = { RequestMethod.POST })
	@ResponseBody
	public RestResult update(Model model, AccountUpdateVo updateVo) {
		RestResult restResult = new RestResult();

		try {
			accountService.updateAccount(updateVo);
		} catch (Exception e) {
			logAndBuildFailureResult(e, restResult);
		}

		return restResult;
	}

	/**
	 * 
	 * @param model
	 * @param id
	 * @return
	 */
	@RequestMapping(value = "/detail", method = { RequestMethod.GET, RequestMethod.POST })
	public String detail(Model model, Long id) {
		Account account = accountService.getAccount(id);

		model.addAttribute("account", account);
		model.addAttribute("payChannelList", PayChannelEnum.values());

		return "account/detail";
	}

	@RequestMapping(value = "/query", method = { RequestMethod.GET, RequestMethod.POST })
	public String query(Model model, AccountQueryVo queryVo, @PageableDefault(value = 10) Pageable pageable) {
		Page<Account> page = accountService.queryList(queryVo, pageable);

		model.addAttribute("payChannelList", PayChannelEnum.values());
		model.addAttribute("page", page);
		model.addAttribute("queryVo", queryVo);

		Boolean isShowPage = Boolean.FALSE;

		if (page != null && page.getContent() != null && !page.getContent().isEmpty()) {
			isShowPage = Boolean.TRUE;
		}

		model.addAttribute("isShowPage", isShowPage);

		return "account/list";
	}
}