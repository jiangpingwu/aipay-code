package com.aipay.admin.vo;

import com.aipay.common.enums.RechargeChannelEnum;
import com.aipay.common.enums.RechargeStatusEnum;
import com.aipay.common.vo.BaseValueObject;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class RechargeQueryVo extends BaseValueObject {
	private static final long serialVersionUID = 1L;

	private String merchantCode;

	private RechargeChannelEnum rechargeChannel;

	private RechargeStatusEnum rechargeStatus;

	private String beginDateTime;

	private String endDateTime;
}
