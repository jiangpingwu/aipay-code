package com.aipay.admin.repository;

import java.util.List;

import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.aipay.admin.entity.Wallet;

@Repository
public interface WalletRepository extends PagingAndSortingRepository<Wallet, Long> {

	Wallet findByMerchantCode(String merchantCode);

	List<Wallet> findByMerchantCodeIn(List<String> merchantCodeList);
}