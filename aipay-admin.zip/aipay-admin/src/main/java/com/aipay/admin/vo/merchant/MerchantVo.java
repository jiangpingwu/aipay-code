package com.aipay.admin.vo.merchant;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import com.aipay.common.enums.MerchantStatusEnum;
import com.aipay.common.enums.MerchantTypeEnum;
import com.aipay.common.vo.BaseValueObject;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class MerchantVo extends BaseValueObject {
	private static final long serialVersionUID = 1L;

	/**
	 * 上级代理id
	 */
	private Long parentId;

	/**
	 * 上级代理code
	 */
	private String parentCode;

	/**
	 * 商户编码,作为DRDS路由字段
	 */
	private String code;

	/**
	 * 商户名称
	 */
	private String name;

	/**
	 * 签名时使用的appSecret
	 */
	private String appSecret;

	/**
	 * 联系电话
	 */
	private String mobile;

	/**
	 * 联系邮箱
	 */
	private String email;

	/**
	 * qq号
	 */
	private String qq;

	/**
	 * 公司地址
	 */
	private String address;

	/**
	 * 手续费费率,保留4位小数,默认是1%
	 */
	private BigDecimal rate = BigDecimal.valueOf(0.01D);

	private MerchantStatusEnum status = MerchantStatusEnum.NORMAL;

	private MerchantTypeEnum type = MerchantTypeEnum.NORMAL;

	/**
	 * 余额
	 */
	private BigDecimal balance = BigDecimal.ZERO;

	private String remark;

	private LocalDateTime createDateTime;

	private LocalDateTime updateDateTime;
}
