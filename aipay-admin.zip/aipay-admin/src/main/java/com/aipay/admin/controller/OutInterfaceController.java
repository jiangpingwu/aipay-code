package com.aipay.admin.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value = "/out")
public class OutInterfaceController extends BaseController {

	@RequestMapping(value = "/ack", method = { RequestMethod.GET, RequestMethod.POST })
	@ResponseBody
	public String ack() {
		return "ack ok";
	}
}