package com.aipay.admin.controller;

import javax.annotation.Resource;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.aipay.admin.service.MerchantService;
import com.aipay.admin.vo.merchant.MerchantAddVo;
import com.aipay.admin.vo.merchant.MerchantQueryVo;
import com.aipay.admin.vo.merchant.MerchantUpdateVo;
import com.aipay.admin.vo.merchant.MerchantVo;
import com.aipay.common.constant.RestResult;
import com.aipay.common.enums.MerchantStatusEnum;
import com.aipay.common.enums.MerchantTypeEnum;

@Controller
@RequestMapping(value = "/merchant")
public class MerchantController extends BaseController {
	@Resource
	private MerchantService merchantService;

	/**
	 * 
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "/toAdd", method = { RequestMethod.GET, RequestMethod.POST })
	public String toAdd(Model model) {
		model.addAttribute("addVo", new MerchantAddVo());

		return "merchant/add";
	}

	/**
	 * 
	 * @param model
	 * @param addVo
	 * @return
	 */
	@RequestMapping(value = "/add", method = { RequestMethod.POST })
	@ResponseBody
	public RestResult add(Model model, MerchantAddVo addVo) {
		RestResult restResult = new RestResult();

		try {
			merchantService.addMerchant(addVo);
		} catch (Exception e) {
			logAndBuildFailureResult(e, restResult);
		}

		return restResult;
	}

	/**
	 * 
	 * @param model
	 * @param updateVo
	 * @return
	 */
	@RequestMapping(value = "/update", method = { RequestMethod.POST })
	@ResponseBody
	public RestResult add(Model model, MerchantUpdateVo updateVo) {
		RestResult restResult = new RestResult();

		try {
			merchantService.updateMerchant(updateVo);
		} catch (Exception e) {
			logAndBuildFailureResult(e, restResult);
		}

		return restResult;
	}

	/**
	 * 
	 * @param model
	 * @param code
	 * @return
	 */
	@RequestMapping(value = "/detail", method = { RequestMethod.GET, RequestMethod.POST })
	public String detail(Model model, String code) {
		MerchantVo vo = merchantService.getDetailInfo(code);

		model.addAttribute("merchantVo", vo);
		model.addAttribute("statusList", MerchantStatusEnum.values());
		model.addAttribute("typeList", MerchantTypeEnum.values());

		return "merchant/detail";
	}

	/**
	 * 
	 * @param model
	 * @param queryVo
	 * @param pageable
	 * @return
	 */
	@RequestMapping(value = "/query", method = { RequestMethod.GET, RequestMethod.POST })
	public String query(Model model, MerchantQueryVo queryVo, @PageableDefault(value = 10) Pageable pageable) {
		Page<MerchantVo> page = merchantService.queryList(queryVo, pageable);

		model.addAttribute("page", page);
		model.addAttribute("queryVo", queryVo);
		model.addAttribute("statusList", MerchantStatusEnum.values());
		model.addAttribute("typeList", MerchantTypeEnum.values());

		return "merchant/list";
	}
}