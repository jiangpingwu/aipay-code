package com.aipay.admin.vo;

import com.aipay.common.enums.PayChannelEnum;
import com.aipay.common.enums.PayStatusEnum;
import com.aipay.common.vo.BaseValueObject;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class OrderQueryVo extends BaseValueObject {
	private static final long serialVersionUID = 1L;

	/**
	 * 商户号
	 */
	private String merchantCode;

	/**
	 * 订单编码,唯一标识一条订单记录
	 */
	private String code;

	/**
	 * 商户的交易标识
	 */
	private String outTradeNo;

	/**
	 * 支付渠道
	 */
	private PayChannelEnum payChannel;

	/**
	 * 支付状态
	 */
	private PayStatusEnum payStatus;

	/**
	 * 开始时间
	 */
	private String beginDateTime;

	/**
	 * 结束时间
	 */
	private String endDateTime;
}
