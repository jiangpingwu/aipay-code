package com.aipay.admin.constant;

import org.springframework.stereotype.Component;

@Component
public class SystemConstant {

}