package com.aipay.admin.controller;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.aipay.admin.entity.User;
import com.aipay.admin.service.UserService;

@Controller
@RequestMapping(value = "/user")
public class UserController extends BaseController {
	@Resource
	private UserService userService;

	@RequestMapping(value = "/toLogin", method = { RequestMethod.GET, RequestMethod.POST })
	public String toLogin(Model model, String email, String password) {
		return "user/login";
	}

	@RequestMapping(value = "/login", method = { RequestMethod.GET, RequestMethod.POST })
	public String login(Model model, String name, String password) {
		try {
			User user = userService.login(name, password);
			request.getSession().setAttribute("user", user);

			return "forward:/merchant/query";
		} catch (IllegalArgumentException | IllegalStateException e) {
			logger.error("注册出错了", e);

			model.addAttribute("errorMsg", e.getMessage());

			return "user/login";
		} catch (Exception e) {
			logger.error("注册出错了", e);

			model.addAttribute("errorMsg", "登录出错了,请稍后再试");

			return "user/login";
		}
	}
}