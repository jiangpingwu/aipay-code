package com.aipay.admin.vo.merchant;

import com.aipay.common.vo.BaseValueObject;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class MerchantQueryVo extends BaseValueObject {
	private static final long serialVersionUID = 1L;

	private String code;

	private String name;
}
