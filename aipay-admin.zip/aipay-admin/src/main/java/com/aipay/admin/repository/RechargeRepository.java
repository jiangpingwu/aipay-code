package com.aipay.admin.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.aipay.admin.entity.Recharge;
import com.aipay.admin.vo.RechargeQueryVo;

@Repository
public interface RechargeRepository extends PagingAndSortingRepository<Recharge, Long> {

	Recharge findByCode(String code);

	Page<Recharge> queryList(RechargeQueryVo orderQueryVo, Pageable pageable);
}
