package com.aipay.admin.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import com.aipay.admin.interceptor.LoginInterceptor;


@Configuration
public class WebAppConfigurer extends WebMvcConfigurerAdapter {

	/**
	 * @param registry
	 */
	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		super.addInterceptors(registry);

		LoginInterceptor loginInterceptor = new LoginInterceptor();
		String[] excludeUrls = new String[] { "/out/ack", "/error", "/user/toLogin", "/user/login" };

		registry.addInterceptor(loginInterceptor).addPathPatterns("/**").excludePathPatterns(excludeUrls);
	}

	/**
	 * 跨域配置
	 *
	 * @param registry
	 */
	@Override
	public void addCorsMappings(CorsRegistry registry) {
		registry.addMapping("/**").allowedHeaders("*").allowedMethods("*").allowedOrigins("*");
	}
}
