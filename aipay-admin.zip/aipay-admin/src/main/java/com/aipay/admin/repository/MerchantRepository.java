package com.aipay.admin.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.aipay.admin.entity.Merchant;
import com.aipay.admin.vo.merchant.MerchantQueryVo;

@Repository
public interface MerchantRepository extends PagingAndSortingRepository<Merchant, Long> {

	Long countByMobile(String mobile);

	Long countByName(String name);

	Long countByNameAndCodeNot(String name, String code);

	Merchant findByCode(String code);

	/**
	 * 
	 * @param merchantVo
	 * @param pageable
	 * @return
	 */
	Page<Merchant> queryList(MerchantQueryVo merchantVo, Pageable pageable);
}