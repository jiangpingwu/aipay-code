package com.aipay.admin.service;

import java.time.LocalDateTime;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.aipay.admin.entity.Account;
import com.aipay.admin.entity.Merchant;
import com.aipay.admin.repository.AccountRepository;
import com.aipay.admin.repository.MerchantRepository;
import com.aipay.admin.vo.account.AccountAddVo;
import com.aipay.admin.vo.account.AccountQueryVo;
import com.aipay.admin.vo.account.AccountUpdateVo;
import com.aipay.common.exception.BusinessException;

@Service
@Transactional
public class AccountService extends BaseService {

	@Resource
	private MerchantRepository merchantRepository;

	@Resource
	private AccountRepository accountRepository;

	/**
	 * 
	 * @param addVo
	 */
	public void addAccount(AccountAddVo addVo) {
		if (addVo == null) {
			throw new IllegalArgumentException("addVo不能为空");
		}

		if (StringUtils.isEmpty(addVo.getMerchantCode())) {
			throw new IllegalArgumentException("商户名不能为空");
		}

		if (StringUtils.isEmpty(addVo.getImageUrl())) {
			throw new IllegalArgumentException("imageUrl不能为空");
		}

		if (addVo.getPayChannel() == null) {
			throw new IllegalArgumentException("支付渠道不能为空");
		}

		if (addVo.getIsDefault() == null) {
			throw new IllegalArgumentException("是否默认账号标识不能为空");
		}

		try {
			if (addVo.getIsDefault()) {
				Long count = accountRepository.countByPayChannelAndIsDefaultAndMerchantCode(addVo.getPayChannel(),
						Boolean.TRUE, addVo.getMerchantCode());

				if (count > 0) {
					throw new IllegalStateException("同一个支付渠道只能存在一个默认账号");
				}
			}
			
			Merchant merchant = merchantRepository.findByCode(addVo.getMerchantCode());

			Account account = new Account();
			account.setMerchantId(merchant.getId());
			account.setMerchantCode(addVo.getMerchantCode());
			account.setPayChannel(addVo.getPayChannel());
			account.setImageUrl(addVo.getImageUrl());
			account.setIsDefault(addVo.getIsDefault());
			account.setRemark(addVo.getRemark());
			account.setCreateDateTime(LocalDateTime.now());

			accountRepository.save(account);
		} catch (IllegalArgumentException | IllegalStateException e) {
			throw e;
		} catch (Exception e) {
			throw new BusinessException("添加账号信息出错了", e);
		}
	}

	/**
	 * 
	 * @param updateVo
	 */
	public void updateAccount(AccountUpdateVo updateVo) {
		if (updateVo == null) {
			throw new IllegalArgumentException("addVo不能为空");
		}

		if (updateVo.getId() == null || updateVo.getId() == 0) {
			throw new IllegalArgumentException("id不能为空");
		}

		if (StringUtils.isEmpty(updateVo.getImageUrl())) {
			throw new IllegalArgumentException("商户号不能为空");
		}

		if (StringUtils.isEmpty(updateVo.getImageUrl())) {
			throw new IllegalArgumentException("imageUrl不能为空");
		}

		if (updateVo.getPayChannel() == null) {
			throw new IllegalArgumentException("支付渠道不能为空");
		}

		if (updateVo.getIsDefault() == null) {
			throw new IllegalArgumentException("是否默认账号标识不能为空");
		}

		try {
			if (updateVo.getIsDefault()) {
				Long count = accountRepository.countByPayChannelAndIsDefaultAndMerchantCodeAndIdNot(
						updateVo.getPayChannel(), Boolean.TRUE, updateVo.getMerchantCode(), updateVo.getId());

				if (count > 0) {
					throw new IllegalStateException("同一个支付渠道只能存在一个默认账号");
				}
			}

			Account account = accountRepository.findOne(updateVo.getId());

			account.setPayChannel(updateVo.getPayChannel());
			account.setImageUrl(updateVo.getImageUrl());
			account.setIsDefault(updateVo.getIsDefault());
			account.setRemark(updateVo.getRemark());
			account.setUpdateDateTime(LocalDateTime.now());

			accountRepository.save(account);
		} catch (IllegalArgumentException | IllegalStateException e) {
			throw e;
		} catch (Exception e) {
			throw new BusinessException("修改账号信息出错了", e);
		}
	}

	/**
	 * 
	 * @param id
	 * @return
	 */
	public Account getAccount(Long id) {
		return accountRepository.findOne(id);
	}

	/**
	 * 
	 * @param queryVo
	 * @param pageable
	 * @return
	 */
	public Page<Account> queryList(AccountQueryVo queryVo, Pageable pageable) {
		return accountRepository.queryList(queryVo, pageable);
	}
}