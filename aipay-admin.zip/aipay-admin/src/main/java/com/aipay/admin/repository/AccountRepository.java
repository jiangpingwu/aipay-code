package com.aipay.admin.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.aipay.admin.entity.Account;
import com.aipay.admin.vo.account.AccountQueryVo;
import com.aipay.common.enums.PayChannelEnum;

@Repository
public interface AccountRepository extends PagingAndSortingRepository<Account, Long> {

	Long countByPayChannelAndIsDefaultAndMerchantCode(PayChannelEnum payChannel, Boolean isDefault,
			String merchantCode);

	Long countByPayChannelAndIsDefaultAndMerchantCodeAndIdNot(PayChannelEnum payChannel, Boolean isDefault,
			String merchantCode, Long id);

	Page<Account> queryList(AccountQueryVo queryVo, Pageable pageable);
}