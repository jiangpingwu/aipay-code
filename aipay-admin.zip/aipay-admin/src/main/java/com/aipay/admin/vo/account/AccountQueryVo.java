package com.aipay.admin.vo.account;

import com.aipay.common.enums.PayChannelEnum;
import com.aipay.common.vo.BaseValueObject;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class AccountQueryVo extends BaseValueObject {
	private static final long serialVersionUID = 1L;

	/**
	 * 商户号
	 */
	private String merchantCode;

	/**
	 * 支付渠道
	 */
	private PayChannelEnum payChannel;

	/**
	 * 开始时间
	 */
	private String beginDateTime;

	/**
	 * 结束时间
	 */
	private String endDateTime;
}
