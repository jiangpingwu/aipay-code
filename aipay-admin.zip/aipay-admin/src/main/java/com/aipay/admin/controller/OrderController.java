package com.aipay.admin.controller;

import javax.annotation.Resource;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.aipay.admin.entity.Order;
import com.aipay.admin.service.OrderService;
import com.aipay.admin.vo.OrderQueryVo;
import com.aipay.common.enums.PayChannelEnum;
import com.aipay.common.enums.PayStatusEnum;

@Controller
@RequestMapping(value = "/order")
public class OrderController extends BaseController {
	@Resource
	private OrderService orderService;

	/**
	 * 
	 * @return
	 */
	@RequestMapping(value = "/toQuery", method = { RequestMethod.GET, RequestMethod.POST })
	public String toQuery(Model model) {
		model.addAttribute("payChannelList", PayChannelEnum.values());
		model.addAttribute("orderStatusList", PayStatusEnum.fetchCanUse());
		model.addAttribute("queryVo", new OrderQueryVo());
		model.addAttribute("isShowPage", Boolean.FALSE);

		return "order/list";
	}

	@RequestMapping(value = "/query", method = { RequestMethod.GET, RequestMethod.POST })
	public String query(Model model, OrderQueryVo queryVo, @PageableDefault(value = 10) Pageable pageable) {
		Page<Order> page = orderService.queryList(queryVo, pageable);

		model.addAttribute("payChannelList", PayChannelEnum.values());
		model.addAttribute("orderStatusList", PayStatusEnum.fetchCanUse());
		model.addAttribute("page", page);
		model.addAttribute("queryVo", queryVo);

		Boolean isShowPage = Boolean.FALSE;

		if (page != null && page.getContent() != null && !page.getContent().isEmpty()) {
			isShowPage = Boolean.TRUE;
		}

		model.addAttribute("isShowPage", isShowPage);

		return "order/list";
	}
}