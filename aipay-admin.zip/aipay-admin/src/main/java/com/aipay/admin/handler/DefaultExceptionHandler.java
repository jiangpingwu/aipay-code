package com.aipay.admin.handler;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.aipay.common.constant.RestResult;
import com.aipay.common.constant.ReturnCode;
import com.aipay.common.exception.BusinessException;
import com.aipay.common.exception.ValidateException;

@ControllerAdvice
public class DefaultExceptionHandler {
	private static Logger logger = LoggerFactory.getLogger(DefaultExceptionHandler.class);

	/**
	 * 
	 * @param e
	 * @return
	 */
	@ExceptionHandler(value = Exception.class)
	public String handleException(Exception e) {
		RestResult result = new RestResult();

		if (e instanceof IllegalArgumentException || e instanceof IllegalStateException) {
			result.setStatus(ReturnCode.REC_2.getCode());
			result.setMsg(e.getMessage());
		} else if (e instanceof ValidateException) {
			ValidateException validateException = (ValidateException) e;

			result.setStatus(validateException.getErrorCode());
			result.setMsg(validateException.getErrorMsg());
		} else if (e instanceof BusinessException) {
			result.setStatus(ReturnCode.REC_0.getCode());
			result.setMsg(ReturnCode.REC_0.getName());
		} else {
			result.setStatus(ReturnCode.REC_0.getCode());
			result.setMsg(ReturnCode.REC_0.getName());
		}

		logger.error("操作出错了", e);

		return "error/500";
	}
}