package com.aipay.admin.entity;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Lob;

import com.aipay.common.enums.PayChannelEnum;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 支付账号信息
 *
 * @author admin
 */
@Entity
@Data
@EqualsAndHashCode(callSuper = true)
public class Account extends BaseDateTimeEntity {
	private static final long serialVersionUID = 1L;

	/**
	 * 冗余存储:对应的商户编号
	 */
	private Long merchantId;

	/**
	 * 商户编码,作为DRDS路由字段
	 */
	private String merchantCode;

	/**
	 * 生成的base64格式的图片字符串
	 */
	@Lob
	private String base64Image;

	/**
	 * 二维码图片的链接地址
	 */
	private String imageUrl;

	/**
	 * 关联的支付渠道
	 */
	@Enumerated(value = EnumType.STRING)
	private PayChannelEnum payChannel;

	/**
	 * 标识是否为默认的账号信息,一个银行商户只能存在一个默认的账号信息
	 */
	private Boolean isDefault = Boolean.FALSE;

	/**
	 * 备注信息
	 */
	private String remark;
}
