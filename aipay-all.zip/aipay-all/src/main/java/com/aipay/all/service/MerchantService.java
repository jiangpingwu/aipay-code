package com.aipay.all.service;

import java.time.LocalDateTime;
import java.util.Optional;
import java.util.UUID;

import javax.annotation.Resource;

import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Base64Utils;

import com.aipay.all.constant.RedisConstant;
import com.aipay.all.entity.Merchant;
import com.aipay.all.entity.Wallet;
import com.aipay.all.repository.MerchantRepository;
import com.aipay.all.repository.WalletRepository;
import com.aipay.all.vo.MerchantVo;
import com.aipay.common.enums.MerchantStatusEnum;
import com.aipay.common.enums.MerchantTypeEnum;
import com.aipay.common.exception.BusinessException;
import com.aipay.common.exception.NoLoginException;
import com.aipay.common.util.VerifyUtil;

@Service
@Transactional
public class MerchantService extends BaseService {

	@Resource
	private MerchantRepository merchantRepository;

	@Resource
	private WalletRepository walletRepository;

	/**
	 * 
	 * @param mobile
	 * @param password
	 * @param deviceCode
	 * @return
	 */
	public String login(String mobile, String password, String deviceCode) {
		if (StringUtils.isEmpty(mobile)) {
			throw new IllegalArgumentException("手机号不能为空");
		}

		if (!VerifyUtil.isMobile(mobile)) {
			throw new IllegalArgumentException("不正确的手机格式");
		}

		if (StringUtils.isEmpty(password)) {
			throw new IllegalArgumentException("密码不能为空");
		}

		if (StringUtils.isEmpty(deviceCode)) {
			throw new IllegalArgumentException("用户终端标识不能为空");
		}

		Merchant merchant = merchantRepository.findByMobileAndPassword(mobile,
				DigestUtils.md5Hex(password).toUpperCase());

		if (merchant == null) {
			throw new IllegalStateException("用户名或密码错误");
		}

		if (merchant.getStatus() == MerchantStatusEnum.FORBIDDEN) {
			throw new IllegalArgumentException("用户已被禁用,不能登录");
		}

		// 判断uniqueCode是否失效
		dealUniqueCodeInfo(merchant, deviceCode);

		merchantRepository.save(merchant);

		try {
			redisTemplate.boundHashOps(RedisConstant.REDIS_USER_UNIQUE_CODES).put(merchant.getUniqueCode(),
					String.valueOf(merchant.getId()));
		} catch (Exception e) {
			logger.error("把用户信息放入redis出错", e);
		}

		return merchant.getUniqueCode();
	}

	/**
	 * 
	 * @param merchantId
	 */
	public void logout(Long merchantId) {
		if (merchantId == null || merchantId == 0) {
			throw new IllegalArgumentException("商户编号不能为空");
		}

		try {
			Merchant member = merchantRepository.findById(merchantId).get();

			String oldUniqueCode = member.getUniqueCode();

			String key = UUID.randomUUID().toString() + "_" + member.getAppSecret() + "_"
					+ member.getCreateDateTime().getNano();
			String newUniqueCode = Base64Utils.encodeToString(key.getBytes());

			member.setUniqueCode(newUniqueCode);
			member.setUpdateDateTime(LocalDateTime.now());

			merchantRepository.save(member);

			try {
				redisTemplate.boundHashOps(RedisConstant.REDIS_USER_UNIQUE_CODES).delete(oldUniqueCode);
			} catch (Exception e) {
				logger.error("从redis中删除旧的uniqueCode出错", e);
			}
		} catch (Exception e) {
			throw new BusinessException("用户注销出错", e);
		}
	}

	/**
	 *
	 * @param uniqueCode
	 * @return
	 */
	public Long getMerchantId(String uniqueCode) {
		if (StringUtils.isEmpty(uniqueCode)) {
			throw new NoLoginException("用户未登录");
		}

		String merchantId = null;

		try {
			merchantId = (String) redisTemplate.boundHashOps(RedisConstant.REDIS_USER_UNIQUE_CODES).get(uniqueCode);
		} catch (Exception e) {
			logger.error("从redis获取用户信息出错", e);
		}

		if (StringUtils.isEmpty(merchantId)) {
			Merchant member = merchantRepository.findByUniqueCode(uniqueCode);

			if (member == null) {
				throw new NoLoginException("用户未登录");
			}

			merchantId = String.valueOf(member.getId());

			try {
				redisTemplate.boundHashOps(RedisConstant.REDIS_USER_UNIQUE_CODES).put(uniqueCode,
						String.valueOf(member.getId()));
			} catch (Exception e) {
				logger.error("把用户信息放入redis出错", e);
			}
		}

		return Long.valueOf(merchantId);
	}

	/**
	 *
	 * @param uniqueCode
	 * @return
	 */
	public Long getMerchantIdAllowNull(String uniqueCode) {
		String merchantId = null;

		try {
			merchantId = (String) redisTemplate.boundHashOps(RedisConstant.REDIS_USER_UNIQUE_CODES).get(uniqueCode);
		} catch (Exception e) {
			logger.error("从redis获取用户信息出错", e);
		}

		if (StringUtils.isEmpty(merchantId)) {
			Merchant member = merchantRepository.findByUniqueCode(uniqueCode);

			if (member == null) {
				return null;
			}

			merchantId = String.valueOf(member.getId());

			try {
				redisTemplate.boundHashOps(RedisConstant.REDIS_USER_UNIQUE_CODES).put(uniqueCode,
						String.valueOf(member.getId()));
			} catch (Exception e) {
				logger.error("把用户信息放入redis出错", e);
			}
		}

		return Long.valueOf(merchantId);
	}

	/**
	 * 
	 * @param merchantId
	 * @return
	 */
	public MerchantVo getDetailInfo(Long merchantId) {
		Optional<Merchant> merchantOptional = merchantRepository.findById(merchantId);

		Merchant merchant = merchantOptional.get();

		MerchantVo merchantVo = new MerchantVo();
		merchantVo.setCode(merchant.getCode());
		merchantVo.setMobile(merchant.getMobile());
		merchantVo.setEmail(merchant.getEmail());
		merchantVo.setQq(merchant.getQq());
		merchantVo.setAppSecret(DigestUtils.md5Hex(merchant.getAppSecret()).toUpperCase());
		merchantVo.setStatus(merchant.getStatus());
		merchantVo.setStatusName(merchant.getStatus().getName());
		merchantVo.setType(merchant.getType());
		merchantVo.setTypeName(merchant.getType().getName());
		merchantVo.setRate(merchant.getRate());

		// 钱包信息
		Wallet wallet = walletRepository.findByMerchantCode(merchant.getCode());

		if (wallet != null) {
			merchantVo.setBalance(wallet.getBalance());
		}

		return merchantVo;
	}

	/**
	 * 
	 * @param merchant
	 */
	private void dealUniqueCodeInfo(Merchant merchant, String deviceCode) {
		String currentDeviceCode = deviceCode;

		if (StringUtils.isEmpty(currentDeviceCode)) {
			currentDeviceCode = UUID.randomUUID().toString();
		}

		// 如果当前deviceCode和用户注册时或最近一次登录的device不同时,
		// 那么通过相同算法生成的uniqueCode也会不同,在安全级别较高时,可以执行相应的校验操作,这里暂时省略
		if (!currentDeviceCode.equals(merchant.getDeviceCode())) {
			logger.warn("用户[" + merchant.getId() + "]不在最近的设备登录,重新生成新的uniqueCode");

			// 重新设置deviceCode和
			String oldUniqueCode = merchant.getUniqueCode();
			String key = currentDeviceCode + "_" + merchant.getAppSecret() + "_"
					+ merchant.getCreateDateTime().getNano();
			String newUniqueCode = Base64Utils.encodeToString(key.getBytes());

			merchant.setDeviceCode(currentDeviceCode);
			merchant.setUniqueCode(newUniqueCode);
			merchant.setUpdateDateTime(LocalDateTime.now());

			merchantRepository.save(merchant);

			try {
				redisTemplate.boundHashOps(RedisConstant.REDIS_USER_UNIQUE_CODES).delete(oldUniqueCode);
			} catch (Exception e) {
				logger.error("从redis中删除旧的uniqueCode出错", e);
			}
		}
	}
}