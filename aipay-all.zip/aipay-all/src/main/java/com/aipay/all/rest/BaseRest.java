package com.aipay.all.rest;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.client.RestTemplate;

import com.aipay.all.service.MerchantService;
import com.aipay.common.constant.HeaderConstant;
import com.aipay.common.constant.ParameterConstant;
import com.aipay.common.exception.NoLoginException;

public class BaseRest {
	protected Logger logger = LoggerFactory.getLogger(getClass());

	@Resource
	protected HttpServletRequest request;

	@Resource
	protected RestTemplate restTemplate;

	@Resource
	protected MerchantService merchantService;

	/**
	 * 
	 * @return
	 */
	protected String getDeviceCode() {
		String deviceCode = request.getHeader(HeaderConstant.DEVICE_CODE);

		if (StringUtils.isEmpty(deviceCode)) {
			deviceCode = request.getParameter(ParameterConstant.DEVICE_CODE);
		}

		return deviceCode;
	}

	/**
	 * 
	 * @return
	 */
	protected Long getCurrentMerchantId() {
		// 多重判断,兼容目前的接口调试
		String uniqueCode = request.getHeader(HeaderConstant.UNIQUE_CODE);

		if (StringUtils.isEmpty(uniqueCode)) {
			uniqueCode = request.getParameter(ParameterConstant.UNIQUE_CODE);
		}

		if (StringUtils.isEmpty(uniqueCode)) {
			throw new NoLoginException();
		}

		return merchantService.getMerchantId(uniqueCode);
	}

	/**
	 * 
	 * @return
	 */
	protected Long getCurrentMerchantIdAllowNull() {
		// 多重判断,兼容目前的接口调试
		String uniqueCode = request.getHeader(HeaderConstant.UNIQUE_CODE);

		if (StringUtils.isEmpty(uniqueCode)) {
			uniqueCode = request.getParameter(ParameterConstant.UNIQUE_CODE);
		}

		if (StringUtils.isEmpty(uniqueCode)) {
			return null;
		}

		return merchantService.getMerchantIdAllowNull(uniqueCode);
	}
}