package com.aipay.all.repository;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.aipay.all.entity.Order;
import com.aipay.all.vo.OrderQueryVo;
import com.aipay.common.enums.CountStatusEnum;
import com.aipay.common.enums.PayChannelEnum;
import com.aipay.common.enums.PayStatusEnum;

@Repository
public interface OrderRepository extends PagingAndSortingRepository<Order, Long> {

	@Modifying
	@Query(value = "update Order set payStatus = :payStatus, payDateTime = :payDateTime, updateDateTime = :updateDateTime where id= :id and merchantCode = :merchantCode")
	public void updateToPayStatus(@Param(value = "payStatus") PayStatusEnum payStatus,
			@Param(value = "payDateTime") LocalDateTime payDateTime,
			@Param(value = "updateDateTime") LocalDateTime updateDateTime, @Param(value = "id") Long id,
			@Param(value = "merchantCode") String merchantCode);

	@Modifying
	@Query(value = "update Order set payStatus = :payStatus, completeDateTime = :completeDateTime, updateDateTime = :updateDateTime where id= :id and merchantCode = :merchantCode")
	public void updateToCompleteStatus(@Param(value = "payStatus") PayStatusEnum payStatus,
			@Param(value = "completeDateTime") LocalDateTime completeDateTime,
			@Param(value = "updateDateTime") LocalDateTime updateDateTime, @Param(value = "id") Long id,
			@Param(value = "merchantCode") String merchantCode);

	@Modifying
	@Query(value = "update Order set countStatus = :countStatus, updateDateTime = :updateDateTime where id= :id and merchantCode = :merchantCode")
	public void update(@Param(value = "countStatus") CountStatusEnum countStatus,
			@Param(value = "updateDateTime") LocalDateTime updateDateTime, @Param(value = "id") Long id,
			@Param(value = "merchantCode") String merchantCode);

	Order findByCodeAndMerchantCode(String code, String merchantCode);

	Order findTop1ByMerchantCodeAndPayAmountAndPayChannelAndCreateDateTimeGreaterThanEqual(String merchantCode,
			BigDecimal payAmount, PayChannelEnum payChannel, LocalDateTime endDateTime);

	Order findTop1ByMerchantCodeAndPayAmountAndPayChannelAndCreateDateTimeGreaterThanEqualOrderByCreateDateTimeDesc(
			String merchantCode, BigDecimal payAmount, PayChannelEnum payChannel, LocalDateTime endDateTime);

	List<Order> queryList(OrderQueryVo queryVo, Pageable pageable);
}