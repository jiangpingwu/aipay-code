package com.aipay.all.rest;

import java.math.BigDecimal;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.aipay.all.service.OrderService;
import com.aipay.all.vo.OrderQueryVo;
import com.aipay.all.vo.OrderVo;
import com.aipay.common.bean.OrderRequest;
import com.aipay.common.bean.OrderResponse;
import com.aipay.common.constant.RestResult;
import com.aipay.common.enums.PayChannelEnum;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(value = "/order")
public class OrderRest extends BaseRest {

	@Resource
	private OrderService orderService;

	/**
	 * 
	 * @param orderRequest
	 * @return
	 */
	@RequestMapping(value = "/create", method = { RequestMethod.POST })
	public RestResult createPersonCode(@RequestBody OrderRequest orderRequest) {
		OrderResponse orderResponse = orderService.createOrder(orderRequest);

		RestResult restResult = new RestResult();
		restResult.setData(orderResponse);

		return restResult;
	}

	/**
	 * 
	 * @param merchantCode
	 * @param payAmount
	 * @param payChannel
	 * @param sign
	 * @return
	 */
	@ApiOperation(value = "回调操作")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "merchantCode", value = "商户号", dataType = "String", paramType = "form", required = true),
			@ApiImplicitParam(name = "payAmount", value = "支付金额", dataType = "number", paramType = "form", required = true),
			@ApiImplicitParam(name = "payChannel", value = "支付渠道", dataType = "String", paramType = "form", required = true),
			@ApiImplicitParam(name = "sign", value = "签名", dataType = "String", paramType = "form", required = true) })
	@RequestMapping(value = "/callback", method = { RequestMethod.POST })
	public RestResult callback(String merchantCode, BigDecimal payAmount, PayChannelEnum payChannel, String sign) {
		RestResult restResult = new RestResult();

		orderService.validateAndDealOrder(merchantCode, payAmount, payChannel, sign, Boolean.FALSE);

		return restResult;
	}

	/**
	 * 
	 * @param merchantCode
	 * @param payAmount
	 * @param payChannel
	 * @param sign
	 * @return
	 */
	@ApiOperation(value = "回调操作")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "merchantCode", value = "商户号", dataType = "String", paramType = "form", required = true),
			@ApiImplicitParam(name = "payAmount", value = "支付金额", dataType = "number", paramType = "form", required = true),
			@ApiImplicitParam(name = "payChannel", value = "支付渠道", dataType = "String", paramType = "form", required = true),
			@ApiImplicitParam(name = "sign", value = "签名", dataType = "String", paramType = "form", required = true) })
	@RequestMapping(value = "/callbackForApp", method = { RequestMethod.POST })
	public RestResult callbackForApp(String merchantCode, BigDecimal payAmount, PayChannelEnum payChannel,
			String sign) {
		RestResult restResult = new RestResult();

		orderService.validateAndDealOrder(merchantCode, payAmount, payChannel, sign, Boolean.TRUE);

		return restResult;
	}

	/**
	 * 
	 * @param merchantCode
	 * @param code
	 * @param sign
	 * @return
	 */
	@ApiOperation(value = "手动回调")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "merchantCode", value = "商户号", dataType = "String", paramType = "form", required = true),
			@ApiImplicitParam(name = "code", value = "平台订单号", dataType = "String", paramType = "form", required = true),
			@ApiImplicitParam(name = "sign", value = "签名", dataType = "String", paramType = "form", required = true) })
	@RequestMapping(value = "/updateStatus", method = { RequestMethod.POST })
	public RestResult updateStatus(String merchantCode, String code, String sign) {
		RestResult restResult = new RestResult();

		orderService.updateStatus(merchantCode, code, sign);

		return restResult;
	}

	/**
	 * 
	 * @param merchantCode
	 * @param code
	 * @param sign
	 * @return
	 */
	@ApiOperation(value = "判断是否支付成功")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "merchantCode", value = "商户号", dataType = "String", paramType = "form", required = true),
			@ApiImplicitParam(name = "code", value = "平台订单号", dataType = "String", paramType = "form", required = true),
			@ApiImplicitParam(name = "sign", value = "签名", dataType = "String", paramType = "form", required = true) })
	@RequestMapping(value = "/isPaySuccess", method = { RequestMethod.POST })
	public RestResult isPaySuccess(String merchantCode, String code, String sign) {
		RestResult restResult = new RestResult();

		Boolean isPaySuccess = orderService.isPaySuccess(merchantCode, code, sign);

		restResult.setData(isPaySuccess);

		return restResult;
	}

	/**
	 * 
	 * @param pageNo
	 * @param pageSize
	 * @return
	 */
	@ApiOperation(value = "查询订单", response = OrderVo.class)
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "unique-code", value = "用戶token标识", dataType = "String", paramType = "header", required = true) })
	@RequestMapping(value = "/queryList", method = { RequestMethod.POST })
	public RestResult queryList(@RequestBody OrderQueryVo queryVo) {
		RestResult restResult = new RestResult();

		List<OrderVo> list = orderService.queryList(getCurrentMerchantId(), queryVo);

		restResult.setData(list);

		return restResult;
	}
}