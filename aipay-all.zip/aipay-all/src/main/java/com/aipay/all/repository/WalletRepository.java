package com.aipay.all.repository;

import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.aipay.all.entity.Wallet;

@Repository
public interface WalletRepository extends PagingAndSortingRepository<Wallet, Long> {

	Wallet findByMerchantCode(String merchantCode);
}