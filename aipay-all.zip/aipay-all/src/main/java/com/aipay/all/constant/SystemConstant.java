package com.aipay.all.constant;

import java.math.BigDecimal;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class SystemConstant {

	@Value("${package.environment}")
	private String packageEnvironment;

	/**
	 * 存储图片的cdn地址
	 */
	@Value("${aipay.oss.cdnUrl}")
	private String ossCdnUrl;

	/**
	 * 订单超时时间,单位为秒
	 */
	@Value("${order_expire_seconds}")
	private Long orderExpireSeconds;

	/**
	 * 订单获取实际支付金额重试次数
	 */
	@Value("${order_amount_fetch_count}")
	private Long orderAmountFetchCount;

	/**
	 * 最大订单金额
	 */
	@Value("${max_order_amount}")
	private BigDecimal maxOrderAmount;

	public String getPackageEnvironment() {
		return packageEnvironment;
	}

	public String getOssCdnUrl() {
		return ossCdnUrl;
	}

	public Long getOrderExpireSeconds() {
		return orderExpireSeconds;
	}

	public Long getOrderAmountFetchCount() {
		return orderAmountFetchCount;
	}

	public BigDecimal getMaxOrderAmount() {
		return maxOrderAmount;
	}
}