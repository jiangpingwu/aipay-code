package com.aipay.all.message;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class ConsumerProperties {

	@Value("${rocketmq.consumer.namesrvAddr}")
	private String namesrvAddr;

	@Value("${rocketmq.consumer.groupName}")
	private String groupName;

	@Value("${rocketmq.consumer.consumeThreadMin}")
	private Integer consumeThreadMin;

	@Value("${rocketmq.consumer.consumeThreadMax}")
	private Integer consumeThreadMax;

	public String getNamesrvAddr() {
		return namesrvAddr;
	}

	public String getGroupName() {
		return groupName;
	}

	public Integer getConsumeThreadMin() {
		return consumeThreadMin;
	}

	public Integer getConsumeThreadMax() {
		return consumeThreadMax;
	}
}