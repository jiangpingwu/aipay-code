package com.aipay.all.repository;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.apache.commons.lang3.StringUtils;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;

import com.aipay.all.entity.Order;
import com.aipay.all.vo.OrderQueryVo;
import com.aipay.common.enums.PayChannelEnum;
import com.aipay.common.enums.PayStatusEnum;
import com.aipay.common.util.DateUtil;

@Repository
public class OrderRepositoryImpl {

	@PersistenceContext
	private EntityManager em;

	/**
	 * 
	 * @param queryVo
	 * @param pageable
	 * @return
	 */
	public List<Order> queryList(OrderQueryVo queryVo, Pageable pageable) {
		CriteriaBuilder cb = em.getCriteriaBuilder();
		CriteriaQuery<Order> cq = cb.createQuery(Order.class);
		Root<Order> root = cq.from(Order.class);

		List<Predicate> paramList = new ArrayList<>();
		paramList.add(cb.equal(root.get("merchantCode").as(String.class), queryVo.getMerchantCode()));

		if (queryVo.getPayChannel() != null) {
			paramList.add(cb.equal(root.get("payChannel").as(PayChannelEnum.class), queryVo.getPayChannel()));
		}

		if (queryVo.getPayStatus() != null) {
			paramList.add(cb.equal(root.get("payStatus").as(PayStatusEnum.class), queryVo.getPayStatus()));
		}

		if (StringUtils.isNotEmpty(queryVo.getBeginDateTime()) && StringUtils.isNotEmpty(queryVo.getEndDateTime())) {
			LocalDateTime beginDateTime = DateUtil.toLocalDateTime(queryVo.getBeginDateTime());
			LocalDateTime endDateTime = DateUtil.toLocalDateTime(queryVo.getEndDateTime());

			paramList.add(cb.between(root.get("createDateTime").as(LocalDateTime.class), beginDateTime, endDateTime));
		}

		javax.persistence.criteria.Order order = cb.desc(root.get("createDateTime"));
		cq.orderBy(order);

		cq.where(paramList.toArray(new Predicate[paramList.size()]));

		TypedQuery<Order> tq = em.createQuery(cq).setFirstResult(pageable.getPageNumber() * pageable.getPageSize())
				.setMaxResults(pageable.getPageSize());

		List<Order> list = tq.getResultList();

		return list;
	}
}