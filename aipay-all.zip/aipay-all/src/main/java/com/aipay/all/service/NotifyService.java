package com.aipay.all.service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import javax.annotation.Resource;

import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.rocketmq.client.producer.DefaultMQProducer;
import org.apache.rocketmq.client.producer.SendResult;
import org.apache.rocketmq.common.message.Message;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.aipay.all.entity.Merchant;
import com.aipay.all.entity.Order;
import com.aipay.all.entity.Wallet;
import com.aipay.all.repository.MerchantRepository;
import com.aipay.all.repository.OrderRepository;
import com.aipay.all.repository.WalletRepository;
import com.aipay.common.bean.OrderNotify;
import com.aipay.common.enums.CountStatusEnum;
import com.aipay.common.enums.ModelEnum;
import com.aipay.common.enums.PayStatusEnum;
import com.aipay.common.enums.SignTypeEnum;
import com.aipay.common.exception.BusinessException;
import com.aipay.common.message.enums.MessageTagEnum;
import com.aipay.common.message.enums.MessageTopicEnum;
import com.aipay.common.message.msgobject.NotifyMerchantMessageObject;
import com.aipay.common.message.msgobject.SubtractBalanceMessageObject;
import com.aipay.common.util.DateUtil;
import com.alibaba.fastjson.JSONObject;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

@Service
@Transactional
public class NotifyService extends BaseService {
	@Resource(name = "messageProducer")
	private DefaultMQProducer messageProducer;

	@Resource
	private MerchantRepository merchantRepository;

	@Resource
	private OrderRepository orderRepository;

	@Resource
	private WalletRepository walletRepository;

	/**
	 * 
	 * @param msgObject
	 */
	public void notifyMerchant(NotifyMerchantMessageObject msgObject) {
		try {
			logger.info("获取到的notifyMerchantMessageObject={}", msgObject);

			Order order = orderRepository.findByCodeAndMerchantCode(msgObject.getOrderCode(),
					msgObject.getMerchantCode());

			if (order.getPayStatus() == PayStatusEnum.COMPLETED) {
				logger.warn("订单[" + msgObject.getOrderCode() + "]已经处理完毕了");

				return;
			}

			if (order.getPayStatus() != PayStatusEnum.PAYED) {
				throw new IllegalStateException("订单[" + msgObject.getOrderCode() + "]不是已支付状态,不能进行通知商户的操作");
			}

			logger.info("获取到的order={}", order);

			OrderNotify notify = new OrderNotify();
			notify.setCode(order.getCode());
			notify.setMerchantCode(order.getMerchantCode());
			notify.setTradeNo(order.getOutTradeNo());
			notify.setPayChannel(order.getPayChannel());
			notify.setTotalAmount(order.getTotalAmount());
			notify.setPayAmount(order.getPayAmount());

			if (StringUtils.isNotEmpty(order.getPassbackData())) {
				Map<String, Object> map = JSONObject.parseObject(order.getPassbackData(), new HashMap<>().getClass());

				notify.setPassbackData(map);
			}

			notify.setPayDateTime(DateUtil.formatLocalDateTime(order.getPayDateTime()));
			notify.setModel(order.getModel());
			notify.setSignType(order.getSignType());

			if (notify.getModel() != ModelEnum.NONE && order.getSignType() != SignTypeEnum.NONE) {
				StringBuilder signSb = new StringBuilder();
				signSb.append("code=").append(notify.getCode());
				signSb.append("&merchantCode=").append(notify.getMerchantCode());
				signSb.append("&payAmount=").append(String.valueOf(notify.getPayAmount()));
				signSb.append("&payChannel=").append(notify.getPayChannel().toString());
				signSb.append("&totalAmount=").append(String.valueOf(notify.getTotalAmount()));

				Merchant merchant = merchantRepository.findByCode(order.getMerchantCode());
				signSb.append("&appSecret=").append(merchant.getAppSecret());

				String sign = DigestUtils.md5Hex(signSb.toString()).toUpperCase();

				notify.setSign(sign);
			}

			// 通过restTemplate发送http请求,数据格式为json串,商户后台使用request.getInputStream()接收数据
			JSONObject jsonObject = (JSONObject) JSONObject.toJSON(notify);

			String requestJson = jsonObject.toString();

			logger.info("发送给商户的数据={}", requestJson);

			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.parseMediaType("application/json; charset=UTF-8"));
			headers.add("Accept", MediaType.APPLICATION_JSON.toString());

			HttpEntity<String> formEntity = new HttpEntity<>(requestJson, headers);

			String result = restTemplate.postForObject(order.getNotifyUrl(), formEntity, String.class);

			if (StringUtils.isNotEmpty(result) && result.equals("SUCCESS")) {
				orderRepository.updateToCompleteStatus(PayStatusEnum.COMPLETED, LocalDateTime.now(),
						LocalDateTime.now(), order.getId(), order.getMerchantCode());
			} else {
				throw new IllegalStateException("通知商户处理失败,返回的result=" + result);
			}

			logger.info("平台通知商户操作成功,orderCode={},result={}", order.getCode(), result);

			// 订单回调完成后,发送扣减订单服务费的消息通知
			SubtractBalanceMessageObject subtractBalanceMessageObject = new SubtractBalanceMessageObject();
			subtractBalanceMessageObject.setOrderCode(order.getCode());
			subtractBalanceMessageObject.setMerchantCode(order.getMerchantCode());

			Gson gson = new GsonBuilder().create();
			String body = gson.toJson(subtractBalanceMessageObject);

			Message msg = new Message(MessageTopicEnum.MERCHANT.toString(), MessageTagEnum.SUBTRACT_BALANCE.toString(),
					UUID.randomUUID().toString(), body.getBytes());

			SendResult sendResult = messageProducer.send(msg);

			logger.info("发送扣减订单服务费消息结果sendResult={}", sendResult);
		} catch (IllegalArgumentException | IllegalStateException e) {
			throw e;
		} catch (Exception e) {
			throw new BusinessException("通知商户处理出错", e);
		}
	}

	/**
	 * 对扣减商户订单服务费的操作进行同步,防止并发问题导致过多的重试操作
	 * 
	 * @param msgObject
	 */
	public synchronized void subtractBalance(SubtractBalanceMessageObject msgObject) {
		try {
			logger.info("获取到的subtractBalanceMessageObject={}", msgObject);

			Order order = orderRepository.findByCodeAndMerchantCode(msgObject.getOrderCode(),
					msgObject.getMerchantCode());

			if (order == null) {
				throw new IllegalStateException("找不到订单信息");
			}

			if (order.getPayStatus() != PayStatusEnum.COMPLETED) {
				throw new IllegalStateException("订单[" + order.getCode() + "]不是已完成状态,不能进行服务费扣减操作");
			}

			if (order.getCountStatus() == CountStatusEnum.COUNTED) {
				logger.warn("订单[" + order.getCode() + "]已经扣除了服务费,不能重复操作");
				return;
			}

			// 减扣用户的余额
			Wallet wallet = walletRepository.findByMerchantCode(msgObject.getMerchantCode());

			if (wallet == null) {
				throw new IllegalStateException("找不到用户的钱包信息");
			}

			BigDecimal newBalance = wallet.getBalance().subtract(order.getServiceAmout()).setScale(4,
					RoundingMode.HALF_UP);

			logger.info("计算出来的newBalance={},walletId={},walletMerchantCode={}", newBalance, wallet.getId(),
					wallet.getMerchantCode());

			wallet.setBalance(newBalance);
			wallet.setUpdateDateTime(LocalDateTime.now());

			walletRepository.save(wallet);

			// 更新订单结算状态
			orderRepository.update(CountStatusEnum.COUNTED, LocalDateTime.now(), order.getId(),
					order.getMerchantCode());

			logger.info("减扣订单[{}]服务费{}成功,当前用户余额={}", order.getCode(), order.getServiceAmout(), newBalance);
		} catch (IllegalArgumentException | IllegalStateException e) {
			throw e;
		} catch (Exception e) {
			throw new BusinessException("扣减订单服务费处理出错", e);
		}
	}
}