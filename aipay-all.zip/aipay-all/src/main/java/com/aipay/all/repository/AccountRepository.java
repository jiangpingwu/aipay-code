package com.aipay.all.repository;

import java.util.List;

import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.aipay.all.entity.Account;
import com.aipay.common.enums.PayChannelEnum;

@Repository
public interface AccountRepository extends PagingAndSortingRepository<Account, Long> {

	Account findByMerchantCodeAndPayChannelAndIsDefault(String merchantCode, PayChannelEnum payChannel,
			Boolean isDefault);

	List<Account> findByMerchantCodeAndPayChannel(String merchantCode, PayChannelEnum payChannel);
}