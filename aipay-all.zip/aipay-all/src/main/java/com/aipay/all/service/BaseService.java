package com.aipay.all.service;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.web.client.RestTemplate;

import com.aipay.all.constant.OtherConstant;
import com.aipay.all.constant.SystemConstant;

public class BaseService {
	protected Logger logger = LoggerFactory.getLogger(getClass());

	@Resource
	protected SystemConstant systemConstant;

	@Resource
	protected RedisTemplate redisTemplate;

	@Resource
	protected RestTemplate restTemplate;

	/**
	 * 
	 * @param pageNo
	 * @param pageSize
	 */
	protected void validatePageRequest(Integer pageNo, Integer pageSize) {
		if (pageNo == null || pageNo <= 0) {
			throw new IllegalArgumentException("pageNo必须大于等于1");
		}

		if (pageSize == null || pageSize <= 0) {
			throw new IllegalArgumentException("pageSize必须大于等于1");
		}

		if (pageSize > OtherConstant.DEFAULT_MAX_PAGE_SIZE) {
			throw new IllegalArgumentException("pageSize不能大于" + OtherConstant.DEFAULT_MAX_PAGE_SIZE);
		}
	}

	/**
	 * 
	 * @param pageNo
	 * @param pageSize
	 */
	protected PageRequest validateAndFetchPageRequest(Integer pageNo, Integer pageSize) {
		validatePageRequest(pageNo, pageSize);

		PageRequest pageRequest = new PageRequest(pageNo - 1, pageSize,
				new Sort(Sort.Direction.DESC, "createDateTime"));

		return pageRequest;
	}
}
