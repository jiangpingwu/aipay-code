package com.aipay.all.rest;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.aipay.common.constant.RestResult;

/**
 * 
 * @author admin
 */
@RestController
@RequestMapping(value = "/out")
public class OutInterfaceRest extends BaseRest {

	/**
	 * 
	 * @return
	 */
	@RequestMapping(value = "/ack", method = { RequestMethod.GET, RequestMethod.POST })
	public RestResult ack() {
		RestResult result = new RestResult();

		try {
			// do none
		} catch (Exception e) {
			logger.error("心跳检测出错了", e);
		}

		return result;
	}
}