package com.aipay.all.entity;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Index;
import javax.persistence.Lob;
import javax.persistence.Table;
import javax.persistence.Version;

import com.aipay.common.enums.CodeTypeEnum;
import com.aipay.common.enums.CountStatusEnum;
import com.aipay.common.enums.ModelEnum;
import com.aipay.common.enums.PayChannelEnum;
import com.aipay.common.enums.PayStatusEnum;
import com.aipay.common.enums.SignTypeEnum;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

/**
 * 订单信息,数据量比较大,需要进行路由分库操作
 *
 * @author admin
 */
@Entity
@Table(name = "orders", indexes = { @Index(columnList = "code", unique = true) })
@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
public class Order extends BaseDateTimeEntity {
	private static final long serialVersionUID = 1L;

	/**
	 * 商户编码,作为DRDS路由字段
	 */
	private String merchantCode;

	/**
	 * 商户编号
	 */
	private Long merchantId;

	/**
	 * 冗余存储:关联的账号编号,可以为空
	 */
	private Long accountId;

	/**
	 * 订单编码,唯一标识一条订单记录
	 */
	private String code;

	/**
	 * 商户的交易标识
	 */
	private String outTradeNo;

	/**
	 * 总的订单金额,以元为单位,保留两位小数
	 */
	private BigDecimal totalAmount = BigDecimal.ZERO;

	/**
	 * 系统生成的随机支付金额,以元为单位,保留两位小数
	 */
	private BigDecimal payAmount = BigDecimal.ZERO;

	/**
	 * 保留字段:实际支付金额,如果支付宝或微信有红包抵扣,那么实际支付金额就会小于订单金额,一般与payAmount一样,以元为单位,保留两位小数
	 */
	private BigDecimal actualAmount = BigDecimal.ZERO;

	/**
	 * 每笔订单的手续费,根据rate计算出来,保留4位小数
	 */
	@Column(columnDefinition = "decimal(19,4)")
	private BigDecimal serviceAmout = BigDecimal.ZERO;

	/**
	 * 商品标题,该参数最长为32个Unicode字符
	 */
	private String subject;

	/**
	 * 商品描述信息,该参数最长为128个Unicode字符
	 */
	private String body;

	/**
	 * 接收通知的URL，需给绝对路径，255字符内格式，确保平台能通过互联网访问该地址
	 */
	private String notifyUrl;

	/**
	 * 支付成功后页面跳转的地址,有些支付渠道可以为空
	 */
	private String returnUrl;

	/**
	 * 扩展的参数数据,该参数最长为1024个Unicode字符
	 */
	@Lob
	private String extraData;

	/**
	 * 需要回传的参数数据,该参数最长为256个Unicode字符
	 */
	private String passbackData;

	/**
	 * 收款码生成类型
	 */
	@Enumerated(value = EnumType.STRING)
	private CodeTypeEnum codeType = CodeTypeEnum.IMAGE_URL;

	/**
	 * 支付状态
	 */
	@Enumerated(value = EnumType.STRING)
	private PayStatusEnum payStatus = PayStatusEnum.UNPAY;

	/**
	 * 结算状态
	 */
	@Enumerated(value = EnumType.STRING)
	private CountStatusEnum countStatus = CountStatusEnum.UNCOUNT;

	/**
	 * 支付渠道
	 */
	@Enumerated(value = EnumType.STRING)
	private PayChannelEnum payChannel;

	/**
	 * 备注信息
	 */
	private String remark;

	/**
	 * 标识这次支付是测试还是生产数据
	 */
	@Enumerated(value = EnumType.STRING)
	private ModelEnum model = ModelEnum.TEST;

	/**
	 * 签名类型
	 */
	@Enumerated(value = EnumType.STRING)
	private SignTypeEnum signType = SignTypeEnum.MD5;

	/**
	 * 客户端ip
	 */
	private String clientIp;

	/**
	 * 商户提交订单的时间,支付中心保存订单的时间通过createDateTime属性记录
	 */
	private LocalDateTime outDateTime;

	/**
	 * 订单的过期时间,不同支付渠道的过期时间不一样,这里默认为3分钟
	 */
	private LocalDateTime expireDateTime;

	/**
	 * 支付成功的时间,收到了支付提供商的回调通知,但是还没有通知商户
	 */
	private LocalDateTime payDateTime;

	/**
	 * 订单完成时间,支付中心异步通知了商户,并且接收到了返回结果
	 */
	private LocalDateTime completeDateTime;

	/**
	 * 乐观锁标识
	 */
	@Version
	private Long version = 1L;
}
