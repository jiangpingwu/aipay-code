package com.aipay.all.message;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class ProducerProperties {

	@Value("${rocketmq.producer.groupName}")
	private String groupName;

	@Value("${rocketmq.producer.namesrvAddr}")
	private String namesrvAddr;

	@Value("${rocketmq.producer.sendMsgTimeout}")
	private Integer sendMsgTimeout;

	public String getGroupName() {
		return groupName;
	}

	public String getNamesrvAddr() {
		return namesrvAddr;
	}

	public Integer getSendMsgTimeout() {
		return sendMsgTimeout;
	}
}