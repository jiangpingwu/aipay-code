package com.aipay.all.message;

import java.util.List;

import org.apache.rocketmq.client.consumer.listener.ConsumeConcurrentlyContext;
import org.apache.rocketmq.client.consumer.listener.ConsumeConcurrentlyStatus;
import org.apache.rocketmq.client.consumer.listener.MessageListenerConcurrently;
import org.apache.rocketmq.common.message.MessageExt;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.aipay.all.service.NotifyService;
import com.aipay.common.message.enums.MessageTagEnum;
import com.aipay.common.message.msgobject.NotifyMerchantMessageObject;
import com.aipay.common.message.msgobject.SubtractBalanceMessageObject;
import com.google.gson.GsonBuilder;

public class DefaultMessageListener implements MessageListenerConcurrently {
	protected Logger logger = LoggerFactory.getLogger(getClass());

	private NotifyService notifyService;

	@Override
	public ConsumeConcurrentlyStatus consumeMessage(List<MessageExt> msgs, ConsumeConcurrentlyContext context) {
		try {
			MessageExt msg = msgs.get(0);

			String body = new String(msg.getBody());

			logger.info("返回的topic={},tag={},消息体body={},重试次数={}", msg.getTopic(), msg.getTags(), body,
					msg.getReconsumeTimes());

			if (msg.getTags().equals(MessageTagEnum.NOTIFY_MERCHANT.toString())) {
				NotifyMerchantMessageObject msgObject = new GsonBuilder().create().fromJson(body,
						NotifyMerchantMessageObject.class);

				notifyService.notifyMerchant(msgObject);
			} else if (msg.getTags().equals(MessageTagEnum.SUBTRACT_BALANCE.toString())) {
				SubtractBalanceMessageObject msgObject = new GsonBuilder().create().fromJson(body,
						SubtractBalanceMessageObject.class);

				notifyService.subtractBalance(msgObject);
			} else {
				logger.warn("没有找到对应topic=[{}],tag=[{}]的消费者", msg.getTopic(), msg.getTags());

				return ConsumeConcurrentlyStatus.RECONSUME_LATER;
			}

			return ConsumeConcurrentlyStatus.CONSUME_SUCCESS;
		} catch (Exception e) {
			logger.error("消息处理失败了", e);

			return ConsumeConcurrentlyStatus.RECONSUME_LATER;
		}
	}

	public void setNotifyService(NotifyService notifyService) {
		this.notifyService = notifyService;
	}
}