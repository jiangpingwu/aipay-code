package com.aipay.all.vo;

import com.aipay.common.enums.PayChannelEnum;
import com.aipay.common.enums.PayStatusEnum;
import com.aipay.common.vo.BaseValueObject;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 *
 * @author admin
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class OrderQueryVo extends BaseValueObject {
	private static final long serialVersionUID = 1L;

	private String merchantCode;
	
	private PayChannelEnum payChannel;

	private PayStatusEnum payStatus;

	private String beginDateTime;

	private String endDateTime;
	
	private Integer pageNo;
	
	private Integer pageSize;
}
