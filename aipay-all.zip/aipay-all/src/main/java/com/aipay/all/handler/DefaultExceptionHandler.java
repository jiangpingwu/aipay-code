package com.aipay.all.handler;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.aipay.common.constant.RestResult;
import com.aipay.common.constant.ReturnCode;
import com.aipay.common.exception.BusinessException;
import com.aipay.common.exception.NoLoginException;
import com.aipay.common.exception.ValidateException;

@ControllerAdvice
public class DefaultExceptionHandler {
	private static Logger logger = LoggerFactory.getLogger(DefaultExceptionHandler.class);

	/**
	 * 
	 * @param e
	 * @return
	 */
	@ResponseBody
	@ExceptionHandler(value = Exception.class)
	@ResponseStatus(HttpStatus.OK)
	public RestResult handleException(Exception e) {
		RestResult result = new RestResult();

		if (e instanceof IllegalArgumentException || e instanceof IllegalStateException) {
			result.setStatus(ReturnCode.REC_2.getCode());
			result.setMsg(e.getMessage());
		} else if (e instanceof ValidateException) {
			ValidateException validateException = (ValidateException) e;

			result.setStatus(validateException.getErrorCode());
			result.setMsg(validateException.getErrorMsg());
		} else if (e instanceof NoLoginException) {
			result.setStatus(ReturnCode.REC_NEGATIVE_1.getCode());
			result.setMsg(e.getMessage());
		} else if (e instanceof BusinessException) {
			result.setStatus(ReturnCode.REC_0.getCode());
			result.setMsg(ReturnCode.REC_0.getName());
		} else {
			result.setStatus(ReturnCode.REC_0.getCode());
			result.setMsg(ReturnCode.REC_0.getName());
		}

		logger.error("请求出错了", e);

		return result;
	}
}