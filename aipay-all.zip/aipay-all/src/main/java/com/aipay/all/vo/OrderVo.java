package com.aipay.all.vo;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import com.aipay.common.enums.PayChannelEnum;
import com.aipay.common.enums.PayStatusEnum;
import com.aipay.common.vo.BaseValueObject;
import com.fasterxml.jackson.annotation.JsonFormat;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
public class OrderVo extends BaseValueObject {
	private static final long serialVersionUID = 1L;

	/**
	 * 平台订单编码,唯一标识一条订单记录
	 */
	@ApiModelProperty(value = "订单编码")
	private String code;

	/**
	 * 商户的交易标识
	 */
	private String outTradeNo;

	/**
	 * 总的订单金额,以元为单位,保留两位小数
	 */
	@ApiModelProperty(value = "订单金额")
	private BigDecimal totalAmount = BigDecimal.ZERO;

	/**
	 * 系统生成的随机支付金额,以元为单位,保留两位小数
	 */
	@ApiModelProperty(value = "实际支付金额")
	private BigDecimal payAmount = BigDecimal.ZERO;

	/**
	 * 商品标题,该参数最长为32个Unicode字符
	 */
	@ApiModelProperty(value = "商品标题")
	private String subject;

	/**
	 * 商品描述信息,该参数最长为128个Unicode字符
	 */
	@ApiModelProperty(value = "商品描述")
	private String body;

	/**
	 * 支付状态
	 */
	@ApiModelProperty(value = "支付状态编码")
	private PayStatusEnum payStatus;

	@ApiModelProperty(value = "支付状态名称")
	private String payStatusName;

	/**
	 * 支付渠道
	 */
	@ApiModelProperty(value = "支付渠道编码")
	private PayChannelEnum payChannel;

	@ApiModelProperty(value = "支付渠道名称")
	private String payChannelName;

	/**
	 * 创建时间
	 */
	@ApiModelProperty(value = "创建时间")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private LocalDateTime createDateTime;

	@ApiModelProperty(value = "备注时间")
	private String remark;
}
