package com.aipay.all.constant;

public class RedisConstant {

	/**
	 * 用户uniqueCode和id对象关系
	 */
	public static final String REDIS_USER_UNIQUE_CODES = "aipay_user_uniqueCodes";
}