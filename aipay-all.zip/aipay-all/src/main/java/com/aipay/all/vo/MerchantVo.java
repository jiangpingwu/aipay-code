package com.aipay.all.vo;

import java.math.BigDecimal;

import com.aipay.common.enums.MerchantStatusEnum;
import com.aipay.common.enums.MerchantTypeEnum;
import com.aipay.common.vo.BaseValueObject;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@ApiModel(value = "商户信息")
@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
public class MerchantVo extends BaseValueObject {
	private static final long serialVersionUID = 1L;

	/**
	 * 商户编码
	 */
	@ApiModelProperty(value = "商户编码")
	private String code;

	/**
	 * 绑定的手机号
	 */
	@ApiModelProperty(value = "手机号")
	private String mobile;

	@ApiModelProperty(value = "qq号")
	private String qq;

	@ApiModelProperty(value = "邮箱")
	private String email;

	/**
	 * 签名时使用的appSecret
	 */
	@ApiModelProperty(value = "二次加密后的商户密钥")
	private String appSecret;

	/**
	 * 余额
	 */
	@ApiModelProperty(value = "余额")
	private BigDecimal balance = BigDecimal.ZERO;

	/**
	 * 状态
	 */
	@ApiModelProperty(value = "商户状态")
	private MerchantStatusEnum status;

	@ApiModelProperty(value = "商户状态名称")
	private String statusName;

	/**
	 * 类型
	 */
	@ApiModelProperty(value = "商户类型")
	private MerchantTypeEnum type;

	@ApiModelProperty(value = "商户类型名称")
	private String typeName;

	@ApiModelProperty(value = "汇率")
	private BigDecimal rate = BigDecimal.ZERO;
}
