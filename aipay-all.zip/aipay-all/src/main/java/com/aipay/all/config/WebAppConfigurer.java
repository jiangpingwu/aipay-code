package com.aipay.all.config;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import com.aipay.all.constant.SystemConstant;
import com.aipay.all.interceptor.LoginInterceptor;

@Configuration
public class WebAppConfigurer extends WebMvcConfigurerAdapter {

	@Resource
	private SystemConstant systemConstant;

	/**
	 * 
	 * @param registry
	 */
	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		super.addInterceptors(registry);

		List<String> memberList = new ArrayList<>();
		memberList.add("/merchant/register");
		memberList.add("/merchant/login");
		memberList.add("/merchant/logout");
		
		List<String> orderList = new ArrayList<>();
		orderList.add("/order/create");
		orderList.add("/order/callback");
		orderList.add("/order/callbackForApp");
		orderList.add("/order/updateStatus");
		orderList.add("/order/isPaySuccess");

		List<String> otherList = new ArrayList<>();
		otherList.add("/out/**");

		List<String> list = new ArrayList<>();
		list.addAll(memberList);
		list.addAll(orderList);
		list.addAll(otherList);

		LoginInterceptor loginInterceptor = new LoginInterceptor();
		registry.addInterceptor(loginInterceptor).addPathPatterns("/**")
				.excludePathPatterns(list.toArray(new String[list.size()]));
	}

	/**
	 * 跨域配置
	 *
	 * @param registry
	 */
	@Override
	public void addCorsMappings(CorsRegistry registry) {
		registry.addMapping("/**").allowedHeaders("*").allowedMethods("*").allowedOrigins("*");
	}
}