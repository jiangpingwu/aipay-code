package com.aipay.all.rest;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.aipay.all.vo.MerchantVo;
import com.aipay.common.constant.RestResult;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(value = "/merchant")
public class MerchantRest extends BaseRest {

	/**
	 * 
	 * @param mobile
	 * @param password
	 * @return
	 */
	@ApiOperation(value = "登录")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "mobile", value = "手机号", dataType = "String", paramType = "form", required = true),
			@ApiImplicitParam(name = "password", value = "密码", dataType = "String", paramType = "form", required = true) })
	@RequestMapping(value = "/login", method = { RequestMethod.POST })
	public RestResult login(String mobile, String password) {
		RestResult result = new RestResult();

		String uniqueCode = merchantService.login(mobile, password, getDeviceCode());

		result.setData(uniqueCode);

		return result;
	}

	@ApiOperation(value = "退出登录")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "unique-code", value = "用戶token标识", dataType = "String", paramType = "header", required = true) })
	@RequestMapping(value = "/logout", method = { RequestMethod.POST })
	public RestResult logout() {
		RestResult result = new RestResult();

		merchantService.logout(getCurrentMerchantId());

		return result;
	}

	/**
	 * 
	 * @return
	 */
	@ApiOperation(value = "获取商户详细信息", response = MerchantVo.class)
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "unique-code", value = "用戶token标识", dataType = "String", paramType = "header", required = true) })
	@RequestMapping(value = "/getDetailInfo", method = { RequestMethod.POST })
	public RestResult getDetailInfo() {
		RestResult result = new RestResult();

		MerchantVo vo = merchantService.getDetailInfo(getCurrentMerchantId());

		result.setData(vo);

		return result;
	}
}