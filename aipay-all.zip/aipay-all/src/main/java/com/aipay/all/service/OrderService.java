package com.aipay.all.service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import javax.annotation.Resource;

import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.rocketmq.client.producer.DefaultMQProducer;
import org.apache.rocketmq.client.producer.SendResult;
import org.apache.rocketmq.common.message.Message;
import org.springframework.beans.BeanUtils;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.aipay.all.entity.Account;
import com.aipay.all.entity.Merchant;
import com.aipay.all.entity.Order;
import com.aipay.all.entity.Wallet;
import com.aipay.all.repository.AccountRepository;
import com.aipay.all.repository.MerchantRepository;
import com.aipay.all.repository.OrderRepository;
import com.aipay.all.repository.WalletRepository;
import com.aipay.all.vo.OrderQueryVo;
import com.aipay.all.vo.OrderVo;
import com.aipay.common.bean.OrderRequest;
import com.aipay.common.bean.OrderResponse;
import com.aipay.common.constant.ReturnCode;
import com.aipay.common.enums.CodeTypeEnum;
import com.aipay.common.enums.CountStatusEnum;
import com.aipay.common.enums.MerchantStatusEnum;
import com.aipay.common.enums.ModelEnum;
import com.aipay.common.enums.PayChannelEnum;
import com.aipay.common.enums.PayStatusEnum;
import com.aipay.common.enums.SignTypeEnum;
import com.aipay.common.exception.BusinessException;
import com.aipay.common.exception.ValidateException;
import com.aipay.common.message.enums.MessageTagEnum;
import com.aipay.common.message.enums.MessageTopicEnum;
import com.aipay.common.message.msgobject.CallbackRecordMessageObject;
import com.aipay.common.message.msgobject.NotifyMerchantMessageObject;
import com.aipay.common.util.CodeUtil;
import com.aipay.common.util.DateUtil;
import com.alibaba.fastjson.JSONObject;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

@Service
@Transactional
public class OrderService extends BaseService {
	@Resource(name = "messageProducer")
	private DefaultMQProducer messageProducer;

	@Resource
	private MerchantRepository merchantRepository;

	@Resource
	private AccountRepository accountRepository;

	@Resource
	private OrderRepository orderRepository;

	@Resource
	private WalletRepository walletRepository;

	/**
	 * 创建订单时需要进行相应的参数验证和验签操作,具体的支付逻辑的由底层的payBusiness实现
	 *
	 * @param orderRequest
	 * @return
	 */
	public OrderResponse createOrder(OrderRequest orderRequest) {
		validateRange(orderRequest);

		try {
			Merchant merchant = merchantRepository.findByCode(orderRequest.getMerchantCode());

			if (merchant == null) {
				throw new ValidateException(ReturnCode.REC_2001.getCode(), "商户不存在");
			}

			if (merchant.getStatus() != MerchantStatusEnum.NORMAL) {
				throw new ValidateException(ReturnCode.REC_2006.getCode(), "该商户为禁用状态");
			}

			// 验证签名
			validateSign(orderRequest, merchant);

			Account account = accountRepository.findByMerchantCodeAndPayChannelAndIsDefault(merchant.getCode(),
					orderRequest.getPayChannel(), Boolean.TRUE);

			if (account == null) {
				throw new ValidateException(ReturnCode.REC_2003.getCode(), "没有找到绑定的账号信息");
			}

			// 保存支付数据
			Order order = new Order();
			order.setMerchantId(merchant.getId());
			order.setMerchantCode(merchant.getCode());
			order.setAccountId(account.getId());
			order.setCode(CodeUtil.generateOrderCode(merchant.getId()));
			order.setOutTradeNo(orderRequest.getTradeNo());
			order.setTotalAmount(orderRequest.getTotalAmount());
			order.setSubject(orderRequest.getSubject());
			order.setBody(orderRequest.getBody());

			if (orderRequest.getExtraData() != null) {
				String jsonStr = JSONObject.toJSONString(orderRequest.getExtraData());

				order.setExtraData(jsonStr);
			}

			if (orderRequest.getPassbackData() != null) {
				String jsonStr = JSONObject.toJSONString(orderRequest.getPassbackData());

				order.setPassbackData(jsonStr);
			}

			order.setClientIp(orderRequest.getClientIp());
			order.setModel(orderRequest.getModel());
			order.setSignType(orderRequest.getSignType());
			order.setCodeType(orderRequest.getCodeType());
			order.setPayStatus(PayStatusEnum.UNPAY);
			order.setCountStatus(CountStatusEnum.UNCOUNT);
			order.setPayChannel(orderRequest.getPayChannel());
			order.setNotifyUrl(orderRequest.getNotifyUrl());
			order.setReturnUrl(orderRequest.getReturnUrl());
			order.setOutDateTime(DateUtil.toLocalDateTime(orderRequest.getRequestDateTime()));
			order.setCreateDateTime(LocalDateTime.now());
			order.setExpireDateTime(order.getCreateDateTime().plusSeconds(systemConstant.getOrderExpireSeconds()));
			order.setRemark(orderRequest.getRemark());

			fetchAndFillPayAmount(order); // 获取真实支付金额

			countAndFillServiceAmount(merchant, order); // // 计算剩余余额是否可以创建支付订单服务费

			orderRepository.save(order);

			// 处理返回数据
			OrderResponse orderResponse = new OrderResponse();
			orderResponse.setMerchantCode(order.getMerchantCode());
			orderResponse.setCode(order.getCode());
			orderResponse.setTradeNo(orderRequest.getTradeNo());
			orderResponse.setPayChannel(order.getPayChannel());
			orderResponse.setTradeNo(order.getOutTradeNo());
			orderResponse.setTotalAmount(order.getTotalAmount());
			orderResponse.setPayAmount(order.getPayAmount());

			if (order.getCodeType() == CodeTypeEnum.IMAGE_URL) {
				orderResponse.setCodeContent(systemConstant.getOssCdnUrl() + account.getImageUrl());
			} else if (order.getCodeType() == CodeTypeEnum.BASE64_IMAGE) {
				orderResponse.setCodeContent(account.getBase64Image());
			} else {
				orderResponse.setCodeContent("");
			}

			orderResponse.setCreateDateTime(DateUtil.formatLocalDateTime(order.getCreateDateTime()));
			orderResponse.setExpireDateTime(DateUtil.formatLocalDateTime(order.getExpireDateTime()));
			orderResponse.setModel(order.getModel());

			return orderResponse;
		} catch (IllegalArgumentException | IllegalStateException | ValidateException e) {
			throw e;
		} catch (Exception e) {
			throw new BusinessException("创建支付订单出错了", e);
		}
	}

	/**
	 * 
	 * @param merchantCode
	 * @param payAmount
	 * @param payChannel
	 * @param sign
	 * @param isApp
	 *            标识是否来自浏览器的请求
	 */
	public void validateAndDealOrder(String merchantCode, BigDecimal payAmount, PayChannelEnum payChannel, String sign,
			Boolean isApp) {
		if (StringUtils.isEmpty(merchantCode)) {
			throw new IllegalArgumentException("商户号不能为空");
		}

		if (payAmount == null || payAmount.compareTo(BigDecimal.ZERO) == 0) {
			throw new IllegalArgumentException("金额不能为空");
		}

		if (payChannel == null) {
			throw new IllegalArgumentException("支付渠道不能为空");
		}

		try {
			Merchant merchant = merchantRepository.findByCode(merchantCode);

			if (merchant == null) {
				throw new IllegalStateException("找不到商户信息");
			}

			LocalDateTime endDateTime = LocalDateTime.now().minusSeconds(systemConstant.getOrderExpireSeconds());

			logger.info("获取时间endDateTime={}", DateUtil.formatLocalDateTime(endDateTime));

			Order order = orderRepository
					.findTop1ByMerchantCodeAndPayAmountAndPayChannelAndCreateDateTimeGreaterThanEqualOrderByCreateDateTimeDesc(
							merchant.getCode(), payAmount, payChannel, endDateTime);

			if (order == null) {
				throw new IllegalStateException("找不到订单信息");
			}

			// 验证签名是否正确,线上环境应该关闭NONE模式和NONE签名类型
			if (order.getModel() != ModelEnum.NONE && order.getSignType() != SignTypeEnum.NONE) {
				if (StringUtils.isEmpty(sign)) {
					throw new IllegalArgumentException("签名不能为空");
				}

				StringBuilder signSb = new StringBuilder();
				signSb.append("merchantCode=").append(merchant.getCode());
				signSb.append("&payAmount=").append(String.valueOf(payAmount));
				signSb.append("&payChannel=").append(payChannel.toString());

				if (isApp) {
					signSb.append("&appSecret=").append(DigestUtils.md5Hex(merchant.getAppSecret()).toUpperCase());
				} else {
					signSb.append("&appSecret=").append(merchant.getAppSecret());
				}

				String newSign = DigestUtils.md5Hex(signSb.toString()).toUpperCase();

				if (!sign.equals(newSign)) {
					throw new IllegalStateException("签名不正确");
				}
			}

			if (order.getPayStatus() != PayStatusEnum.UNPAY) {
				throw new IllegalStateException("不是未支付的订单,不需要进行回调处理");
			}

			orderRepository.updateToPayStatus(PayStatusEnum.PAYED, LocalDateTime.now(), LocalDateTime.now(), order.getId(),
					order.getMerchantCode());

			// 回调处理完成后,再通过消息机制向商户发送异步通知
			NotifyMerchantMessageObject msgObject = new NotifyMerchantMessageObject();
			msgObject.setOrderCode(order.getCode());
			msgObject.setMerchantCode(order.getMerchantCode());

			String body = new GsonBuilder().create().toJson(msgObject);

			Message msg = new Message(MessageTopicEnum.ORDER.toString(), MessageTagEnum.NOTIFY_MERCHANT.toString(),
					UUID.randomUUID().toString(), body.getBytes());

			SendResult sendResult = messageProducer.send(msg);

			logger.info("发送通知商户的消息结果sendResult={}", sendResult);

			// 删除redis的支付金额
			String key = merchant.getCode() + "_" + order.getPayChannel().toString() + "_AMOUNT";

			try {
				redisTemplate.boundHashOps(key).delete(String.valueOf(order.getPayAmount()));
			} catch (Exception e) {
				logger.error("删除key={}中的支付金额出错", key, e);
			}
		} catch (IllegalArgumentException | IllegalStateException e) {
			throw e;
		} catch (Exception e) {
			throw new BusinessException("支付通知处理出错", e);
		}
	}

	/**
	 * 手动通知
	 * 
	 * @param merchantCode
	 * @param code
	 * @param sign
	 */
	public void updateStatus(String merchantCode, String code, String sign) {
		if (StringUtils.isEmpty(merchantCode)) {
			throw new IllegalArgumentException("商户号不能为空");
		}

		if (StringUtils.isEmpty(code)) {
			throw new IllegalArgumentException("订单号不能为空");
		}

		try {
			Merchant merchant = merchantRepository.findByCode(merchantCode);

			if (merchant == null) {
				throw new IllegalStateException("找不到商户信息");
			}

			Order order = orderRepository.findByCodeAndMerchantCode(code, merchant.getCode());

			if (order == null) {
				throw new IllegalStateException("找不到订单信息");
			}

			// 验证签名是否正确
			if (order.getModel() != ModelEnum.NONE && order.getSignType() != SignTypeEnum.NONE) {
				if (StringUtils.isEmpty(sign)) {
					throw new IllegalArgumentException("签名不能为空");
				}

				StringBuilder signSb = new StringBuilder();
				signSb.append("code=").append(code);
				signSb.append("&merchantCode=").append(merchant.getCode());
				signSb.append("&appSecret=").append(DigestUtils.md5Hex(merchant.getAppSecret()).toUpperCase());

				String newSign = DigestUtils.md5Hex(signSb.toString()).toUpperCase();

				logger.info("signSb={},sign={},newSign={}", signSb.toString(), sign, newSign);

				if (!sign.equals(newSign)) {
					throw new IllegalStateException("签名不正确");
				}
			}

			if (order.getPayStatus() != PayStatusEnum.UNPAY) {
				throw new IllegalStateException("不是未支付的订单,不需要进行手动通知操作");
			}

			orderRepository.updateToPayStatus(PayStatusEnum.PAYED, LocalDateTime.now(), LocalDateTime.now(), order.getId(),
					order.getMerchantCode());

			// 第三方支付提供商回调处理完成后,再通过消息机制向商户发送异步通知
			NotifyMerchantMessageObject msgObject = new NotifyMerchantMessageObject();
			msgObject.setOrderCode(order.getCode());
			msgObject.setMerchantCode(order.getMerchantCode());

			Gson gson = new GsonBuilder().create();
			String body = gson.toJson(msgObject);

			Message msg = new Message(MessageTopicEnum.ORDER.toString(), MessageTagEnum.NOTIFY_MERCHANT.toString(),
					UUID.randomUUID().toString(), body.getBytes());

			SendResult sendResult = messageProducer.send(msg);

			logger.info("发送通知商户的消息结果sendResult={}", sendResult);

			// 删除redis的支付金额
			if (LocalDateTime.now().isBefore(order.getExpireDateTime())) { // 订单未超时
				String key = merchant.getCode() + "_" + order.getPayChannel().toString() + "_AMOUNT";

				try {
					redisTemplate.boundHashOps(key).delete(String.valueOf(order.getPayAmount()));
				} catch (Exception e) {
					logger.error("删除key={}中的支付金额出错", key, e);
				}
			}
		} catch (IllegalArgumentException | IllegalStateException e) {
			throw e;
		} catch (Exception e) {
			throw new BusinessException("手动通知订单处理出错", e);
		}
	}

	/**
	 * 判断是否是否成功
	 * 
	 * @param merchantCode
	 * @param code
	 * @param sign
	 * @return
	 */
	public Boolean isPaySuccess(String merchantCode, String code, String sign) {
		if (StringUtils.isEmpty(merchantCode)) {
			throw new IllegalArgumentException("商户号不能为空");
		}

		if (StringUtils.isEmpty(code)) {
			throw new IllegalArgumentException("订单号不能为空");
		}

		if (StringUtils.isEmpty(sign)) {
			throw new IllegalArgumentException("签名不能为空");
		}

		try {
			Merchant merchant = merchantRepository.findByCode(merchantCode);

			if (merchant == null) {
				throw new IllegalStateException("找不到商户信息");
			}

			// 验证签名是否正确
			StringBuilder signSb = new StringBuilder();
			signSb.append("code=").append(code);
			signSb.append("&merchantCode=").append(merchant.getCode());
			signSb.append("&appSecret=").append(merchant.getAppSecret());

			String newSign = DigestUtils.md5Hex(signSb.toString()).toUpperCase();

			logger.info("signSb={},sign={},newSign={}", signSb.toString(), sign, newSign);

			if (!sign.equals(newSign)) {
				throw new IllegalStateException("签名不正确");
			}

			Order order = orderRepository.findByCodeAndMerchantCode(code, merchant.getCode());

			if (order == null) {
				throw new IllegalStateException("找不到订单信息");
			}

			if (order.getPayStatus() == PayStatusEnum.PAYED || order.getPayStatus() == PayStatusEnum.COMPLETED) {
				return Boolean.TRUE;
			} else {
				return Boolean.FALSE;
			}
		} catch (IllegalArgumentException | IllegalStateException e) {
			throw e;
		} catch (Exception e) {
			throw new BusinessException("获取订单信息出错", e);
		}
	}

	/**
	 * 
	 * @param merchantId
	 * @param queryVo
	 * @return
	 */
	public List<OrderVo> queryList(Long merchantId, OrderQueryVo queryVo) {
		PageRequest pageRequest = validateAndFetchPageRequest(queryVo.getPageNo(), queryVo.getPageSize());

		Merchant merchant = merchantRepository.findById(merchantId).get();
		queryVo.setMerchantCode(merchant.getCode());

		List<Order> list = orderRepository.queryList(queryVo, pageRequest);

		List<OrderVo> voList = new ArrayList<>();

		list.forEach(order -> {
			OrderVo vo = new OrderVo();

			BeanUtils.copyProperties(order, vo);

			vo.setPayStatusName(vo.getPayStatus().getName());
			vo.setPayChannelName(order.getPayChannel().getName());

			if (StringUtils.isEmpty(vo.getRemark())) {
				vo.setRemark("");
			}

			voList.add(vo);
		});

		return voList;
	}

	/**
	 * 
	 * @param orderRequest
	 */
	private void validateRange(OrderRequest orderRequest) {
		if (orderRequest == null) {
			throw new IllegalArgumentException("传递的支付数据不正确");
		}

		if (StringUtils.isEmpty(orderRequest.getMerchantCode())) {
			throw new IllegalArgumentException("商户号merchantCode不能为空");
		}

		if (StringUtils.isEmpty(orderRequest.getTradeNo())) {
			throw new IllegalArgumentException("商户交易号tradeNo不能为空");
		}

		if (StringUtils.isEmpty(orderRequest.getSubject())) {
			throw new IllegalArgumentException("商品标题subject不能为空");
		}

		if (StringUtils.isEmpty(orderRequest.getBody())) {
			throw new IllegalArgumentException("商品描述body不能为空");
		}

		if (orderRequest.getPayChannel() == null) {
			throw new IllegalArgumentException("支付渠道payChannel标识不能为空");
		}

		if (orderRequest.getTotalAmount() == null) {
			throw new IllegalArgumentException("支付金额不能为空");
		}

		if (orderRequest.getTotalAmount().compareTo(BigDecimal.valueOf(0.01D)) < 0) {
			throw new IllegalArgumentException("支付金额必须大于等于0.01");
		}

		if (orderRequest.getTotalAmount().compareTo(systemConstant.getMaxOrderAmount()) > 0) {
			throw new IllegalArgumentException("单笔最大金额不能大于" + systemConstant.getMaxOrderAmount());
		}

		if (StringUtils.isEmpty(orderRequest.getNotifyUrl())) {
			throw new IllegalArgumentException("回调地址notifyUrl不能为空");
		}

		if (orderRequest.getRequestDateTime() == null) {
			throw new IllegalArgumentException("订单创建时间requestDate不能为空");
		}

		if (StringUtils.isNotEmpty(orderRequest.getRemark()) && orderRequest.getRemark().length() > 200) {
			throw new IllegalArgumentException("备注信息remark的长度不能超过200");
		}

		if (orderRequest.getModel() == null) {
			throw new IllegalArgumentException("model标识不能为空");
		}

		if (orderRequest.getSignType() == null) {
			throw new IllegalArgumentException("signType不能为空");
		}

		if (orderRequest.getCodeType() == null) {
			throw new IllegalArgumentException("codeType不能为空");
		}

		if (StringUtils.isEmpty(orderRequest.getClientIp())) {
			throw new IllegalArgumentException("clientIp不能为空");
		}
	}

	/**
	 * 进行签名验证
	 * 
	 * @param orderRequest
	 * @param merchant
	 */
	private void validateSign(OrderRequest orderRequest, Merchant merchant) {
		if (orderRequest.getModel() != ModelEnum.NONE && orderRequest.getSignType() != SignTypeEnum.NONE) {
			if (StringUtils.isEmpty(orderRequest.getSign())) {
				throw new IllegalArgumentException("签名数据不能为空");
			}

			StringBuilder signSb = new StringBuilder();
			signSb.append("merchantCode=").append(orderRequest.getMerchantCode());
			signSb.append("&notifyUrl=").append(orderRequest.getNotifyUrl());
			signSb.append("&payChannel=").append(orderRequest.getPayChannel().toString());
			signSb.append("&tradeNo=").append(orderRequest.getTradeNo());

			BigDecimal tempTotalAmount = orderRequest.getTotalAmount().multiply(BigDecimal.ONE).setScale(2,
					RoundingMode.HALF_UP); // 金额的格式必须保留两位小数

			signSb.append("&totalAmount=").append(String.valueOf(tempTotalAmount));
			signSb.append("&appSecret=").append(merchant.getAppSecret());

			String signStr = signSb.toString();
			String newSign = DigestUtils.md5Hex(signStr).toUpperCase();

			logger.info("参与签名运算的字符串={},生成的签名={}", signStr, newSign);

			if (!orderRequest.getSign().equals(newSign)) {
				throw new ValidateException(ReturnCode.REC_11.getCode(), ReturnCode.REC_11.getName());
			}
		}
	}

	/**
	 * 
	 * @param merchant
	 * @return
	 */
	private void fetchAndFillPayAmount(Order order) {
		String key = order.getMerchantCode() + "_" + order.getPayChannel().toString() + "_AMOUNT";

		BigDecimal payAmount = order.getTotalAmount();

		Lock lock = new ReentrantLock();

		Boolean isFetchLock = Boolean.FALSE;

		try {
			isFetchLock = lock.tryLock(10, TimeUnit.SECONDS);
		} catch (Exception e) {
			logger.error("在10秒内无法获取到锁", e);
		}

		if (!isFetchLock) {
			throw new IllegalStateException("暂时无法生成支付金额");
		}

		Boolean isExistAmount = Boolean.FALSE;

		logger.info("商户[{}]的订单[{}]请求的总金额={}", order.getMerchantCode(), order.getCode(), payAmount);

		Long count = 0L;

		try {
			do {
				if (count > systemConstant.getOrderAmountFetchCount()) { // 防止无限或者过多的循环
					logger.warn("循环次数达到了{},暂时跳出循环", count);
					break;
				}

				String value = (String) redisTemplate.boundHashOps(key).get(String.valueOf(payAmount));

				if (StringUtils.isNotEmpty(value)) {
					LocalDateTime saveDateTime = DateUtil.toLocalDateTime(value);
					LocalDateTime now = LocalDateTime.now();

					Duration duration = Duration.between(saveDateTime, now);
					Long seconds = duration.getSeconds();

					if (seconds < systemConstant.getOrderExpireSeconds()) { // 没有超过失效时间
						payAmount = payAmount.subtract(BigDecimal.valueOf(0.01D));

						if (payAmount.compareTo(BigDecimal.ZERO) <= 0) { // 如果金额降低到了0,线程先睡眠1秒,然后金额加上0.1,再继续计算
							Thread.sleep(1000);

							payAmount = payAmount.add(BigDecimal.valueOf(0.1));
						}

						isExistAmount = Boolean.TRUE;
					} else {
						isExistAmount = Boolean.FALSE;
					}
				} else {
					isExistAmount = Boolean.FALSE;
				}

				count++;
			} while (isExistAmount);

			if (isExistAmount) {
				throw new IllegalStateException("暂时无法生成支付金额");
			}

			redisTemplate.boundHashOps(key).put(String.valueOf(payAmount),
					DateUtil.formatLocalDateTime(order.getCreateDateTime()));
		} catch (IllegalArgumentException | IllegalStateException e) {
			throw e;
		} catch (Exception e) {
			logger.error("访问redis出错了", e);
		} finally {
			lock.unlock();
		}

		logger.info("商户[{}]的订单[{}]最终生成的支付金额={},运算次数={}", order.getMerchantCode(), order.getCode(), payAmount, count);

		order.setPayAmount(payAmount);
		order.setActualAmount(payAmount);
	}

	/**
	 * 
	 * @param merchant
	 * @param order
	 */
	private void countAndFillServiceAmount(Merchant merchant, Order order) {
		Wallet wallet = walletRepository.findByMerchantCode(merchant.getCode());

		if (wallet == null) {
			throw new ValidateException(ReturnCode.REC_2003.getCode(), ReturnCode.REC_2003.getName());
		}

		BigDecimal serviceAmount = order.getPayAmount().multiply(merchant.getRate()).setScale(4, RoundingMode.HALF_UP);

		if (wallet.getBalance().compareTo(serviceAmount) < 0) {
			throw new ValidateException(ReturnCode.REC_2008.getCode(), ReturnCode.REC_2008.getName());
		}

		order.setServiceAmout(serviceAmount);
	}
}