package com.aipay.all.entity;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Version;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 商户的钱包信息,作为广播表使用
 *
 * @author admin
 */
@Entity
@Data
@EqualsAndHashCode(callSuper = true)
public class Wallet extends BaseDateTimeEntity {
	private static final long serialVersionUID = 1L;

	/**
	 * 冗余存储:对应的商户编号
	 */
	private Long merchantId;

	/**
	 * 商户编码
	 */
	private String merchantCode;

	/**
	 * 余额
	 */
	@Column(columnDefinition = "decimal(19,4)")
	private BigDecimal balance = BigDecimal.ZERO;

	/**
	 * 冻结金额
	 */
	@Column(columnDefinition = "decimal(19,4)")
	private BigDecimal freezeAmount = BigDecimal.ZERO;

	/**
	 * 赠送金额
	 */
	private BigDecimal giveAmount = BigDecimal.ZERO;

	/**
	 * 乐观锁标识
	 */
	@Version
	private Long version = 1L;
}
