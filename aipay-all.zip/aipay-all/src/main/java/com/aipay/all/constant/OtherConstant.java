package com.aipay.all.constant;

public class OtherConstant {

	/**
	 * 默认的每页最大返回的记录数
	 */
	public static final Integer DEFAULT_MAX_PAGE_SIZE = 10;
}
