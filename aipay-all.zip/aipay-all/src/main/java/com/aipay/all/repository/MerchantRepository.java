package com.aipay.all.repository;

import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.aipay.all.entity.Merchant;

@Repository
public interface MerchantRepository extends PagingAndSortingRepository<Merchant, Long> {

	Merchant findByCode(String code);

	Merchant findByUniqueCode(String uniqueCode);

	Merchant findByMobileAndPassword(String mobile, String password);
}