package com.aipay.all.message;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.apache.rocketmq.client.consumer.DefaultMQPushConsumer;
import org.apache.rocketmq.client.exception.MQClientException;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.aipay.all.service.NotifyService;
import com.aipay.common.message.enums.MessageTopicEnum;

@Configuration
public class ConsumerConfiguration {

	@Resource
	private ConsumerProperties consumerProperties;

	@Resource
	private NotifyService notifyService;

	@Bean(name = "messageConsumer", destroyMethod = "shutdown")
	public DefaultMQPushConsumer getRocketMQConsumer() {
		if (StringUtils.isBlank(consumerProperties.getNamesrvAddr())) {
			throw new IllegalArgumentException("namesrvAddr is null");
		}

		if (StringUtils.isBlank(consumerProperties.getGroupName())) {
			throw new IllegalArgumentException("groupName is null");
		}

		DefaultMQPushConsumer consumer = new DefaultMQPushConsumer(consumerProperties.getGroupName());
		consumer.setNamesrvAddr(consumerProperties.getNamesrvAddr());
		consumer.setConsumeThreadMin(consumerProperties.getConsumeThreadMin());
		consumer.setConsumeThreadMax(consumerProperties.getConsumeThreadMax());

		DefaultMessageListener defaultMessageListener = new DefaultMessageListener();
		defaultMessageListener.setNotifyService(notifyService);

		consumer.registerMessageListener(defaultMessageListener);

		try {
			// 订阅指定topic任意tag的消息
			consumer.subscribe(MessageTopicEnum.ORDER.toString(), "*");
			consumer.subscribe(MessageTopicEnum.MERCHANT.toString(), "*");

			consumer.start();
		} catch (MQClientException e) {
			throw new RuntimeException(e);
		}

		return consumer;
	}
}
