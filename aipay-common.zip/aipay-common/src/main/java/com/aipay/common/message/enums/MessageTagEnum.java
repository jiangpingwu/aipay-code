package com.aipay.common.message.enums;

import java.io.Serializable;

/**
 * 消息支持的tag
 * 
 * @author admin
 */
public enum MessageTagEnum implements Serializable {
	NOTIFY_MERCHANT("tag_notify_merchant", "通知商户", ""),
	CALLBACK_RECORD("tag_callback_record", "回调记录", ""),
	SUBTRACT_BALANCE("tag_subtract_balance", "扣减余额", "");
	
    private String code;

    private String name;

    private String desc;

    private MessageTagEnum(String code, String name, String desc) {
        this.code = code;
        this.name = name;
        this.desc = desc;
    }
    
    public String getName() {
        return name;
    }

    public String getCode() {
        return code;
    }

    public String getDesc() {	
        return desc;
    }
}
