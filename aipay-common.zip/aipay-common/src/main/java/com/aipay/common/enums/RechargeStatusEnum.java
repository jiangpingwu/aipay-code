package com.aipay.common.enums;

/**
 * 充值状态
 * 
 * @author admin
 */
public enum RechargeStatusEnum {
	UNPAY("pas_unpay", "未支付", ""),
	PAYING("pas_paying", "支付中", ""),
	CANCEL("pas_cancel", "支付取消", ""),
	PAYED("pas_payed", "已支付", ""),
	FAILURE("pas_pay_failure", "支付失败", ""),
	REFUNDING("pas_refunding", "退款中", ""),
	REFUNDED("pas_refunded", "退款完成", "");

	private String code;

	private String name;
	
	private String desc;

	private RechargeStatusEnum(String code, String name, String desc) {
		this.code = code;
		this.name = name;
		this.desc = desc;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getName() {
		return name;
	}
	
	public String getDesc() {
		return desc;
	}
}