package com.aipay.common.exception;

public class ValidateException extends BaseRuntimeException {
	private static final long serialVersionUID = 1L;

	public ValidateException(String errorMsg) {
		super(errorMsg);
	}

	public ValidateException(Throwable cause) {
		super(cause);
	}

	public ValidateException(String errorCode, String errorMsg) {
		super(errorCode, errorMsg);
	}

	public ValidateException(String errorMsg, Throwable cause) {
		super(errorMsg, cause);
	}

	public ValidateException(String errorCode, String errorMsg, Throwable cause) {
		super(errorCode, errorMsg, cause);
	}
}