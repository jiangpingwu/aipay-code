package com.aipay.common.enums;

import java.io.Serializable;

/**
 * 系统商户类型
 * 
 * @author admin
 */
public enum MerchantTypeEnum implements Serializable {
	NORMAL("mte_normal", "普通用户", ""), 
	PROXY("mte_proxy", "代理用户", "");

	private String code;

	private String name;

	private String desc;

	private MerchantTypeEnum(String code, String name, String desc) {
		this.code = code;
		this.name = name;
		this.desc = desc;
	}

	public String getName() {
		return name;
	}

	public String getCode() {
		return code;
	}

	public String getDesc() {
		return desc;
	}
}
