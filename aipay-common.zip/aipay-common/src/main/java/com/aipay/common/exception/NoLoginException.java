package com.aipay.common.exception;

public class NoLoginException extends BaseRuntimeException {
	private static final long serialVersionUID = 1L;

	public NoLoginException() {
		super();
	}

	public NoLoginException(String msg) {
		super(msg);
	}
}
