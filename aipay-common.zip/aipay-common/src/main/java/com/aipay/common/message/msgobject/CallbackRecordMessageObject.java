package com.aipay.common.message.msgobject;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import com.aipay.common.enums.PayChannelEnum;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
public class CallbackRecordMessageObject extends BaseMessageObject {

	private BigDecimal payAmount;

	private PayChannelEnum payChannel;

	private String sign;

	private Boolean isApp;

	private LocalDateTime requestDateTime;
}
