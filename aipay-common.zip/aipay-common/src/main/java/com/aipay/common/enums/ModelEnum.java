package com.aipay.common.enums;

import java.io.Serializable;

/**
 * 订单模式:标识支付订单是测试还是生产数据
 * 
 * @author admin
 */
public enum ModelEnum implements Serializable {
	TEST("test", "测试数据", ""),
	PRODUCT("product", "生产数据", ""),
	NONE("none","标识为普通测试数据","回调和通知时不会进行签名验证,便于自动化测试");

    private String code;

    private String name;

    private String desc;

    private ModelEnum(String code, String name, String desc) {
        this.code = code;
        this.name = name;
        this.desc = desc;
    }
    
    public String getName() {
        return name;
    }

    public String getCode() {
        return code;
    }

    public String getDesc() {	
        return desc;
    }
}
