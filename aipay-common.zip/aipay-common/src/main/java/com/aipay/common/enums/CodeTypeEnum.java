package com.aipay.common.enums;

import java.io.Serializable;

/**
 * 收款码图片类型
 * 
 * @author admin
 */
public enum CodeTypeEnum implements Serializable {
	BASE64_IMAGE("ctt_base64_image", "base64编码格式的图片", ""),
	IMAGE_URL("ctt_image_type", "图片的链接地址", ""),
    NONE("ctt_none","商户自己生成","");

    private String code;

    private String name;

    private String desc;

    private CodeTypeEnum(String code, String name, String desc) {
        this.code = code;
        this.name = name;
        this.desc = desc;
    }

    public String getName() {
        return name;
    }

    public String getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }
}
