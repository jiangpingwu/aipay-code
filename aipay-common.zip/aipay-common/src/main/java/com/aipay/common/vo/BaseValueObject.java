package com.aipay.common.vo;

import java.io.Serializable;

public class BaseValueObject implements Serializable {
	private static final long serialVersionUID = 1L;

}