package com.aipay.common.enums;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public enum RechargeChannelEnum implements Serializable {
	WECHAT_WAP("wechat_wap", "微信wap支付", ""),
	WECHAT_APP("wechat_app", "微信app支付",""),
	ALIPAY_APP("alipay_app", "支付宝app支付", ""),
	ALIPAY_WAP("alipay_wap", "支付宝wap付", "");

	private String code;

	private String name;

	private String desc;

	private RechargeChannelEnum(String code, String name, String desc) {
		this.code = code;
		this.name = name;
		this.desc = desc;
	}
	
	public static void fillToMap(Map<String, Map<Object, String>> dataMap) {
		Map<Object, String> map = new HashMap<>();

		for (RechargeChannelEnum e : RechargeChannelEnum.values()) {
			map.put(e, e.getName());
		}

		dataMap.put("PayChannelEnum", map);
	}

	public String getName() {
		return name;
	}

	public String getCode() {
		return code;
	}

	public String getDesc() {
		return desc;
	}
}
