package com.aipay.common.enums;

import java.io.Serializable;

/**
 * 系统商户状态
 * 
 * @author admin
 */
public enum MerchantStatusEnum implements Serializable {
	NORMAL("normal", "正常", ""), 
	FORBIDDEN("forbidden", "禁用", "");

	private String code;

	private String name;

	private String desc;

	private MerchantStatusEnum(String code, String name, String desc) {
		this.code = code;
		this.name = name;
		this.desc = desc;
	}

	public String getName() {
		return name;
	}

	public String getCode() {
		return code;
	}

	public String getDesc() {
		return desc;
	}
}
