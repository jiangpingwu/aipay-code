package com.aipay.common.constant;

public enum ReturnCode {
	REC_0("0", "系统繁忙,请稍后再试", ""),
	REC_NEGATIVE_1("-1", "用戶未登录", ""),
	REC_1("1", "操作成功", ""),
	REC_2("2", "参数验证出错", ""),
	REC_3("3", "参数映射错误", ""),
	REC_4("4", "认证出错", ""),
	REC_5("5", "找不到请求的接口地址", ""),
	REC_6("6", "不支持的请求方法", ""),
	REC_7("7", "不正确的Content-Type请求头标识", ""),
	REC_10("10", "请求出错了", ""),
	REC_11("11","签名错误",""),
	REC_100("100", "其它错误", ""),
	REC_2001("2001","商户不存在",""),
	REC_2003("2003","没有绑定支付账号",""),
	REC_2004("2004","不正确的支付渠道",""),
	REC_2006("2006","商户被禁用",""),
	REC_2008("2008","商户余额不足","");
	
	private String code;

	private String name;
	
	private String desc;

	private ReturnCode(String code, String name, String desc) {
		this.code = code;
		this.name = name;
		this.desc = desc;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getName() {
		return name;
	}
	
	public String getDesc() {
		return desc;
	}
}