package com.aipay.common.bean;

import java.util.Map;

import com.aipay.common.enums.CodeTypeEnum;
import com.aipay.common.enums.SignTypeEnum;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

/**
 * 支付请求对象
 * 
 * @author admin
 */
@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
public class OrderRequest extends Payment {
	private static final long serialVersionUID = 1L;

	/**
	 * 根据signType生成的对应的签名串
	 */
	private String sign;

	/**
	 * 商品标题,该参数最长为32个Unicode字符
	 */
	private String subject;

	/**
	 * 商品描述信息,该参数最长为128个Unicode字符
	 */
	private String body;

	/**
	 * 扩展的参数数据
	 */
	private Map<String, Object> extraData;

	/**
	 * 需要回传的参数数据
	 */
	private Map<String, Object> passbackData;

	/**
	 * 商户的异步回调地址
	 */
	private String notifyUrl;

	/**
	 * 支付成功后的跳转地址
	 */
	private String returnUrl;

	/**
	 * 订单创建时间,是订单在商户后台创建的时间,晚于系统当前时间的订单不能正常提交,格式为yyyy-MM-dd HH:mm:ss
	 */
	private String requestDateTime;

	/**
	 * 备注信息
	 */
	private String remark;

	/**
	 * 客户端ip,不能为空
	 */
	private String clientIp;

	/**
	 * 服务端接口的版本标识,默认为1.0.1
	 */
	private String version = "1.0.1";

	/**
	 * 字符集编码,目前只支持UTF-8
	 */
	private String charset = "UTF-8";

	/**
	 * 签名类型,在测试阶段或者非高安全的情况下可以先不需要签名
	 */
	private SignTypeEnum signType = SignTypeEnum.MD5;

	/**
	 * 收款码生成类型
	 */
	private CodeTypeEnum codeType = CodeTypeEnum.IMAGE_URL;
}