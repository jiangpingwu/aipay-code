package com.aipay.common.exception;

public class BusinessException extends BaseRuntimeException {
	private static final long serialVersionUID = 1L;

	public BusinessException(String errorMsg) {
		super(errorMsg);
	}

	public BusinessException(Throwable cause) {
		super(cause);
	}
	
	public BusinessException(String errorCode, String errorMsg) {
		super(errorCode, errorMsg);
	}

	public BusinessException(String errorMsg, Throwable cause) {
		super(errorMsg, cause);
	}

	public BusinessException(String errorCode, String errorMsg, Throwable cause) {
		super(errorCode, errorMsg, cause);
	}
}