package com.aipay.common.exception;

public class BaseRuntimeException extends RuntimeException {
	private static final long serialVersionUID = 1L;

	protected String errorCode;
	protected String errorMsg;
	protected Throwable throwable;

	public BaseRuntimeException() {
		super();
	}

	public BaseRuntimeException(String errorMsg) {
		super(errorMsg);

		this.errorMsg = errorMsg;
	}

	public BaseRuntimeException(Throwable cause) {
		super(cause);

		this.throwable = cause;
	}

	public BaseRuntimeException(String errorCode, String errorMsg) {
		super(errorMsg);

		this.errorCode = errorCode;
		this.errorMsg = errorMsg;
	}

	public BaseRuntimeException(String errorMsg, Throwable cause) {
		super(errorMsg, cause);

		this.errorMsg = errorMsg;
		this.throwable = cause;
	}

	public BaseRuntimeException(String errorCode, String errorMsg, Throwable cause) {
		super(errorMsg, cause);

		this.errorCode = errorCode;
		this.errorMsg = errorMsg;
		this.throwable = cause;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public void setCause(Throwable cause) {
		this.throwable = cause;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public Throwable getThrowable() {
		return throwable;
	}

	public void setThrowable(Throwable throwable) {
		this.throwable = throwable;
	}
}