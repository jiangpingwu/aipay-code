package com.aipay.common.util;

public class CodeUtil {

	/**
	 * 生成商户编码
	 * 
	 * @return
	 */
	public static String generateMerchantCode() {
		return "AP_M" + System.nanoTime();
	}

	/**
	 * 生成订单编码
	 *
	 * @param merchantId
	 * @return
	 */
	public static String generateOrderCode(Long merchantId) {
		return "AP_O" + merchantId + "_" + System.nanoTime() + "R" + fetchRandomNumber();
	}

	/**
	 * 生成支付流水编码
	 *
	 * @param merchantId
	 * @return
	 */
	public static String generatePaymentCode(Long merchantId) {
		return "AP_R" + merchantId + "_" + System.nanoTime() + "R" + fetchRandomNumber();
	}

	private static int fetchRandomNumber() {
		int res = (int) (Math.random() * 900000) + 99999;

		return res;
	}
}