package com.aipay.common.util;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class DateUtil {
	public static final String DATEFORMAT_DATETIME = "yyyy-MM-dd HH:mm:ss";

	public static final String DATEFORMAT_DATETIME14 = "yyyyMMddHHmmss";

	public static final String DATEFORMAT_DATETIME16 = "yyyy-MM-dd HH:mm";

	public static final String DATEFORMAT_TIMESTAMP = "yyyy-MM-dd HH:mm:ss.SSS";

	public static final String DATEFORMAT_TIMESTAMP17 = "yyyyMMddHHmmssSSS";

	/**
	 * 将LocalDateTime按格式转换成字符串
	 * 
	 * @param dateTime
	 * @return
	 */
	public static String formatLocalDateTime(LocalDateTime dateTime) {
		return dateTime.format(DateTimeFormatter.ofPattern(DateUtil.DATEFORMAT_DATETIME));
	}

	/**
	 * 将LocalDateTime按格式转换成字符串
	 * 
	 * @param dateTime
	 * @param formatStr
	 * @return
	 */
	public static String formatLocalDateTime(LocalDateTime dateTime, String formatStr) {
		return dateTime.format(DateTimeFormatter.ofPattern(formatStr));
	}

	/**
	 * 使用默认格式转换日期
	 *
	 * @param dateTime
	 * @return
	 */
	public static LocalDateTime toLocalDateTime(String dateTime) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern(DateUtil.DATEFORMAT_DATETIME);

		return LocalDateTime.parse(dateTime, formatter);
	}

	/**
	 * 使用默认格式转换日期
	 *
	 * @param dateTime
	 * @param formatStr
	 * @return
	 */
	public static LocalDateTime toLocalDateTime(String dateTime, String formatStr) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern(formatStr);

		return LocalDateTime.parse(dateTime, formatter);
	}
}