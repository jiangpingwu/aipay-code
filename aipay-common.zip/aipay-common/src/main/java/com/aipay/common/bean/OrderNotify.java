package com.aipay.common.bean;

import java.math.BigDecimal;
import java.util.Map;

import com.aipay.common.enums.SignTypeEnum;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 异步通知商户对象
 * 
 * @author admin
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class OrderNotify extends Payment {
	private static final long serialVersionUID = 1L;

	/**
	 * 生成的唯一标识
	 */
	private String code;

	/**
	 * 实际支付金额
	 */
	private BigDecimal payAmount;

	/**
	 * 回传参数,如果请求时传递了该参数，则返回给商户时会回传该参数
	 */
	private Map<String,Object> passbackData;

	/**
	 * 订单支付时间,是订单在支付中心生成支付数据的时间
	 */
	private String payDateTime;

	/**
	 * 签名方式:可选的取值为none md5 rsa等,如果取值为none则不进行签名认证处理,一般在开发阶段使用
	 */
	private SignTypeEnum signType;

	/**
	 * 签名
	 */
	private String sign = "";
}