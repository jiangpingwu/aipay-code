package com.aipay.common.message.msgobject;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
public class NotifyMerchantMessageObject extends BaseMessageObject {

	/**
	 * 订单号
	 */
	private String orderCode;
}
