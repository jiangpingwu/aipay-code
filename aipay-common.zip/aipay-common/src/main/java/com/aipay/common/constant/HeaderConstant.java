package com.aipay.common.constant;

/**
 * 
 * @author admin
 */
public class HeaderConstant {

	/**
	 * 每次請求的uuid标识,与logback中的MDC存储的值是对应的
	 */
	public static final String REQUEST_UUID = "request-uuid";

	/**
	 * 用户token的名称定义,与前端app传递的参数名对应
	 */
	public static final String UNIQUE_CODE = "unique-code";
	
	/**
	 * 设备号，与前端app传递的参数名对应
	 */
	public static final String DEVICE_CODE = "device-code";
}