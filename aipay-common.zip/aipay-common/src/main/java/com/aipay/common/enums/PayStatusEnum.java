package com.aipay.common.enums;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * 支付状态
 * 
 * @author admin
 */
public enum PayStatusEnum implements Serializable {
	UNPAY("pas_unpay", "未支付", "创建了订单,但还未执行支付操作"),
	CANCEL("pas_cancel", "支付取消", "商户通知支付中心支付取消"),
	PAYED("pas_payed", "已支付", "已支付,收到支付提供商的回调通知,但是还没有通知商户"),
	OVERTIME("pas_overtime", "已超时", "已超时,超过了指定时间还没支付"),
	COMPLETED("pas_completed", "已完成", "已支付,并且已成功通知商户,商户也返回了成功结果"),
	FAILURE("pas_failure", "支付失败", "支付提供商通知支付中心支付失败");

    private String code;

    private String name;

    private String desc;

    private PayStatusEnum(String code, String name, String desc) {
        this.code = code;
        this.name = name;
        this.desc = desc;
    }
    
    public static List<PayStatusEnum> fetchCanUse() {
    	List<PayStatusEnum> list = new ArrayList<>();
    	list.add(UNPAY);
    	list.add(PAYED);
    	list.add(COMPLETED);
    	
    	return list;
    }
    
    public String getName() {
        return name;
    }

    public String getCode() {
        return code;
    }

    public String getDesc() {	
        return desc;
    }
}
