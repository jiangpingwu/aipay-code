package com.aipay.common.enums;

import java.io.Serializable;

/**
 * 结算状态
 * 
 * @author admin
 */
public enum CountStatusEnum implements Serializable {
	UNCOUNT("cse_uncount", "未结算", "还未扣除订单的服务费"),
	COUNTED("cse_counted", "已结算", "已经扣除订单的服务费");
    private String code;

    private String name;

    private String desc;

    private CountStatusEnum(String code, String name, String desc) {
        this.code = code;
        this.name = name;
        this.desc = desc;
    }
    
    public String getName() {
        return name;
    }

    public String getCode() {
        return code;
    }

    public String getDesc() {	
        return desc;
    }
}
