package com.aipay.common.enums;

import java.io.Serializable;

/**
 * 支付渠道,与PayChannel的code属性相对应
 * 
 * @author admin
 */
public enum PayChannelEnum implements Serializable {
	ALIPAY_CODE("pce_alipay_code","支付宝收款",""),
	WECHAT_CODE("pce_wechat_code","微信收款","");

	private String code;

	private String name;

	private String desc;

	private PayChannelEnum(String code, String name, String desc) {
		this.code = code;
		this.name = name;
		this.desc = desc;
	}

	public String getName() {
		return name;
	}

	public String getCode() {
		return code;
	}

	public String getDesc() {
		return desc;
	}
}
