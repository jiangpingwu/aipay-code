package com.aipay.common.message.msgobject;

import lombok.Data;

@Data
public class BaseMessageObject {

	/**
	 * 商户号
	 */
	protected String merchantCode;
}
