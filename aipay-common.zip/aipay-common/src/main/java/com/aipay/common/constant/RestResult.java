package com.aipay.common.constant;

import java.io.Serializable;

public class RestResult implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 * 返回的编码,标识接口调用成功或者失败
	 */
	protected String status = ReturnCode.REC_1.getCode();

	/**
	 * 返回的提示消息
	 */
	protected String msg = ReturnCode.REC_1.getName();;

	/**
	 * 返回的数据
	 */
	protected Object data;

	/**
	 * @return the msg
	 */
	public String getMsg() {
		return msg;
	}

	/**
	 * @param msg
	 *            the msg to set
	 */
	public void setMsg(String msg) {
		this.msg = msg;
	}

	/**
	 * @return the data
	 */
	public Object getData() {
		return data;
	}

	/**
	 * @param data
	 *            the data to set
	 */
	public void setData(Object data) {
		this.data = data;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "RestResult [status=" + status + ", msg=" + msg + ", data=" + data + "]";
	}
}