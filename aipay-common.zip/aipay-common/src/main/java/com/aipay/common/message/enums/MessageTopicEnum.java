package com.aipay.common.message.enums;

import java.io.Serializable;

/**
 * 消息支持的topic
 * 
 * @author admin
 */
public enum MessageTopicEnum implements Serializable {
	ORDER("topic_pay_skm_order", "订单通知消息", ""),
	MERCHANT("topic_pay_skm_merchant", "商户通知消息", "");
    private String code;

    private String name;

    private String desc;

    private MessageTopicEnum(String code, String name, String desc) {
        this.code = code;
        this.name = name;
        this.desc = desc;
    }
    
    public String getName() {
        return name;
    }

    public String getCode() {
        return code;
    }

    public String getDesc() {	
        return desc;
    }
}
