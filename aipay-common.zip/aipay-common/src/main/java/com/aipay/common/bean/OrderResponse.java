package com.aipay.common.bean;

import java.math.BigDecimal;

import com.aipay.common.enums.CodeTypeEnum;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 支付响应对象
 * 
 * @author admin
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class OrderResponse extends Payment {
	private static final long serialVersionUID = 1L;

	/**
	 * 生成的唯一标识
	 */
	private String code;

	/**
	 * 实际支付金额
	 */
	private BigDecimal payAmount;

	/**
	 * 收款码生成类型
	 */
	private CodeTypeEnum codeType = CodeTypeEnum.IMAGE_URL;

	/**
	 * 收款码的类型:可能是base64Image格式的图片,可能是图片的链接地址,也可以为空
	 */
	private String codeContent;

	/**
	 * 订单创建时间,是订单在支付中心生成支付数据的时间
	 */
	private String createDateTime;

	/**
	 * 订单的过期时间,不同支付渠道的过期时间不一样
	 */
	private String expireDateTime;
}