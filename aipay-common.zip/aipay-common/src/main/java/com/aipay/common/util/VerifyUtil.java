package com.aipay.common.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;

public class VerifyUtil {

	/**
	 * 是否是电话(固话+手机)
	 * 
	 * @param phone
	 * @return
	 */
	public static boolean isPhone(String phone) {
		String regEx = "(^((\\d{3,4})|\\d{3,4}-)\\d{7,8}$)|(^[1][3584]\\d{9}$)";
		Pattern p = Pattern.compile(regEx);
		Matcher m = p.matcher(phone);
		if (!m.find()) {
			return false;
		}
		return true;
	}

	/**
	 * 是否是图片
	 */
	public static boolean isPicture(String picture) {
		if (StringUtils.isBlank(picture)) {
			return false;
		}
		String regEx = "\\w+\\\\.(jpg|jpeg|gif|bmp|png)";
		return Pattern.matches(regEx, picture);
	}

	/**
	 * 是否是邮箱
	 */
	public static boolean isEmail(String email) {
		if (StringUtils.isBlank(email)) {
			return false;
		}
		String regEx = "^\\w+([-+.]\\w+)*@\\w+([-.]\\w+)*\\.\\w+([-.]\\w+)*$";
		return Pattern.matches(regEx, email);
	}

	/**
	 * 是否是手机号码
	 */
	public static boolean isMobile(String mobile) {
		if (StringUtils.isBlank(mobile)) {
			return false;
		}
		String regEx = "^[1][35847]\\d{9}$";
		return Pattern.matches(regEx, mobile);
	}
}