package com.aipay.common.enums;

import java.util.HashMap;
import java.util.Map;

public enum RechargePlatformEnum {
    WECHAT("pap_wechat", "微信支付", ""),
    ALIPAY("pap_alipay", "支付宝支付", "");

	private String code;

	private String name;
	
	private String desc;

	private RechargePlatformEnum(String code, String name, String desc) {
		this.code = code;
		this.name = name;
		this.desc = desc;
	}
	
	public static void fillToMap(Map<String, Map<Object, String>> dataMap) {
		Map<Object, String> map = new HashMap<>();

		for (RechargePlatformEnum e : RechargePlatformEnum.values()) {
			map.put(e, e.getName());
		}

		dataMap.put("PayPlatformEnum", map);
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getName() {
		return name;
	}
	
	public String getDesc() {
		return desc;
	}
}