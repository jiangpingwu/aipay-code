package com.aipay.common.bean;

import java.math.BigDecimal;

import com.aipay.common.enums.ModelEnum;
import com.aipay.common.enums.PayChannelEnum;
import com.aipay.common.vo.BaseValueObject;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class Payment extends BaseValueObject {
	private static final long serialVersionUID = 1L;

	/**
	 * 模式:标识是test还是product
	 */
	protected ModelEnum model = ModelEnum.TEST;

	/**
	 * 商户编码
	 */
	protected String merchantCode;

	/**
	 * 商户的订单编号,在商户系统中必须唯一,不同支付渠道的长度和字符限制不同
	 */
	protected String tradeNo;

	/**
	 * 支付渠道
	 */
	protected PayChannelEnum payChannel;

	/**
	 * 支付金额,以元为单位,不能为空
	 */
	protected BigDecimal totalAmount;
}