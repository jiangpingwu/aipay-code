package com.aipay.demo.constant;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class SystemConstant {

	@Value("${notify_url}")
	private String notifyUrl;

	@Value("${aipay_url}")
	private String aipayUrl;

	public String getAipayUrl() {
		return aipayUrl;
	}

	public String getNotifyUrl() {
		return notifyUrl;
	}
}