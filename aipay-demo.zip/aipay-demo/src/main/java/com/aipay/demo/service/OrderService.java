package com.aipay.demo.service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.google.gson.GsonBuilder;

@Service
public class OrderService extends BaseService {

	/**
	 * 
	 * @param merchantCode
	 * @param totalAmount
	 * @param payChannel
	 * @return
	 */
	public Map<String, Object> createOrder(String merchantCode, BigDecimal totalAmount, String payChannel) {
		try {
			Map<String, String> paramMap = new HashMap<>();
			paramMap.put("tradeNo", "TEST_" + System.nanoTime());
			paramMap.put("merchantCode", merchantCode);
			paramMap.put("payChannel", payChannel);
			paramMap.put("totalAmount", String.valueOf(totalAmount));
			paramMap.put("subject", "demo商品88");
			paramMap.put("body", "使用demo商品8888");
			paramMap.put("notifyUrl", systemConstant.getNotifyUrl());
			paramMap.put("requestDateTime",
					LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
			paramMap.put("codeType", "IMAGE_URL");
			paramMap.put("model", "NONE");
			paramMap.put("signType", "NONE");
			paramMap.put("clientIp", "127.0.0.1");

			// 生成json请求串
			String jsonStr = new GsonBuilder().create().toJson(paramMap);

			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.parseMediaType("application/json; charset=UTF-8"));
			headers.add("Accept", MediaType.APPLICATION_JSON.toString());

			HttpEntity<String> formEntity = new HttpEntity<>(jsonStr, headers);

			String result = restTemplate.postForObject(systemConstant.getAipayUrl(), formEntity, String.class);

			logger.info("返回的result={}", result);

			JSONObject jsonObject = JSON.parseObject(result);

			String status = jsonObject.getString("status");

			if (!status.equals("1")) {
				throw new IllegalStateException("创建aipay订单出错了");
			}

			JSONObject dataJsonObject = jsonObject.getJSONObject("data");

			String thirdOrderNo = dataJsonObject.getString("code");
			String payAmount = dataJsonObject.getString("payAmount");
			String codeType = dataJsonObject.getString("codeType");
			String codeContent = dataJsonObject.getString("codeContent");

			Map<String, Object> returnMap = new HashMap<>();
			returnMap.put("thirdOrderNo", thirdOrderNo);
			returnMap.put("totalAmount", totalAmount);
			returnMap.put("payAmount", payAmount);
			returnMap.put("codeType", codeType);
			returnMap.put("codeContent", codeContent);

			return returnMap;
		} catch (IllegalArgumentException | IllegalStateException e) {
			throw e;
		} catch (Exception e) {
			throw new RuntimeException("创建aipay订单出错了", e);
		}
	}
}