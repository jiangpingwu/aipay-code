package com.aipay.demo.rest;

import java.math.BigDecimal;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.aipay.demo.service.OrderService;

@Controller
@RequestMapping(value = "/order")
public class OrderRest extends BaseRest {

	@Resource
	private OrderService orderService;

	@RequestMapping(value = "/toRecharge", method = { RequestMethod.GET, RequestMethod.POST })
	public String toRecharge(Model model) {
		return "order/to_recharge";
	}

	@RequestMapping(value = "/recharge", method = { RequestMethod.POST })
	public String recharge(Model model, String merchantCode, BigDecimal amount, String payChannel) {
		Map<String, Object> returnMap = orderService.createOrder(merchantCode, amount, payChannel);

		model.addAttribute("thirdOrderNo", returnMap.get("thirdOrderNo"));
		model.addAttribute("totalAmount", returnMap.get("totalAmount"));
		model.addAttribute("payAmount", returnMap.get("payAmount"));
		model.addAttribute("codeContent", returnMap.get("codeContent"));

		if (payChannel.equals("ALIPAY_CODE")) {
			return "order/alipay_pay";
		} else if (payChannel.equals("WECHAT_CODE")) {
			return "order/wechat_pay";
		} else {
			return "order/error";
		}
	}
}