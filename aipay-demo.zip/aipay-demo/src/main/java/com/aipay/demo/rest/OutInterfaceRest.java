package com.aipay.demo.rest;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "/out")
public class OutInterfaceRest extends BaseRest {

	/**
	 * 
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/callbackForAipay", method = { RequestMethod.POST })
	public String callbackForZpskm(HttpServletRequest request, HttpServletResponse response) {
		PrintWriter writer = null;

		try {
			logger.info("aipay支付回调方法,远程请求机器ip=" + getClientIp());

			writer = response.getWriter();

			String result = parseInputStream(request);

			logger.info("aipay服务器返回的支付结果：" + result);

			// TODO 商户执行具体的验签和订单处理逻辑

			writer.print("SUCCESS");
		} catch (Exception e) {
			logger.error("aipay支付回调出错了", e);

			writer.print("FAILURE");
		} finally {
			if (writer != null) {
				writer.flush();
				writer.close();
			}
		}

		return null;
	}
}